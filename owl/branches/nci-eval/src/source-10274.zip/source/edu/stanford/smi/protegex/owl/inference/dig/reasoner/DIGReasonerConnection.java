package edu.stanford.smi.protegex.owl.inference.dig.reasoner;

import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;

/**
 * User: matthewhorridge<br>
 * The Univeristy Of Manchester<br>
 * Medical Informatics Group<br>
 * Date: Jun 4, 2004<br><br>
 * <p/>
 * matthew.horridge@cs.man.ac.uk<br>
 * www.cs.man.ac.uk/~horridgm<br><br>
 */
public interface DIGReasonerConnection {

    /**
     * Specifies the location of the inference
     *
     * @param reasonerURL The <code>URL</code>
     */
    public void setReasonerURL(String reasonerURL);


    /**
     * Gets the URL that points to the location
     * of the DIG Reasoner.
     */
    public String getReasonerURL();


    /**
     * Sends a request to the inference
     *
     * @param writer The <code>StringWriter</code> that the
     *               request has been already written in to.
     */
    public void send(StringWriter writer) throws IOException;


    /**
     * Obtains a <code>Reader</code>  which can be
     * used to get the reasoner response
     */
    public Reader receive() throws IOException;


    /**
     * May be used to close the reasoner connection
     * after a read has finished.
     *
     * @throws IOException
     */
    public void closeConnection() throws IOException;
}
