package edu.stanford.smi.protegex.owl.swrl.model;

import edu.stanford.smi.protegex.owl.model.RDFList;

/**
 * @author Martin O'Connor  <moconnor@smi.stanford.edu>
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface SWRLAtomList extends RDFList, SWRLIndividual {

} // SWRLAtomList

