package edu.stanford.smi.protegex.owl.model.factory;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.model.framestore.MergingNarrowFrameStore;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class OWLJavaFactoryUpdater {

    private KnowledgeBase kb;

    private int count = 0;

    private Slot directSuperclassesSlot;

    private Slot directSubslotsSlot;

    private MergingNarrowFrameStore mnfs;


    public OWLJavaFactoryUpdater(KnowledgeBase kb) {
        this(kb, kb.getFrames());
    }


    public OWLJavaFactoryUpdater(KnowledgeBase kb, Collection frames) {
        this.kb = kb;
        directSuperclassesSlot = kb.getSlot(Model.Slot.DIRECT_SUPERCLASSES);
        directSubslotsSlot = kb.getSlot(Model.Slot.DIRECT_SUBSLOTS);

        mnfs = MergingNarrowFrameStore.get(kb);

        long startTime = System.currentTimeMillis();

        for (Iterator it = frames.iterator(); it.hasNext();) {
            Instance instance = (Instance) it.next();
            Instance newInstance = createNewFrame(instance);
            if (instance.getClass() != newInstance.getClass()) {
                mnfs.replaceFrame(newInstance);
                if ((++count % 10000) == 0) {
                    System.out.println("FactoryUpdater " + count + ": Replacing " + instance.getName() + " from " + instance.getClass() + " to " + newInstance.getClass());
                }
            }
        }

        long endTime = System.currentTimeMillis();
        //System.out.println(" OWLJavaFactoryUpdater took " + (endTime - startTime) + " ms for " + count + " frames.");
    }


    private Instance createNewFrame(Instance instance) {
        if (isCls(instance)) {
            return instance.getKnowledgeBase().getFrameFactory().createCls(instance.getFrameID(), instance.getDirectTypes());
        }
        else if (isSlot(instance)) {
            return instance.getKnowledgeBase().getFrameFactory().createSlot(instance.getFrameID(), instance.getDirectTypes());
        }
        else if (!(instance instanceof Facet)) {
            return instance.getKnowledgeBase().getFrameFactory().createSimpleInstance(instance.getFrameID(), instance.getDirectTypes());
        }
        return instance;
    }


    private boolean isSlot(Instance instance) {
        return instance.hasOwnSlot(directSubslotsSlot);
    }


    private boolean isCls(Instance instance) {
        Collection types = instance.getDirectTypes();
        for (Iterator it = types.iterator(); it.hasNext();) {
            Instance type = (Instance) it.next();
            if (!(type instanceof Cls)) {
                updateFrame(type);
            }
        }
        return instance.hasOwnSlot(directSuperclassesSlot);
    }


    public void updateFrame(Instance instance) {
        Instance newInstance = createNewFrame(instance);
        if (instance.getClass() != newInstance.getClass()) {
            mnfs.replaceFrame(newInstance);
        }
    }


    public static void run(Instance resource) {
        run(resource.getKnowledgeBase(), Collections.singleton(resource));
    }


    public static void run(KnowledgeBase kb, Collection instances) {
        new OWLJavaFactoryUpdater(kb, instances);
    }


    /**
     * Completely replaces all occurances of all frames to their correct Java type
     * according to the current FrameFactory.  This method tolerates frames that have
     * a completely wrong type, e.g. Slots can be converted into Clses etc.
     *
     * @param owlModel the OWLModel
     */
    public static void run(JenaOWLModel owlModel) {
        new OWLJavaFactoryUpdater(owlModel);
    }
}
