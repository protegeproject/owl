package edu.stanford.smi.protegex.owl.jena;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLFilesPlugin {

    void setFile(String fileURI);


    void setLanguage(String lang);


    void setUseARP(boolean value);
}
