package edu.stanford.smi.protegex.owl.model.factory.tests;

import edu.stanford.smi.protegex.owl.model.RDFIndividual;

/**
 * A test interface only.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface TestPerson extends RDFIndividual {

}
