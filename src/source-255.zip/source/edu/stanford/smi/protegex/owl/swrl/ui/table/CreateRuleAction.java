package edu.stanford.smi.protegex.owl.swrl.ui.table;

import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLFactory;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLImp;
import edu.stanford.smi.protegex.owl.swrl.ui.code.SWRLTextAreaPanel;
import edu.stanford.smi.protegex.owl.swrl.ui.icons.SWRLIcons;
import edu.stanford.smi.protegex.owl.ui.icons.OWLIcons;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class CreateRuleAction extends AbstractAction {

    private OWLModel okb;

    private SWRLTable table;


    public CreateRuleAction(SWRLTable table, OWLModel okb) {
        super("Create new rule...", OWLIcons.getCreateIcon(SWRLIcons.IMP, SWRLIcons.class));
        this.okb = okb;
        this.table = table;
    }


    public void actionPerformed(ActionEvent e) {
        final SWRLImp newImp = new SWRLFactory(okb).createImp();
        if (SWRLTextAreaPanel.showEditDialog(table, okb, newImp)) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    table.setSelectedRow(newImp);
                }
            });
        }
        else {
            newImp.delete();
        }
    }
}
