package edu.stanford.smi.protegex.owl.model;


/**
 * A Cls representing a minimumCardinality restriction.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLMinCardinality extends OWLCardinalityBase {

}
