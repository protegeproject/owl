package edu.stanford.smi.protegex.owl.compactparser.tests;

import edu.stanford.smi.protegex.owl.compactparser.OWLCompactParser;
import edu.stanford.smi.protegex.owl.model.OWLHasValue;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.RDFSClass;
import edu.stanford.smi.protegex.owl.tests.AbstractOWLModelTestCase;
import edu.stanford.smi.protegex.owl.ui.profiles.OWLProfiles;
import edu.stanford.smi.protegex.owl.ui.profiles.ProfilesManager;

public class ParseHasRestrictionTestCase extends AbstractOWLModelTestCase {


    public void testParseHasValueBoolean() throws Exception {
        owlModel.createOWLDatatypeProperty("rich", owlModel.getXSDboolean());
        String expression = "rich $ true";
        RDFSClass aClass = OWLCompactParser.parseCls(owlModel, expression);
        assertTrue(aClass instanceof OWLHasValue);
        OWLHasValue restriction = (OWLHasValue) aClass;
        assertEquals(restriction.getOnProperty().getName(), "rich");
        assertEquals(restriction.getHasValue(), Boolean.TRUE);
    }


    public void testParseHasValueString() throws Exception {
        owlModel.createOWLDatatypeProperty("name", owlModel.getXSDstring());
        String expression = "name $ \"Hans Eichel\"";
        RDFSClass aClass = OWLCompactParser.parseCls(owlModel, expression);
        assertTrue(aClass instanceof OWLHasValue);
        OWLHasValue restriction = (OWLHasValue) aClass;
        assertEquals(restriction.getOnProperty().getName(), "name");
        assertEquals(restriction.getHasValue(), "Hans Eichel");
    }


    public void testParseHasClass() throws Exception {
        OWLNamedClass namedCls = owlModel.createOWLNamedClass("Cls");
        owlModel.createOWLObjectProperty("slot");
        String expression = "slot $ Cls";
        RDFSClass aClass = OWLCompactParser.parseCls(owlModel, expression);
        assertTrue(aClass instanceof OWLHasValue);
        OWLHasValue restriction = (OWLHasValue) aClass;
        assertEquals(restriction.getOnProperty().getName(), "slot");
        assertEquals(restriction.getHasValue(), namedCls);
    }


    public void testParseHasClassInOWLDL() throws Exception {
        ProfilesManager.setProfile(owlModel, OWLProfiles.OWL_DL.getURI());
        owlModel.createOWLNamedClass("Cls");
        owlModel.createOWLObjectProperty("slot");
        String expression = "slot $ Cls";
        try {
            OWLCompactParser.parseCls(owlModel, expression);
            assertFalse("Expected failure!", true);
        }
        catch (Exception ex) {
            // Expected
        }
    }


    public void testParseIllegalHasFiller1() {
        owlModel.createOWLObjectProperty("slot");
        String expression = "slot $ 42";
        try {
            OWLCompactParser.parseCls(owlModel, expression);
            assertTrue(false);
        }
        catch (Exception ex) {
            // Expected
        }
    }


    public void testParseIllegalHasFiller2() {
        owlModel.createOWLDatatypeProperty("slot");
        OWLNamedClass cls = owlModel.createOWLNamedClass("Cls");
        cls.createInstance("instance");
        String expression = "slot $ instance";
        try {
            OWLCompactParser.parseCls(owlModel, expression);
            assertTrue(false);
        }
        catch (Exception ex) {
            // Expected
        }
    }
}
