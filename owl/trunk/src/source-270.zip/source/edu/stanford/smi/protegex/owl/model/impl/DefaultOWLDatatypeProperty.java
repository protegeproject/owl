package edu.stanford.smi.protegex.owl.model.impl;

import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protegex.owl.model.OWLDatatypeProperty;
import edu.stanford.smi.protegex.owl.model.visitor.OWLModelVisitor;

/**
 * The default implementation of the OWLDatatypeProperty interface.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultOWLDatatypeProperty extends AbstractOWLProperty implements OWLDatatypeProperty {

    public final static String ICON_NAME = "OWLDatatypeProperty";


    public DefaultOWLDatatypeProperty(KnowledgeBase kb, FrameID id) {
        super(kb, id);
    }


    public DefaultOWLDatatypeProperty() {
    }


    public boolean hasDatatypeRange() {
        return true;
    }


	public void accept(OWLModelVisitor visitor) {
		visitor.visitOWLDatatypeProperty(this);
	}
}
