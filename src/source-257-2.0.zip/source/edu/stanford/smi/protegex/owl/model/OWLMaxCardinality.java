package edu.stanford.smi.protegex.owl.model;


/**
 * A Cls representing a maximumCardinality restriction.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLMaxCardinality extends OWLCardinalityBase {

}
