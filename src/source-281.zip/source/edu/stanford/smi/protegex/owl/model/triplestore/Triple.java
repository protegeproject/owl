package edu.stanford.smi.protegex.owl.model.triplestore;

import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFResource;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface Triple {

    RDFResource getSubject();


    RDFProperty getPredicate();


    Object getObject();
}
