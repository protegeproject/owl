package edu.stanford.smi.protegex.owl.jena.parser.tests;

import com.hp.hpl.jena.ontology.OntModel;
import edu.stanford.smi.protegex.owl.ProtegeOWL;
import edu.stanford.smi.protegex.owl.jena.Jena;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.jena.parser.ProtegeOWLParser;
import edu.stanford.smi.protegex.owl.tests.AbstractOWLTestCase;

import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.net.URI;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public abstract class AbstractProtegeOWLParserTestCase extends AbstractOWLTestCase {


    public void loadRemoteOntology(String localFileName) throws Exception {
        loadTestOntology(getRemoteOntologyURI(localFileName));
    }


    public void loadTestOntology(URI uri) throws Exception {
        // Jena2Protege.fillOWLModel(uri, owlModel);
        ProtegeOWLParser arp = new ProtegeOWLParser(owlModel, false);
        arp.run(uri);
    }


    public static JenaOWLModel reload(JenaOWLModel owlModel) throws Exception {
        JenaOWLModel newModel = ProtegeOWL.createJenaOWLModel();
        OntModel ontModel = owlModel.getOntModel();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        Jena.dumpRDF(ontModel, stream);
        String str = stream.toString();
        StringReader reader = new StringReader(str);
        new ProtegeOWLParser(newModel, false).run(reader, owlModel.getNamespaceManager().getDefaultNamespace());
        return newModel;

        //List graphs = ontModel.getSubGraphs();
        //Graph lastGraph = ((Graph) graphs.get(graphs.size() - 1));
        //Model lastModel = ModelFactory.createModelForGraph(lastGraph);
        //ontModel.removeSubModel(lastModel);
        //Jena2Protege.fillOWLModel(ontModel, newModel);
    }
}
