package edu.stanford.smi.protegex.owl.jena;

import java.net.URI;
import java.net.URL;

/**
 * An interface for objects used by the ProtegeOWLParser to convert logical URIs to physical URLs.
 * This is used to redirect imports and file loading in general, and to determine the file to save
 * a model into.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface URIResolver {


    /**
     * Converts a logical URI into a physical URL.
     *
     * @param uri the logical URI
     * @return the physical URL (often the same as url)
     */
    URL getPhysicalURL(URI uri);


    /**
     * If the result of <CODE>getPhysicalURL()</CODE> is internally derived from a
     * relative file, then this returns the relative file name.
     *
     * @param uri the logical URI
     * @return the relative file name or null if the URL is absolute
     */
    String getRelativePhysicalFileName(URI uri);


    /**
     * Gets the prefix that should be used for a namespace if no other prefix
     * has been defined yet.  If no such entry is found during loading, the system
     * will generate one automatically (e.g., "p1").
     *
     * @param namespace the namespace to get a prefix for (including '#')
     * @return a valid, non-empty namespace prefix or null for default
     */
    String getPreferredNamespacePrefix(String namespace);


    /**
     * Checks if a given import is editable for the current OWLModel.
     * This is used to determine whether a given TripleStore shall be editable or not.
     * Not editable TripleStores will not be saved to disc.
     * If the method returns true, then there must be a physical file URL for the URI.
     *
     * @param uri the URI of the import (usually the name of the associated TripleStore)
     * @return true  if uri points to an editable file
     */
    boolean isEditableImport(URI uri);


    void setEditableImport(URI uri, boolean value);


    /**
     * Sets the physical URL of an URI.
     *
     * @param uri         the URI to set the URL of
     * @param physicalURL the new physcial URL or null to reset this URI
     */
    void setPhysicalURL(URI uri, URL physicalURL);


    /**
     * Sets the physical URL of an URI to point to a relative file.
     *
     * @param uri              the URI to set the URL of
     * @param relativeFileName the name of the file (not null)
     */
    void setPhysicalURL(URI uri, String relativeFileName);
}
