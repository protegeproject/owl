package edu.stanford.smi.protegex.owl.model.impl.tests;

import edu.stanford.smi.protegex.owl.model.OWLEnumeratedClass;
import edu.stanford.smi.protegex.owl.model.OWLIndividual;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.RDFList;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultOWLEnumeratedClassTestCase extends AbstractJenaTestCase {

    public void testCreateEnumeratedClass() {
        OWLNamedClass cls = owlModel.createOWLNamedClass("Class");
        OWLIndividual a = cls.createOWLIndividual("a");
        OWLIndividual b = cls.createOWLIndividual("b");
        OWLEnumeratedClass enum = owlModel.createOWLEnumeratedClass();
        assertNull(enum.getPropertyValue(owlModel.getOWLOneOfProperty()));
        enum.addOneOf(a);
        enum.addOneOf(b);
        assertSize(2, enum.getOneOf());
        assertContains(a, enum.getOneOf());
        assertContains(b, enum.getOneOf());
        assertSize(1, enum.getPropertyValues(owlModel.getOWLOneOfProperty()));
        RDFList list = (RDFList) enum.getPropertyValue(owlModel.getOWLOneOfProperty());
        assertEquals(a, list.getFirst());
        assertEquals(b, list.getRest().getFirst());
        assertSize(2, list.getValues());
    }
}
