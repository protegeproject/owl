package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.net.URI;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadICalTestCase extends AbstractJenaTestCase {

    public void testLoadICalOntology() throws Exception {
        loadTestOntologyWithJenaLoader(new URI("http://www.w3.org/2002/12/cal/ical"));
    }
}
