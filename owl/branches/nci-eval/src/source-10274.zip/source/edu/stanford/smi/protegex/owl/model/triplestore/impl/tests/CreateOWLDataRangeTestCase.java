package edu.stanford.smi.protegex.owl.model.triplestore.impl.tests;

import edu.stanford.smi.protegex.owl.model.OWLDataRange;
import edu.stanford.smi.protegex.owl.model.RDFList;
import edu.stanford.smi.protegex.owl.model.RDFResource;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class CreateOWLDataRangeTestCase extends AbstractTripleStoreTestCase {


    public void testCreateDataRange() {
        RDFResource dataRange = createRDFResource(null);
        ts.add(dataRange, owlModel.getRDFTypeProperty(), owlModel.getOWLDataRangeClass());
        RDFResource firstNode = createRDFResource(null);
        ts.add(dataRange, owlModel.getOWLOneOfProperty(), firstNode);
        RDFResource secondNode = createRDFResource(null);
        ts.add(firstNode, owlModel.getRDFFirstProperty(), "A");
        ts.add(firstNode, owlModel.getRDFRestProperty(), secondNode);
        ts.add(secondNode, owlModel.getRDFFirstProperty(), "B");
        ts.add(secondNode, owlModel.getRDFRestProperty(), owlModel.getRDFNil());
        owlModel.getTripleStoreModel().endTripleStoreChanges();
        OWLDataRange owlDataRange = (OWLDataRange) owlModel.getRDFResource(dataRange.getName());
        assertTrue(owlModel.getRDFResource(firstNode.getName()) instanceof RDFList);
    }
}
