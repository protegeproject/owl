package edu.stanford.smi.protegex.owl.javacode;

import edu.stanford.smi.protege.model.Project;

import java.io.File;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class ProjectBasedJavaCodeGeneratorOptions implements EditableJavaCodeGeneratorOptions {

    public final static String ABSTRACT_MODE = "JavaCodeAbstract";

    public final static String FACTORY_CLASS_NAME = "JavaCodeFactoryClassName";

    public final static String FILE_NAME = "JavaCodeFileName";

    public final static String PACKAGE = "JavaCodePackage";

    public final static String SET_MODE = "JavaCodeSet";

    private Project project;


    public ProjectBasedJavaCodeGeneratorOptions(Project project) {
        this.project = project;
    }


    public boolean getAbstractMode() {
        Boolean b = project.getSources().getBoolean(ABSTRACT_MODE);
        if (b != null) {
            return b.booleanValue();
        }
        else {
            return false;
        }
    }


    public String getFactoryClassName() {
        String value = project.getSources().getString(FACTORY_CLASS_NAME);
        if (value == null) {
            return "MyFactory";
        }
        else {
            return value;
        }
    }


    public File getOutputFolder() {
        String fileName = project.getSources().getString(FILE_NAME);
        if (fileName == null) {
            return new File("");
        }
        else {
            return new File(fileName);
        }
    }


    public String getPackage() {
        return project.getSources().getString(PACKAGE);
    }


    public boolean getSetMode() {
        Boolean b = project.getSources().getBoolean(SET_MODE);
        if (b != null) {
            return b.booleanValue();
        }
        else {
            return false;
        }
    }


    public void setAbstractMode(boolean value) {
        project.getSources().setBoolean(ABSTRACT_MODE, value);
    }


    public void setOutputFolder(File file) {
        if (file == null) {
            project.getSources().remove(FILE_NAME);
        }
        else {
            project.getSources().setString(FILE_NAME, file.getAbsolutePath());
        }
    }


    public void setFactoryClassName(String value) {
        if (value == null || value.length() == 0) {
            project.getSources().remove(FACTORY_CLASS_NAME);
        }
        else {
            project.getSources().setString(FACTORY_CLASS_NAME, value);
        }
    }


    public void setPackage(String value) {
        if (value == null || value.length() == 0) {
            project.getSources().remove(PACKAGE);
        }
        else {
            project.getSources().setString(PACKAGE, value);
        }
    }


    public void setSetMode(boolean value) {
        project.getSources().setBoolean(SET_MODE, value);
    }
}
