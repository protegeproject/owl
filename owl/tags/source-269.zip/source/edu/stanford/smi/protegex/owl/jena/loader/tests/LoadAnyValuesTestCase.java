package edu.stanford.smi.protegex.owl.jena.loader.tests;

import com.hp.hpl.jena.ontology.Individual;
import com.hp.hpl.jena.ontology.OntProperty;
import edu.stanford.smi.protege.model.ValueType;
import edu.stanford.smi.protegex.owl.model.RDFIndividual;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadAnyValuesTestCase extends AbstractJenaTestCase {


    public void testLoadAnyValues() throws Exception {
        loadRemoteOntology("any-values.owl");
        RDFProperty slot = owlModel.getRDFProperty("slot");
        RDFIndividual instance = owlModel.getRDFIndividual("instance");
        Individual individual = ontModel.getIndividual(instance.getURI());
        OntProperty property = ontModel.getOntProperty(slot.getURI());
        assertSize(4, individual.listPropertyValues(property));
        assertHasValue(individual, property, ValueType.BOOLEAN, Boolean.TRUE);
        assertHasValue(individual, property, ValueType.FLOAT, new Float(4.2));
        assertHasValue(individual, property, ValueType.INTEGER, new Integer(42));
        assertHasValue(individual, property, ValueType.STRING, "Holgi");
    }
}
