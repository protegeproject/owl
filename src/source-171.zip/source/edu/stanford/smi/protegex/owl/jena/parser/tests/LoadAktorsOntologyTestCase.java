package edu.stanford.smi.protegex.owl.jena.parser.tests;

import java.net.URI;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadAktorsOntologyTestCase extends AbstractProtegeOWLParserTestCase {

    public void testLoadPortal() throws Exception {
        loadTestOntology(new URI("http://www.aktors.org/ontology/portal"));
    }
}
