package edu.stanford.smi.protegex.owl.swrl.model;

import edu.stanford.smi.protegex.owl.model.OWLDatatypeProperty;

/**
 * @author Martin O'Connor  <moconnor@smi.stanford.edu>
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface SWRLDatavaluedPropertyAtom extends SWRLAtom {

    SWRLVariable getArgument1();


    void setArgument1(SWRLVariable variable);


    Object getArgument2();


    void setArgument2(Object value);


    OWLDatatypeProperty getPropertyPredicate();


    void setPropertyPredicate(OWLDatatypeProperty datatypeSlot);

} // SWRLDatavaluedPropertyAtom
