package edu.stanford.smi.protegex.owl.model;

import java.util.Collection;


/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface RDFSNamedClass extends RDFSClass, Deprecatable {

    /**
     * Creates an instance of this class so that Protege will recognize
     * this as an "anonymous" node in the RDF rendering.  Protege uses
     * an internal naming convention to simulate anonymous nodes.
     *
     * @return a new, anonymous instance of this
     * @see OWLModel#getNextAnonymousResourceName
     * @see OWLModel#isAnonymousResource
     */
    RDFResource createAnonymousInstance();


    /**
     * Creates a new individual of this (assuming this is not a metaclass).
     *
     * @param name the name of the new instance or null for a default value
     * @return the new instance
     */
    RDFIndividual createRDFIndividual(String name);


    /**
     * Gets the allowed classes for a given property at this class.
     * This assumes that the property takes objects as values.
     * The method tests whether an allValuesFrom restriction has been
     * defined on this class, and resolves this into a collection if the
     * restriction has a union class as filler.
     * If no restriction could be found in the inheritance hierarchy, the
     * method looks for a global range restriction for the property.
     *
     * @param property the property to get the local range of
     * @return a Collection of RDFSClasses
     */
    Collection getUnionRangeClasses(RDFProperty property);


    /**
     * Checks whether this and a path to the root class is visible.
     *
     * @return true if visible
     */
    boolean isVisibleFromOWLThing();
}
