package edu.stanford.smi.protegex.owl.swrl.model;

import edu.stanford.smi.protegex.owl.model.RDFSClass;

/**
 * @author Martin O'Connor  <moconnor@smi.stanford.edu>
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface SWRLClassAtom extends SWRLAtom {

    SWRLVariable getArgument1();


    void setArgument1(SWRLVariable variable);


    RDFSClass getClassPredicate();


    void setClassPredicate(RDFSClass aClass);

} // SWRLBuiltinAtom
