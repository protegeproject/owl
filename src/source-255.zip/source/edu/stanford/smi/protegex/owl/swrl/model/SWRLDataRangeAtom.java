package edu.stanford.smi.protegex.owl.swrl.model;

import edu.stanford.smi.protege.model.Instance;

/**
 * @author Martin O'Connor  <moconnor@smi.stanford.edu>
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface SWRLDataRangeAtom extends SWRLAtom {

    SWRLVariable getArgument1();


    void setArgument1(SWRLVariable variable);


    Instance getDataRange();


    void setDataRange(Instance dataRange);

} // SWRLDataRangeAtom
