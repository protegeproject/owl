package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.OWLOntology;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.util.Collection;
import java.util.Iterator;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadImportsTestCase extends AbstractJenaTestCase {

    public void testLoadImports() throws Exception {
        loadRemoteOntologyWithJenaLoader("import-demo.owl");
        assertEquals("http://protege.stanford.edu/plugins/owl/owl-library/import-demo.owl#",
                owlModel.getNamespaceManager().getDefaultNamespace());
        assertNotNull(owlModel.getOWLNamedClass("RottnestIslandQuokka"));
        assertNotNull(owlModel.getOWLNamedClass("koala:Quokka"));
        Collection ontologies = owlModel.getOWLOntologies();
        assertSize(2, ontologies);
        assertContains(owlModel.getDefaultOWLOntology(), ontologies);
        Collection imports = owlModel.getDefaultOWLOntology().getImports();
        for (Iterator it = imports.iterator(); it.hasNext();) {
            Object o = it.next();
            assertTrue(o instanceof String);
        }
        OWLOntology oi = owlModel.getOWLOntologyByURI("http://protege.stanford.edu/plugins/owl/owl-library/koala.owl");
        assertNotNull(oi);
        assertContains(oi, ontologies);
        OWLNamedClass koalaCls = owlModel.getOWLNamedClass("koala:Koala");
        assertNotNull(koalaCls);
    }


    public void testLoadUglyImport() throws Exception {
        loadRemoteOntologyWithJenaLoader("uglyImport.owl");
        assertNotNull(owlModel.getRDFSNamedClass("travel:Destination"));
        assertEquals("http://aldi.de/ont/", owlModel.getNamespaceManager().getDefaultNamespace());
        OWLOntology oi = owlModel.getDefaultOWLOntology();
        assertSize(1, oi.getImports());
    }
}
