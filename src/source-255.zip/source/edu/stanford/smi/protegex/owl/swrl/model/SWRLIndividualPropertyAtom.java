package edu.stanford.smi.protegex.owl.swrl.model;

import edu.stanford.smi.protegex.owl.model.OWLObjectProperty;

/**
 * @author Martin O'Connor  <moconnor@smi.stanford.edu>
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface SWRLIndividualPropertyAtom extends SWRLAtom {

    SWRLVariable getArgument1();


    void setArgument1(SWRLVariable variable);


    SWRLVariable getArgument2();


    void setArgument2(SWRLVariable variable);


    OWLObjectProperty getPropertyPredicate();


    void setPropertyPredicate(OWLObjectProperty objectSlot);

} // SWRLIndividualPropertyAtom
