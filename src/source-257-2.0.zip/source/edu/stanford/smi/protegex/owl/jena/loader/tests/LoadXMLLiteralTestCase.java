package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.model.OWLDatatypeProperty;
import edu.stanford.smi.protegex.owl.model.impl.XMLSchemaDatatypes;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadXMLLiteralTestCase extends AbstractJenaTestCase {

    /*public void loadXMLLiteralInJena() throws Exception {
        OntModel m = ModelFactory.createOntologyModel();
        m.read("http://www.w3.org/2002/03owlt/miscellaneous/consistent205");
        //m.read("http://protege.stanford.edu/plugins/owl/testdata/XMLLiteralValue.owl");
        String language = FileUtils.langXMLAbbrev;
        String namespace = m.getNsPrefixURI("");
        RDFWriter writer = m.getWriter(language);
        writer.write(m.getBaseModel(), System.out, namespace);
    } */


    public void testLoadXMLLiteral() throws Exception {
        loadRemoteOntology("XMLLiteralValue.owl");
        OWLDatatypeProperty slot = (OWLDatatypeProperty) owlModel.getSlot("anno");
        assertEquals(owlModel.getRDFXMLLiteralType(), slot.getRange());
        assertTrue(XMLSchemaDatatypes.isXMLLiteralSlot(slot));
        assertSize(1, slot.getPropertyValues(slot));
        final Object value = slot.getPropertyValue(slot);
        assertEquals("<P>Value</P>", value);
    }
}
