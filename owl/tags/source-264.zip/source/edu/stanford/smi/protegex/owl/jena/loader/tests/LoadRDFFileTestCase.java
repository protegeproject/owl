package edu.stanford.smi.protegex.owl.jena.loader.tests;

import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntProperty;
import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.net.URI;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadRDFFileTestCase extends AbstractJenaTestCase {

    public void testLoadFOAF() throws Exception {
        loadTestOntology(new URI("http://xmlns.com/foaf/0.1/index.rdf"));
    }


    public void testLoadRDF() throws Exception {
        loadRemoteOntology("rdf-test.owl");
        RDFSNamedClass animalCls = owlModel.getRDFSNamedClass("Animal");
        assertTrue(animalCls instanceof RDFSNamedClass);
        assertFalse(animalCls instanceof OWLNamedClass);
        OntClass animalClass = ontModel.getOntClass(animalCls.getURI());
        assertNotNull(animalClass);
        RDFProperty hasChildrenProperty = owlModel.getRDFProperty("hasChildren");
        assertTrue(hasChildrenProperty instanceof RDFProperty);
        assertFalse(hasChildrenProperty instanceof OWLProperty);
        OntProperty hasChildrenOntProperty = ontModel.getOntProperty(hasChildrenProperty.getURI());
        assertNotNull(hasChildrenOntProperty);
        RDFIndividual purzel = owlModel.getRDFIndividual("Purzel");
        assertEquals(animalCls, purzel.getProtegeType());
        Instance susie = owlModel.getInstance("Susie");
        assertEquals(animalCls, susie.getDirectType());
        assertSize(1, purzel.getPropertyValues(hasChildrenProperty));
        assertEquals(susie, purzel.getPropertyValue(hasChildrenProperty));
    }
}
