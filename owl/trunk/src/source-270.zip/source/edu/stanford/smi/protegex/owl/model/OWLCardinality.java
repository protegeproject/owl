package edu.stanford.smi.protegex.owl.model;


/**
 * A class representing an owl:cardinality restriction.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLCardinality extends OWLCardinalityBase {

}
