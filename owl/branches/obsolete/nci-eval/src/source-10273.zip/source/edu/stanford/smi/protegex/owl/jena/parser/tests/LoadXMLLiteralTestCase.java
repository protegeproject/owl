package edu.stanford.smi.protegex.owl.jena.parser.tests;

import edu.stanford.smi.protegex.owl.model.OWLDatatypeProperty;
import edu.stanford.smi.protegex.owl.model.RDFSLiteral;
import edu.stanford.smi.protegex.owl.model.impl.XMLSchemaDatatypes;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadXMLLiteralTestCase extends AbstractProtegeOWLParserTestCase {

    /*public void loadXMLLiteralInJena() throws Exception {
        OntModel m = ModelFactory.createOntologyModel();
        m.read("http://www.w3.org/2002/03owlt/miscellaneous/consistent205");
        //m.read("http://protege.stanford.edu/plugins/owl/testdata/XMLLiteralValue.owl");
        String language = FileUtils.langXMLAbbrev;
        String namespace = m.getNsPrefixURI("");
        RDFWriter writer = m.getWriter(language);
        writer.write(m.getBaseModel(), System.out, namespace);
    } */


    public void testLoadXMLLiteral() throws Exception {
        loadRemoteOntology("XMLLiteralValue.owl");
        OWLDatatypeProperty slot = (OWLDatatypeProperty) owlModel.getSlot("anno");
        assertEquals(owlModel.getRDFXMLLiteralType(), slot.getRange());
        assertTrue(XMLSchemaDatatypes.isXMLLiteralSlot(slot));
        assertSize(1, slot.getPropertyValues(slot));
        final Object value = slot.getPropertyValue(slot);
        assertTrue(value instanceof RDFSLiteral);
        RDFSLiteral literal = (RDFSLiteral) value;
        assertEquals(owlModel.getRDFXMLLiteralType(), literal.getDatatype());
        // assertEquals("<P>Value</P>", value);
    }
}
