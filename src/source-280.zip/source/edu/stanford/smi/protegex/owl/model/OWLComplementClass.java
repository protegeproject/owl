package edu.stanford.smi.protegex.owl.model;

/**
 * A OWLLogicalClass to represent a complement.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLComplementClass extends OWLLogicalClass {

    RDFSClass getComplement();


    void setComplement(RDFSClass complement);
}
