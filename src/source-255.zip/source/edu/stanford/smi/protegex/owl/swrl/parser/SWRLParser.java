package edu.stanford.smi.protegex.owl.swrl.parser;

import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.impl.XMLSchemaDatatypes;
import edu.stanford.smi.protegex.owl.swrl.model.*;

import java.util.*;

/**
 * @author Martin O'Connor  <moconnor@smi.stanford.edu>
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class SWRLParser {

    public final static char AND_CHAR = '\u2227';   // ^

    public final static char IMP_CHAR = '\u2192';   // >

    private OWLModel owlModel;

    private SWRLFactory swrlFactory;

    private boolean parseOnly;

    private StringTokenizer tokenizer;

    private String delimiters = " ?\n\t()[],\"" + AND_CHAR + IMP_CHAR;

    private Collection xmlSchemaSymbols = XMLSchemaDatatypes.getSlotSymbols();

    private HashMap variables;


    public SWRLParser(OWLModel okb) {
        this.owlModel = okb;
        swrlFactory = new SWRLFactory(okb);
        parseOnly = true;
        variables = new HashMap();
    } // SWRLParser


    public void setParseOnly(boolean parseOnly) {
        this.parseOnly = parseOnly;
    } // setParseOnly

    // This parser will throw a SWRLParseException if it finds errors in
    // the supplied rule. If the rule is correct but incomplete, a
    // SWRLIncompleteRuleException (which is a subclass of
    // SWRLParseException) will be thrown.
    //
    // If parseOnly is true, only checking is performed - no OWL
    // individuals are created; if it is false, instances are created.

    public SWRLImp parse(String rule) throws SWRLParseException {
        return parse(rule, null);
    } // parse


    public SWRLImp parse(String rule, SWRLImp imp) throws SWRLParseException {
        String token;
        SWRLAtomList head = null, body = null;
        SWRLAtom atom;
        boolean atLeastOneAtom = false, inHead = false, processedFinalAtom = false;

        // rule = getParsableRuleString(rule);
        
        variables.clear();

        tokenizer = new StringTokenizer(rule, delimiters, true);

        if (!parseOnly) {
            head = swrlFactory.createAtomList();
            body = swrlFactory.createAtomList();
        } // if

        if (!parseOnly && !tokenizer.hasMoreTokens()) {
            throw new SWRLParseException("Empty rule.");
        }

        while (tokenizer.hasMoreTokens()) {

            token = getNextNonSpaceToken("Expecting atom.");

            atom = parseAtom(token);

            atLeastOneAtom = true;
            if (inHead) {
                processedFinalAtom = true;
            }

            if (!parseOnly) {
                if (inHead) {
                    head.append(atom);
                }
                else {
                    body.append(atom);
                }
            } // if

            if (processedFinalAtom) {
                if (hasMoreNonSpaceTokens()) {
                    throw new SWRLParseException("Extra text after rule.");
                }
                break;
            } // if

            token = getNextNonSpaceToken("Expecting '" + AND_CHAR +
                    "' or '" + IMP_CHAR + "'.");

            if (token.equals("" + IMP_CHAR)) {
                if (!atLeastOneAtom) {
                    throw new SWRLParseException("Rule must have at least one antecedent atom.");
                }
                if (inHead) {
                    throw new SWRLParseException("Only one consequent allowed.");
                }
                inHead = true;
            }
            else if (token.equals("-") || token.equals("->")) {
                // Ignore "->" while we build up IMP_CHAR.
            }
            else if (!token.equals("" + AND_CHAR)) {
                throw new SWRLParseException("Expecting '" + AND_CHAR +
                        "' or '" + IMP_CHAR + "' between atoms - got '" + token + "'.");
            } // if

        } // while

        if (!parseOnly) {
            if (!processedFinalAtom) {
                throw new SWRLParseException("Incomplete rule - no consequent part.");
            }
            if (imp == null) {
                imp = swrlFactory.createImp(head, body);
            }
            else {
                imp.setHead(head);
                imp.setBody(body);
            }
        }
        else {
            imp = null;
        }

        return imp;
    } // parse


    //public static String getParsableRuleString(String unicodeRule) {
    //    return unicodeRule.replace(AND_CHAR, '^').replace(IMP_CHAR, '>');
    //}


    private SWRLAtom parseAtom(String identifier)
            throws SWRLParseException {
        SWRLAtom atom = null;
        List enumeratedList = null;
        boolean isEnumeratedList = false;

        if (!isValidIdentifier(identifier)) throw new SWRLParseException("Invalid identifier: '" + identifier + "'.");

        if (identifier.startsWith("[")) { // A data range with an enumerated literal list
            enumeratedList = parseLiteralList();
            isEnumeratedList = true;
        } // if

        if (isEnumeratedList)
            checkAndSkipToken("(", "Expecting parameters enclosed in parentheses for data range atom.");
        else
            checkAndSkipToken("(", "Expecting parameters enclosed in parentheses for atom '" + identifier + "'.");

        if (isEnumeratedList) {
            atom = parseEnumeratedListParameters(enumeratedList);
        }
        else if (isSameAs(identifier)) {
            atom = parseSameAsAtomParameters();
        }
        else if (isDifferentFrom(identifier)) {
            atom = parseDifferentFromAtomParameters();
        }
        else if (isOWLClassName(identifier)) {
            atom = parseClassAtomParameters(identifier);
        }
        else if (isOWLObjectPropertyName(identifier)) {
            atom = parseIndividualPropertyAtomParameters(identifier);
        }
        else if (isOWLDatatypePropertyName(identifier)) {
            atom = parseDatavaluedPropertyAtomParameters(identifier);
        }
        else if (isBuiltinName(identifier)) {
            atom = parseBuiltinParameters(identifier);
        }
        else if (isXSDDatatype(identifier)) {
            atom = parseXSDDatatypeParameters(identifier);
        }
        else {
            throw new SWRLParseException("Invalid atom name '" + identifier + "'.");
        } // if

        return atom;
    } // parseAtom


    private void checkAndSkipToken(String skipToken, String unexpectedTokenMessage)
            throws SWRLParseException {
        String token = getNextNonSpaceToken(unexpectedTokenMessage);

        if (!token.equalsIgnoreCase(skipToken)) throw new SWRLParseException("Expecting '" + skipToken + "', got '" + token + "'. " + unexpectedTokenMessage);

    } // checkAndSkipToken


    private String getNextNonSpaceToken(String noTokenMessage)
            throws SWRLParseException {
        String token = "";
        String errorMessage = "Incomplete rule. " + noTokenMessage;

        if (!tokenizer.hasMoreTokens()) {
            if (parseOnly)
                throw new SWRLIncompleteRuleException(errorMessage);
            else
                throw new SWRLParseException(errorMessage);
        } // if

        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken(delimiters);
            if (!(token.equals(" ") || token.equals("\n") || token.equals("\t"))) return token;
        } // while

        if (parseOnly) {
            throw new SWRLIncompleteRuleException(errorMessage);
        }
        else {
            throw new SWRLParseException(errorMessage); // Should not get here
        }

    } // getNextNonSpaceToken


    private boolean hasMoreNonSpaceTokens() {

        if (!tokenizer.hasMoreTokens()) {
            return false;
        }

        while (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken(delimiters);
            if (!(token.equals(" ") || token.equals("\n") || token.equals("\t"))) {
                return true;
            }
        } // while

        return false;

    } // hasMoreNonSpaceTokens


    private SWRLAtom parseSameAsAtomParameters()
            throws SWRLParseException {
        SWRLVariable variable1, variable2;
        SWRLAtom atom = null;

        variable1 = parseVariable();
        checkAndSkipToken(",", "Expecting comma-separated second parameter for SameAsAtom.");
        variable2 = parseVariable();

        if (!parseOnly) {
            atom = swrlFactory.createSameIndividualAtom(variable1, variable2);
        } // if

        checkAndSkipToken(")", "Expecting closing parenthesis after second parameters in SameAsAtom");

        return atom;
    } // parseSameAsAtomParameters


    private SWRLAtom parseDifferentFromAtomParameters()
            throws SWRLParseException {
        SWRLVariable variable1, variable2;
        SWRLAtom atom = null;

        variable1 = parseVariable();
        checkAndSkipToken(",", "Expecting comma-separated second parameters for DifferentFromAtom");
        variable2 = parseVariable();

        if (!parseOnly) {
            atom = swrlFactory.createDifferentIndividualsAtom(variable1, variable2);
        } // if

        checkAndSkipToken(")", "Only two parameters allowed for DifferentFromAtom");

        return atom;
    } // parseDifferentFromAtomParameters


    private SWRLAtom parseClassAtomParameters(String identifier)
            throws SWRLParseException {
        SWRLVariable variable1;
        SWRLAtom atom = null;
        RDFSNamedClass aClass;

        variable1 = parseVariable();

        if (!parseOnly) {
            aClass = owlModel.getOWLNamedClass(identifier);
            atom = swrlFactory.createClassAtom(aClass, variable1);
        } // if

        checkAndSkipToken(")", "Expecting closing parenthesis for parameter for ClassAtom '" + identifier + "'.");

        return atom;
    } // parseClassAtomParameters


    private SWRLAtom parseIndividualPropertyAtomParameters(String identifier)
            throws SWRLParseException {
        SWRLVariable variable1, variable2;
        SWRLAtom atom = null;
        OWLObjectProperty objectSlot;

        variable1 = parseVariable();
        checkAndSkipToken(",", "Expecting comma-separated second parameter for IndividualPropertyAtom '" + identifier + "'");
        variable2 = parseVariable();

        if (!parseOnly) {
            objectSlot = owlModel.getOWLObjectProperty(identifier);
            if (objectSlot == null) throw new SWRLParseException("no datatype slot found for IndividualPropertyAtom: " + identifier);
            atom = swrlFactory.createIndividualPropertyAtom(objectSlot, variable1, variable2);
        } // if

        checkAndSkipToken(")", "Expecting closing parenthesis after second parameter of IndividualPropertyAtom '" + identifier + "'.");

        return atom;
    } // parseClassAtomParameters

    // TODO: clarify parsing of second parameter - SWRLVariable,
    // rdfs:literal, or both. For the moment, we just allow
    // SWRLVariables.

    private SWRLAtom parseDatavaluedPropertyAtomParameters(String identifier)
            throws SWRLParseException {
        SWRLVariable variable1, variable2;
        SWRLAtom atom = null;
        //        Object literalValue;
        OWLDatatypeProperty datatypeSlot;

        variable1 = parseVariable();
        checkAndSkipToken(",", "Expecting comma-separated second parameter for DatavaluedPropertyAtom '" + identifier + "'.");
        //        literalValue = parseLiteralValue();
        variable2 = parseVariable();

        if (!parseOnly) {
            datatypeSlot = owlModel.getOWLDatatypeProperty(identifier);
            //            atom = swrlFactory.createDatavaluedPropertyAtom(datatypeSlot, variable1, literalValue);
            atom = swrlFactory.createDatavaluedPropertyAtom(datatypeSlot, variable1, variable2);
        } // if

        checkAndSkipToken(")", "Expecting closing parenthesis after second parameter of DatavaluedPropertyAtom '" + identifier + "'.");

        return atom;
    } // parseDatavaluedPropertyAtomParameters


    private SWRLAtom parseBuiltinParameters(String identifier)
            throws SWRLParseException {
        SWRLVariable variable;
        SWRLBuiltin builtin;
        SWRLAtom atom = null;
        List variables = new ArrayList();

        variables = parseVariableList(); // Swallows ')'

        if (!parseOnly) {
            builtin = swrlFactory.getBuiltin(identifier);
            atom = swrlFactory.createBuiltinAtom(builtin, variables.iterator());
        } // if

        return atom;
    } // parseBuiltinParameters


    private SWRLAtom parseXSDDatatypeParameters(String identifier)
            throws SWRLParseException {
        SWRLVariable variable;
        SWRLAtom atom = null;
        RDFExternalResource eri;

        variable = parseVariable();

        if (!parseOnly) {
            eri = owlModel.createRDFExternalResource(identifier); // TODO - check for duplication
            atom = swrlFactory.createDataRangeAtom(eri, variable);
        } // if

        checkAndSkipToken(")", "Expecting closing parenthesis after DataRangeAtom '" + identifier + "'.");

        return atom;
    } // parseXSDDatatypeParameters


    private SWRLAtom parseEnumeratedListParameters(List enumeratedList)
            throws SWRLParseException {
        SWRLVariable variable;
        SWRLAtom atom = null;
        Object literalValue;
        Iterator iterator;

        variable = parseVariable();

        if (!parseOnly) {

            OWLDataRange dataRange = owlModel.createOWLDataRange();
            RDFProperty oneOfProperty = owlModel.getOWLOneOfProperty();

            iterator = enumeratedList.iterator();
            while (iterator.hasNext()) {
                literalValue = (Object) iterator.next();
                dataRange.addPropertyValue(oneOfProperty, literalValue);
            } // while
            atom = swrlFactory.createDataRangeAtom(dataRange, variable);

        } // if

        checkAndSkipToken(")", "Expecting closing parenthesis after parameter in DataRangeAtom.");

        return atom;
    } // parseEnumeratedListParameters


    private List parseVariableList()
            throws SWRLParseException {
        SWRLVariable variable;
        List variables = null;
        String token;

        if (!parseOnly) variables = new ArrayList();

        variable = parseVariable();

        if (!parseOnly) variables.add(variable);

        token = getNextNonSpaceToken("Expecting additional comma-separated variables or end of variable list.");
        while (token.equals(",")) {
            variable = parseVariable();
            if (!parseOnly) variables.add(variable);

            token = getNextNonSpaceToken("Expecting ',' or ')'.");

            if (!(token.equals(",") || token.equals(")"))) throw new SWRLParseException("Expecting ',' or ')', got '" + token + "'.");
        } // if

        return variables;

    } // parseVariableList


    private List parseLiteralList()
            throws SWRLParseException {
        Object literalValue;
        List literals = null;
        String token;

        if (!parseOnly) literals = new ArrayList();

        literalValue = parseLiteralValue();
        if (!parseOnly) literals.add(literalValue);

        token = getNextNonSpaceToken("Expecting additional comma-separated literals or end of literal list.");

        while (token.equals(",")) {
            literalValue = parseLiteralValue();
            if (!parseOnly) literals.add(literalValue);
            token = getNextNonSpaceToken("Expecting additional comma-separated literals or end of literal list.");

            if (!(token.equals(",") || token.equals("]"))) throw new SWRLParseException("Expecting ',' or ']', got '" + token + "'.");
        } // if

        return literals;

    } // parseLiteralList


    private SWRLVariable parseVariable()
            throws SWRLParseException {
        SWRLVariable variable = null;
        String variableName;

        checkAndSkipToken("?", "Expecting variable name preceded by '?'.");

        variableName = getNextNonSpaceToken("Expecting variable name.");

        if (!isValidIdentifier(variableName)) throw new SWRLParseException("Invalid variable name: '" + variableName + "'.");

        if (!parseOnly) variable = getSWRLVariable(variableName);

        return variable;
    } // parseVariable

    // TODO: Handle escaped quote characters? Literal may also be an integer.

    private Object parseLiteralValue()
            throws SWRLParseException {
        String literalValue = null;
        String token;

        checkAndSkipToken("\"", "Quotation enclosed literal value expected.");

        // Original delimiters will be restored in next call to getNextNonSpaceToken().
        if (!tokenizer.hasMoreTokens()) {
            if (parseOnly)
                throw new SWRLParseException("");
            else
                throw new SWRLParseException("Expecting literal value after quote - got nothing.");
        } // if

        token = tokenizer.nextToken("\"");

        if (token.equals("")) {
            if (parseOnly)
                throw new SWRLParseException("");
            else
                throw new SWRLParseException("Expecting literal value after quote - got nothing.");
        } // if

        if (token.equals("\"")) { // Empty literal
            if (!parseOnly) literalValue = "";
        }
        else {
            if (!parseOnly) literalValue = new String(token);

            checkAndSkipToken("\"", "Expecting '\"' to close literal value '" + literalValue + "'.");
        } // if

        return literalValue;
    } // parseLiteralValue


    private boolean isSameAs(String identifier)
            throws SWRLParseException {
        return identifier.equalsIgnoreCase("sameAs");
    } // isSameAs


    private boolean isDifferentFrom(String identifier)
            throws SWRLParseException {
        return identifier.equalsIgnoreCase("differentFrom");
    } // isDifferentFrom


    private boolean isOWLClassName(String identifier)
            throws SWRLParseException {
        return owlModel.getRDFResource(identifier) instanceof RDFSNamedClass;
    } // isOWLClassName


    private boolean isOWLObjectPropertyName(String identifier)
            throws SWRLParseException {
        return owlModel.getRDFResource(identifier) instanceof OWLObjectProperty;
    } // isOWLObjectPropertyName


    private boolean isOWLDatatypePropertyName(String identifier)
            throws SWRLParseException {
        return owlModel.getRDFResource(identifier) instanceof OWLDatatypeProperty;
    } // isOWLDatatypePropertyName


    private boolean isBuiltinName(String identifier)
            throws SWRLParseException {
        RDFResource resource = owlModel.getRDFResource(identifier);
        return resource != null && resource.getProtegeType().getName().equals(SWRLNames.Cls.BUILTIN);
    } // isBuiltinName


    private boolean isXSDDatatype(String identifier)
            throws SWRLParseException {

        return (identifier.startsWith("xsd:") && xmlSchemaSymbols.contains(identifier.substring(4)));
    } // isXSDDatatype


    private boolean isValidIdentifier(String s) {
        if (s.length() == 0 || !Character.isJavaIdentifierStart(s.charAt(0))) {
            return false;
        }
        for (int i = 1; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!(Character.isJavaIdentifierPart(c) || c == ':' || c == '-')) {
                return false;
            }
        }
        return true;
    } // isValidIdentifier

    // We do not create a new instance for each occurence of the same variable.

    private SWRLVariable getSWRLVariable(String name) throws SWRLParseException {
        RDFResource resource = owlModel.getRDFResource(name);
        if (resource instanceof SWRLVariable) {
            return (SWRLVariable) resource;
        }
        else if (resource == null) {
            return swrlFactory.createVariable(name);
        }
        else {
            throw new SWRLParseException(name + " cannot be used as a variable name");
        }
    } // getVariable

} // SWRLParser
