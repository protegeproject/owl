package edu.stanford.smi.protegex.owl.model.impl;

import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protegex.owl.model.OWLIntersectionClass;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.visitor.OWLModelVisitor;

/**
 * The default implementation of the OWLIntersectionClass interface.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultOWLIntersectionClass extends AbstractOWLNAryLogicalClass
        implements OWLIntersectionClass {

    /**
     * The unicode operator symbol for this kind of class
     */
    public final static char OPERATOR = '\u2293';


    public DefaultOWLIntersectionClass(KnowledgeBase kb, FrameID id) {
        super(kb, id);
    }


    public DefaultOWLIntersectionClass() {
    }


    public void accept(OWLModelVisitor visitor) {
        visitor.visitOWLIntersectionClass(this);
    }


    public RDFProperty getOperandsProperty() {
        return getOWLModel().getOWLIntersectionOfProperty();
    }


    public char getOperatorSymbol() {
        return OPERATOR;
    }
}
