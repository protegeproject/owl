package edu.stanford.smi.protegex.owl.jena;


/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLCreateProjectPlugin {


    void setDefaultNamespace(String namespace);


    void setPropertiesView(boolean value);


    void setProfile(String profileURI);
}
