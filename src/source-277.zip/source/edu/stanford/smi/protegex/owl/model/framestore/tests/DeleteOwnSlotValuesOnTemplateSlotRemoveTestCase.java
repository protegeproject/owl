package edu.stanford.smi.protegex.owl.model.framestore.tests;

import edu.stanford.smi.protege.event.FrameAdapter;
import edu.stanford.smi.protege.event.FrameEvent;
import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protegex.owl.model.OWLDatatypeProperty;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DeleteOwnSlotValuesOnTemplateSlotRemoveTestCase extends AbstractJenaTestCase {

    private int eventCount = 0;


    public void testDeleteOwnSlotValues() {
        OWLNamedClass superCls = owlModel.createOWLNamedClass("Person");
        OWLNamedClass subCls = owlModel.createOWLNamedSubclass("Parent", superCls);
        final OWLDatatypeProperty ageProperty = owlModel.createOWLDatatypeProperty("age", owlModel.getXSDint());
        OWLDatatypeProperty otherProperty = owlModel.createOWLDatatypeProperty("other", owlModel.getXSDstring());
        ageProperty.setDomain(superCls);
        otherProperty.setDomain(superCls);

        Instance superInstance = superCls.createInstance("SuperInstance");
        Instance subInstance = subCls.createInstance("SubInstance");
        assertTrue(superInstance.hasOwnSlot(ageProperty));
        assertTrue(superInstance.hasOwnSlot(otherProperty));
        assertTrue(subInstance.hasOwnSlot(ageProperty));

        superInstance.setOwnSlotValue(ageProperty, new Integer(42));
        superInstance.setOwnSlotValue(otherProperty, "Test");
        subInstance.setOwnSlotValue(ageProperty, new Integer(43));
        assertSize(1, superInstance.getDirectOwnSlotValues(ageProperty));
        assertSize(1, subInstance.getDirectOwnSlotValues(ageProperty));

        superInstance.addFrameListener(new FrameAdapter() {
            public void ownSlotValueChanged(FrameEvent event) {
                if (event.getSlot().equals(ageProperty)) {
                    eventCount++;
                }
            }
        });

        subInstance.addFrameListener(new FrameAdapter() {
            public void ownSlotValueChanged(FrameEvent event) {
                if (event.getSlot().equals(ageProperty)) {
                    eventCount++;
                }
            }
        });

        assertEquals(0, eventCount);
        ageProperty.removeUnionDomainClass(superCls);
        assertEquals(2, eventCount);

        assertSize(0, superInstance.getDirectOwnSlotValues(ageProperty));
        assertSize(0, subInstance.getDirectOwnSlotValues(ageProperty));
    }
}
