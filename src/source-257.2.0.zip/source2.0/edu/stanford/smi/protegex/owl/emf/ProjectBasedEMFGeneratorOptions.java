package edu.stanford.smi.protegex.owl.emf;

import edu.stanford.smi.protege.model.Project;

import java.io.File;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class ProjectBasedEMFGeneratorOptions implements EditableEMFGeneratorOptions {

    public final static String FILE_NAME = "EMFFileName";

    public final static String PACKAGE = "EMFPackage";

    private Project project;


    public ProjectBasedEMFGeneratorOptions(Project project) {
        this.project = project;
    }


    public File getOutputFolder() {
        String fileName = project.getSources().getString(FILE_NAME);
        if (fileName == null) {
            return new File("");
        }
        else {
            return new File(fileName);
        }
    }


    public String getPackage() {
        return project.getSources().getString(PACKAGE);
    }


    public void setOutputFolder(File file) {
        if (file == null) {
            project.getSources().remove(FILE_NAME);
        }
        else {
            project.getSources().setString(FILE_NAME, file.getAbsolutePath());
        }
    }


    public void setPackage(String value) {
        if (value == null) {
            project.getSources().remove(PACKAGE);
        }
        else {
            project.getSources().setString(PACKAGE, value);
        }
    }
}
