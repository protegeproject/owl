package edu.stanford.smi.protegex.owl.inference.ui.action;

import edu.stanford.smi.protege.ui.ProjectManager;
import edu.stanford.smi.protege.ui.ProjectView;
import edu.stanford.smi.protegex.owl.inference.dig.exception.DIGReasonerException;
import edu.stanford.smi.protegex.owl.inference.protegeowl.ProtegeOWLReasoner;
import edu.stanford.smi.protegex.owl.inference.protegeowl.ReasonerManager;
import edu.stanford.smi.protegex.owl.inference.protegeowl.task.ReasonerTaskListener;
import edu.stanford.smi.protegex.owl.inference.ui.ReasonerActionRunner;
import edu.stanford.smi.protegex.owl.inference.ui.RunnableReasonerAction;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.ui.cls.OWLClassesTab;
import edu.stanford.smi.protegex.owl.ui.icons.OWLIcons;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * User: matthewhorridge<br>
 * The Univeristy Of Manchester<br>
 * Medical Informatics Group<br>
 * Date: Jun 20, 2004<br><br>
 * <p/>
 * matthew.horridge@cs.man.ac.uk<br>
 * www.cs.man.ac.uk/~horridgm<br><br>
 */
public class CheckConsistencyAction extends AbstractAction {

    private OWLModel kb;


    public CheckConsistencyAction(OWLModel kb) {
        super("Check consistency...", OWLIcons.getCheckConsistencyIcon());
        this.kb = kb;
    }


    public void actionPerformed(ActionEvent e) {
        ReasonerActionRunner runner = new ReasonerActionRunner(new RunnableReasonerAction() {
            public void executeReasonerActions(ReasonerTaskListener taskListener) throws DIGReasonerException {
                ProtegeOWLReasoner reasoner = ReasonerManager.getInstance().getReasoner(kb);
                reasoner.computeInconsistentConcepts(taskListener);
            }


            public OWLModel getOWLModel() {
                return kb;
            }
        }, false);

        runner.execute();
    }


    protected void displayInferredHierarchy() {
        ProjectView projectView = ProjectManager.getProjectManager().getCurrentProjectView();
        OWLClassesTab classesTab = (OWLClassesTab) projectView.getTabByClassName(OWLClassesTab.class.getName());
        if (classesTab != null) {
            classesTab.setInferredClsesVisible(true);
            classesTab.refreshChangedClses();
            classesTab.requestFocusInWindow();
	        classesTab.repaint();
        }
    }
}

