package edu.stanford.smi.protegex.owl.jena;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.RDFWriter;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.reasoner.ReasonerRegistry;
import com.hp.hpl.jena.reasoner.dig.DIGReasoner;
import com.hp.hpl.jena.reasoner.dig.DIGReasonerFactory;
import com.hp.hpl.jena.shared.PrefixMapping;
import com.hp.hpl.jena.vocabulary.ReasonerVocabulary;
import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.KnowledgeBaseFactory;
import edu.stanford.smi.protege.model.framestore.MergingNarrowFrameStore;
import edu.stanford.smi.protege.util.SystemUtilities;
import edu.stanford.smi.protegex.owl.jena.creator.JenaCreator;
import edu.stanford.smi.protegex.owl.jena.loader.JenaLoader;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.factory.OWLJavaFactory;
import edu.stanford.smi.protegex.owl.model.factory.OWLJavaFactoryUpdater;
import edu.stanford.smi.protegex.owl.model.impl.AbstractOWLModel;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreModel;
import edu.stanford.smi.protegex.owl.ui.widget.ModalProgressBarManager;

import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

/**
 * An OWLModel that can be synchronized with a Jena OntModel.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class JenaOWLModel extends AbstractOWLModel implements OntModelProvider {

    public final static String COPYRIGHT =
            "<!-- Created with Protege (with OWL Plugin " +
            OWLNames.VERSION + ", Build " +
            OWLNames.BUILD + ")  http://protege.stanford.edu -->";


    public static boolean inUI = false;

    private TripleStoreModel tripleStoreModel;


    public static final String TEMPLATE_FILE_NAME = "plugins/owl/template.owl";

    public static final String DEFAULT_PREFIX = "default";


    protected JenaOWLModel(KnowledgeBaseFactory factory, NamespaceManager namespaceManager) {
        super(factory, namespaceManager);
        OWLJavaFactoryUpdater.run(this);
        MergingNarrowFrameStore mnfs = MergingNarrowFrameStore.get(this);
        mnfs.setTopFrameStore(mnfs.getActiveFrameStore().getName());
    }


    private void closeRDFLists() {
        for (Iterator it = getCls(RDFNames.Cls.LIST).getInstances().iterator(); it.hasNext();) {
            Instance instance = (Instance) it.next();
            if (instance instanceof RDFList &&
                    instance.isEditable()) {
                RDFList li = (RDFList) instance;
                if (li.getRest() == null) {
                    li.setRest(getRDFNil());
                }
            }
        }
    }


    // Implements NamespaceManagerListener
    public void defaultNamespaceChanged(String oldValue, String newValue) {
        super.defaultNamespaceChanged(oldValue, newValue);
    }


    public RDFResource getRDFResource(Resource resource) {
        final String uri = resource.getURI();
        final String frameName = getResourceNameForURI(uri);
        if (frameName != null) {
            return (RDFResource) getFrame(frameName);
        }
        else {
            return null;
        }
    }


    // Implements OntModelProvider
    public OntModel getOntModel() {
        // TODO buffer recent OntModel until changed
        JenaCreator creator = new JenaCreator(this, false, null,
                inUI ? new ModalProgressBarManager("Preparing Ontology") : null);
        return creator.createOntModel();
    }


    // Implements OntModelProvider
    public OntModel getOWLDLOntModel() {
        JenaCreator creator = new JenaCreator(this, true, null,
                new ModalProgressBarManager("Preparing Ontology"));
        return creator.createOntModelWithoutOWLFullModel();
    }


    public int getOWLSpecies() {
        JenaCreator creator = new JenaCreator(this, false, null,
                new ModalProgressBarManager("Preparing Ontology"));
        OntModel ontModel = creator.createOntModelWithoutOWLFullModel();
        return Jena.getOWLSpecies(ontModel);
    }


    // Implements OntModelProvider
    public OntModel getReasonerOntModel(String classifierURL) {
        com.hp.hpl.jena.rdf.model.Model newModel = ModelFactory.createDefaultModel();
        Resource resource = newModel.createResource("http://foo.de#foo");
        newModel.add(resource, ReasonerVocabulary.EXT_REASONER_URL, classifierURL);

        DIGReasoner reasoner = (DIGReasoner) ReasonerRegistry.theRegistry().
                create(DIGReasonerFactory.URI, resource);

        OntModelSpec spec = new OntModelSpec(OntModelSpec.OWL_DL_MEM);
        spec.setReasoner(reasoner);
        return Jena.cloneOntModel(getOntModel(), spec);
    }


    public TripleStoreModel getTripleStoreModel() {
        if (tripleStoreModel == null) {
            String className = "edu.stanford.smi.protegex.owl.jena.triplestore.JenaTripleStoreModel";
            try {
                Class c = Class.forName(className);
                Constructor con = c.getConstructors()[0];
                tripleStoreModel = (TripleStoreModel) con.newInstance(new Object[]{this});
            }
            catch (Exception ex) {
                // Ok, then no TripleStore here
            }
        }
        return tripleStoreModel;
    }


    public void initOWLFrameFactoryInvocationHandler() {
        setFrameFactory(new OWLJavaFactory(this));
    }


    public void initPrefixes(OntModel ontModel) {
        NamespaceManager nsm = getNamespaceManager();
        initPrefixes(nsm, ontModel);
        String defaultNamespace = ontModel.getNsPrefixURI("");
        if (defaultNamespace != null) {
            nsm.setDefaultNamespace(defaultNamespace);
        }

        for (Iterator it = ontModel.getSubGraphs().iterator(); it.hasNext();) {
            Graph graph = (Graph) it.next();
            PrefixMapping mapping = graph.getPrefixMapping();
            initPrefixes(nsm, mapping);
        }
    }


    private void initPrefixes(NamespaceManager nsm, PrefixMapping mapping) {
        Map map = mapping.getNsPrefixMap();
        for (Iterator it = map.keySet().iterator(); it.hasNext();) {
            String prefix = (String) it.next();
            if (prefix.length() > 0) {
                String uri = (String) map.get(prefix);
                if (nsm.getPrefix(uri) == null && nsm.getNamespaceForPrefix(prefix) == null) {
                    nsm.setPrefix(uri, prefix);
                }
                else {
                    String oldNS = nsm.getNamespaceForPrefix(prefix);
                    if (oldNS != null && !oldNS.equals(uri)) {
                        System.err.println("[JenaOWLModel] Error: Conflicting prefix " +
                                prefix + " (was: " + oldNS + ") was redefined as " + uri);
                    }
                }
            }
        }
    }


    public void load(URI uri, String language) throws Exception {
        if (JenaKnowledgeBaseFactory.getUseARP(getProject())) {
            Class parserClass = Class.forName("edu.stanford.smi.protegex.owl.jena.parser.ProtegeOWLParser");
            Constructor constructor = parserClass.getConstructors()[0];
            Object parser = constructor.newInstance(new Object[]{this});
            // ProtegeOWLParser parser = new ProtegeOWLParser(this);
            Method runMethod = parserClass.getMethod("run", new Class[]{URL.class});
            runMethod.invoke(parser, new Object[]{uri.toURL()});
            // parser.run(uri.toURL());
            // OWLUtil.sortSubclasses(this);
        }
        else {
            JenaLoader.loadFile(this, uri, language);
        }
        copyFacetValuesIntoNamedClses();
    }


    public void load(InputStream is, String language) throws Exception {
        new JenaLoader(this, is, language);
        copyFacetValuesIntoNamedClses();
    }


    public void load(Reader reader, String language) throws Exception {
        new JenaLoader(this, reader, language);
        copyFacetValuesIntoNamedClses();
    }


    public void load(URI uri, String language, Collection errors) {
        try {
            load(uri, language);
        }
        catch (Throwable t) {
            t.printStackTrace();
            errors.add(t);
        }
    }


    // Implements NamespaceManagerListener
    public void namespaceChanged(String prefix, String oldValue, String newValue) {
        super.namespaceChanged(prefix, oldValue, newValue);
    }


    // Implements NamespaceManagerListener
    public void prefixAdded(String prefix) {
        super.prefixAdded(prefix);
    }


    // Implements NamespaceManagerListener
    public void prefixChanged(String namespace, String oldPrefix, String newPrefix) {
        super.prefixChanged(namespace, oldPrefix, newPrefix);
    }


    // Implements NamespaceManagerListener
    public void prefixRemoved(String prefix) {
        super.prefixRemoved(prefix);
    }


    /**
     * Writes the base model of this into a given file.
     *
     * @param fileURI  the URI of the target file
     * @param language the Jena output language (typically FileUtils.langXMLAbbrev)
     * @param errors   an initially empty collection of errors
     */
    public void save(URI fileURI, String language, Collection errors) {
        closeRDFLists();
        save(fileURI, language, errors, getOntModel());
    }


    /**
     * Writes the base model of this into a given OutputStream.
     *
     * @param os       the target output stream
     * @param language the Jena output language (typically FileUtils.langXMLAbbrev)
     * @param errors   an initially empty collection of errors
     */
    public void save(OutputStream os, String language, Collection errors) {
        closeRDFLists();
        save(os, language, errors, getOntModel());
    }


    public void save(URI fileURI, String language, Collection errors, OntModel ontModel) {
        try {
            File file = new File(fileURI);
            String namespace = getNamespaceManager().getDefaultNamespace();
            save(file, ontModel, language, namespace);
        }
        catch (Throwable t) {
            t.printStackTrace();
            errors.add(t);
        }
    }


    public static void save(File file, OntModel ontModel, String language, String namespace) throws IOException {
        OutputStream outputStream = new FileOutputStream(file);
        save(outputStream, ontModel, language, namespace);
    }


    public void save(OutputStream os, String language, Collection errors, OntModel ontModel) {
        try {
            String namespace = getNamespaceManager().getDefaultNamespace();
            save(os, ontModel, language, namespace);
        }
        catch (Throwable t) {
            t.printStackTrace();
            errors.add(t);
        }
    }


    private static void save(OutputStream outputStream, OntModel ontModel, String language, String namespace) throws IOException {
        PrintStream ps = new PrintStream(outputStream);
        RDFWriter writer = ontModel.getWriter(language);
        Jena.prepareWriter(writer, language, namespace);
        boolean xml = Jena.isXMLLanguage(language);
        if (xml) {
            String encoding = SystemUtilities.getFileEncoding();
            Collection charsets = Charset.availableCharsets().keySet();
            if (!charsets.contains(encoding)) {
                encoding = "UTF-8";
            }
            //ps.println("<?xml version=\"1.0\" encoding=\"" + encoding + "\" ?>");
            // Jena will save in <encoding>, and add xml-declaration
            writer.write(ontModel.getBaseModel(), new OutputStreamWriter(ps, encoding), namespace);
        }
        else {
            // Jena will save in UTF-8
            ontModel.removeNsPrefix("");
            ontModel.setNsPrefix(DEFAULT_PREFIX, namespace);
            try {
                writer.write(ontModel.getBaseModel(), ps, namespace);
            }
            finally {
                ontModel.removeNsPrefix(DEFAULT_PREFIX);
                ontModel.setNsPrefix("", namespace);
            }
        }
        //writer.write(ontModel.getBaseModel(), ps, namespace);
        if (xml) {
            ps.println();
            ps.println(COPYRIGHT);
        }
        outputStream.close();
    }
}
