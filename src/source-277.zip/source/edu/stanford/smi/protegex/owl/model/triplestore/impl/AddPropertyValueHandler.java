package edu.stanford.smi.protegex.owl.model.triplestore.impl;

import edu.stanford.smi.protegex.owl.model.RDFResource;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
interface AddPropertyValueHandler {

    void handleAdd(RDFResource subject, Object object);
}
