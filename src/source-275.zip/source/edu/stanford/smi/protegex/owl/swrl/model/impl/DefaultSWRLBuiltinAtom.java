package edu.stanford.smi.protegex.owl.swrl.model.impl;

import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protegex.owl.model.RDFList;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLBuiltin;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLBuiltinAtom;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLNames;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class DefaultSWRLBuiltinAtom extends DefaultSWRLAtom implements SWRLBuiltinAtom {

    public DefaultSWRLBuiltinAtom(KnowledgeBase kb, FrameID id) {
        super(kb, id);
    } // DefaultSWRLBuiltinAtom


    public DefaultSWRLBuiltinAtom() {
    }


    public void getReferencedInstances(Set set) {
        RDFList arguments = getArguments();
        if (arguments != null) {
            set.addAll(arguments.getValues());
            set.add(arguments);
        }
        SWRLBuiltin builtin = getBuiltin();
        if (builtin != null) {
            set.add(builtin);
        }
    }


    public RDFList getArguments() {
        return (RDFList) getDirectOwnSlotValue(getKnowledgeBase().getSlot(SWRLNames.Slot.ARGUMENTS));
    } // getArguments


    public void setArguments(RDFList arguments) {
        setOwnSlotValue(getKnowledgeBase().getSlot(SWRLNames.Slot.ARGUMENTS), arguments);
    } // setArgument1


    public SWRLBuiltin getBuiltin() {
        return (SWRLBuiltin) getDirectOwnSlotValue(getKnowledgeBase().getSlot(SWRLNames.Slot.BUILTIN));
    } // SWRLBuiltin


    public void setBuiltin(SWRLBuiltin swrlBuiltin) {
        setOwnSlotValue(getKnowledgeBase().getSlot(SWRLNames.Slot.BUILTIN), swrlBuiltin);
    } // swrlBuiltin


    public String getBrowserText() {
        String s = "";

        if (getBuiltin() == null || getArguments() == null) return super.getBrowserText();

        s += getBuiltin().getBrowserText() + "(";
        List values = getArguments().getValues();
        for (Iterator it = values.iterator(); it.hasNext();) {
            Object o = (Object) it.next();
            if (o instanceof Frame) {
                s += ((Frame) o).getBrowserText();
            }
            else {
                s += o;
            }
            if (it.hasNext()) {
                s += ", ";
            }
        }
        s += ")";

        return s;

    } // getBrowserText

} // SWRLBuiltinAtom
