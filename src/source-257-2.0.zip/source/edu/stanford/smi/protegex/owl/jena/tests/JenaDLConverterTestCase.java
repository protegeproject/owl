package edu.stanford.smi.protegex.owl.jena.tests;

import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntProperty;
import edu.stanford.smi.protegex.owl.jena.Jena;
import edu.stanford.smi.protegex.owl.jena.OntModelProvider;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.util.Collections;

/**
 * TestCases for the JenaDLConverter.
 * These tests basically create an OWL Full ontology and check whether it is
 * correctly transformed into OWL DL.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class JenaDLConverterTestCase extends AbstractJenaTestCase {


    public void testConvertAnnotationPropertyValue() {
        OWLNamedClass cls = owlModel.createOWLNamedClass("Cls");
        OWLProperty property = owlModel.createAnnotationOWLDatatypeProperty("property");
        cls.addPropertyValue(property, "value");
        OntModel ontModel = owlModel.getOntModel();
        OntClass oldClass = ontModel.getOntClass(cls.getURI());
        OntProperty oldProperty = ontModel.getOntProperty(property.getURI());
        assertSize(1, oldClass.listPropertyValues(oldProperty));
        assertEquals(OntModelProvider.OWL_FULL, owlModel.getOWLSpecies());
        OntModel newModel = owlModel.getOWLDLOntModel();
        OntClass newClass = newModel.getOntClass(cls.getURI());
        OntProperty newProperty = newModel.getOntProperty(property.getURI());
        assertNotNull(newProperty);
        assertNotNull(newClass);
        assertSize(1, newClass.listPropertyValues(newProperty));
    }


    public void testConvertAnnotationPropertyWithRange() {
        OWLProperty property = owlModel.createAnnotationOWLObjectProperty("anno");
        property.setDomainDefined(false);
        RDFSClass aClass = owlModel.createOWLNamedClass("Cls");
        property.setUnionRangeClasses(Collections.singleton(aClass));
        assertEquals(OntModelProvider.OWL_LITE, Jena.getOWLSpecies(owlModel.getOWLDLOntModel()));
    }


    public void testConvertAnnotationPropertyWithDomain() {
        OWLProperty property = owlModel.createAnnotationOWLObjectProperty("anno");
        property.setDomainDefined(true);
        OWLNamedClass cls = owlModel.createOWLNamedClass("Cls");
        property.addUnionDomainClass(cls);
        assertEquals(OntModelProvider.OWL_LITE, Jena.getOWLSpecies(owlModel.getOWLDLOntModel()));
    }


    public void testConvertClassProperty() {
        OWLObjectProperty slot = owlModel.createOWLObjectProperty("cls");
        slot.setRange(owlModel.getOWLNamedClassClass());
        final OntModel owlDLOntModel = owlModel.getOWLDLOntModel();
        assertEquals(OntModelProvider.OWL_LITE, Jena.getOWLSpecies(owlDLOntModel));
    }


    public void testConvertMetaclass() {
        OWLNamedClass metaCls = owlModel.createOWLNamedClass("MetaCls");
        metaCls.addSuperclass(owlModel.getOWLNamedClassClass());
        metaCls.removeSuperclass(owlThing);
        RDFProperty slot = owlModel.createOWLDatatypeProperty("author", owlModel.getXSDstring());
        slot.addUnionDomainClass(metaCls);

        OWLNamedClass cls = owlModel.createOWLNamedClass("Cls", metaCls);
        cls.addPropertyValue(slot, "Holgi");

        final OntModel owlDLOntModel = owlModel.getOWLDLOntModel();
        assertEquals(OntModelProvider.OWL_LITE, Jena.getOWLSpecies(owlDLOntModel));
        assertSize(1, owlDLOntModel.listNamedClasses());  // Metaclass was deleted
    }


    public void testConvertMetaclassSubClass() {
        OWLNamedClass metaCls = owlModel.createOWLNamedClass("MetaCls");
        metaCls.addSuperclass(owlModel.getOWLNamedClassClass());
        metaCls.removeSuperclass(owlThing);
        OWLNamedClass subMetaCls = owlModel.createOWLNamedClass("SubMetaCls");
        subMetaCls.addSuperclass(metaCls);
        subMetaCls.removeSuperclass(owlThing);
        final OntModel owlDLOntModel = owlModel.getOWLDLOntModel();
        assertEquals(OntModelProvider.OWL_LITE, Jena.getOWLSpecies(owlDLOntModel));
        assertSize(0, owlDLOntModel.listNamedClasses());  // Metaclass was deleted
    }


    public void testConvertPropertyMetaclass() {
        OWLNamedClass metaCls = owlModel.createOWLNamedClass("SlotMetaCls");
        metaCls.addSuperclass(owlModel.getOWLObjectPropertyClass());
        metaCls.removeSuperclass(owlThing);
        OWLObjectProperty slot = owlModel.createOWLObjectProperty("slot", metaCls);
        final OntModel owlDLOntModel = owlModel.getOWLDLOntModel();
        assertEquals(OntModelProvider.OWL_LITE, Jena.getOWLSpecies(owlDLOntModel));
        assertSize(0, owlDLOntModel.listNamedClasses());  // Metaclass was deleted
    }


    public void testImportProtegeDC() throws Exception {
        loadRemoteOntology("import-protege-dc.owl");
        final OntModel owlDLOntModel = owlModel.getOWLDLOntModel();
        assertEquals(OntModelProvider.OWL_LITE, Jena.getOWLSpecies(owlDLOntModel));
    }
}
