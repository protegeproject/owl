package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadRDFPropertiesTestCase extends AbstractJenaTestCase {

    public void testLoadRDFProperty() throws Exception {
        loadRemoteOntologyWithJenaLoader("rdfSlotTypes.owl");
        RDFProperty anyProperty = owlModel.getRDFProperty("anySlot");
        assertNull(anyProperty.getRange());
        RDFProperty booleanProperty = owlModel.getRDFProperty("booleanSlot");
        assertEquals(owlModel.getXSDboolean(), booleanProperty.getRange());
        RDFProperty stringProperty = owlModel.getRDFProperty("stringSlot");
        assertEquals(owlModel.getXSDstring(), stringProperty.getRange());
        RDFProperty objectProperty = owlModel.getRDFProperty("objectSlot");
        assertTrue(objectProperty.hasObjectRange());
        assertSize(1, objectProperty.getUnionRangeClasses());
        assertEquals(owlModel.getCls("Cls"), objectProperty.getUnionRangeClasses().iterator().next());
    }
}
