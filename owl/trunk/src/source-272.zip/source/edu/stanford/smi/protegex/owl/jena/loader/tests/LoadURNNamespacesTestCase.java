package edu.stanford.smi.protegex.owl.jena.loader.tests;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.util.FileUtils;
import edu.stanford.smi.protegex.owl.model.OWLNames;
import edu.stanford.smi.protegex.owl.model.OWLOntology;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.net.URI;
import java.util.Iterator;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadURNNamespacesTestCase extends AbstractJenaTestCase {

    public void testLoadOntologyMetadata() throws Exception {
        loadRemoteOntologyWithJenaLoader("alix/java.owl");
        for (Iterator it = owlModel.getCls(OWLNames.Cls.ONTOLOGY).getDirectInstances().iterator(); it.hasNext();) {
            OWLOntology owlOntology = (OWLOntology) it.next();
            System.out.println("- " + owlOntology.getBrowserText());
        }
        OWLOntology oi = owlModel.getDefaultOWLOntology();
        assertSize(1, oi.getVersionInfo());

        Resource test = ontModel.createOntology("urn:hdl:1016.2/mapping/java/");
        System.out.println("URI: " + test.getURI());
    }


    public void testLoadURN() throws Exception {
        //loadRemoteOntologyWithJenaLoader("urn.owl");
        //System.out.println("Default: " + ontModel.getNsPrefixURI(""));
        //Jena.dumpRDF(ontModel);
        URI uri = new URI("http://protege.stanford.edu/plugins/owl/testdata/urn.owl");
        OntModelSpec spec = new OntModelSpec(OntModelSpec.OWL_MEM);
        spec.setReasoner(null);
        OntModel ontModel = ModelFactory.createOntologyModel(spec, null);
        ontModel.read(uri.toString(), FileUtils.langXMLAbbrev);
        //System.out.println("Default: " + ontModel.getNsPrefixURI(""));
        //Jena.dumpRDF(ontModel);
        //loadTestOntologyWithJenaLoader(uri);
    }
}
