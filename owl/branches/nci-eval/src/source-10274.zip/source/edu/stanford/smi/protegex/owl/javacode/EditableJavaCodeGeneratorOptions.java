package edu.stanford.smi.protegex.owl.javacode;

import java.io.File;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface EditableJavaCodeGeneratorOptions extends JavaCodeGeneratorOptions {

    void setAbstractMode(boolean value);


    void setFactoryClassName(String value);


    void setOutputFolder(File file);


    void setPackage(String value);


    void setSetMode(boolean value);
}
