package edu.stanford.smi.protegex.owl.inference.dig.translator;

import edu.stanford.smi.protege.model.ValueType;
import edu.stanford.smi.protegex.owl.model.impl.XMLSchemaDatatypes;

import java.util.HashMap;

/**
 * User: matthewhorridge<br>
 * The Univeristy Of Manchester<br>
 * Medical Informatics Group<br>
 * Date: Aug 30, 2004<br><br>
 * <p/>
 * matthew.horridge@cs.man.ac.uk<br>
 * www.cs.man.ac.uk/~horridgm<br><br>
 */
public class DIGDataTypes {

    public static final int REAL_MULTIPLIER = 10000;

    private static DIGDataTypes instance;

    private HashMap map;

    private HashMap rangeMap;


    protected DIGDataTypes() {
        // Create the map and put in the supported
        // datatypes
        map = new HashMap();



        // Integer
        map.put(Integer.class, new ValueTypeMapEntry(DIGVocabulary.Language.IVAL,
                DIGVocabulary.Tell.RANGE_INT,
                DIGVocabulary.Language.INT_EQUALS) {
            public String getRenderering(Object value) {
                return value.toString();
            }
        });

        // String
        map.put(String.class, new ValueTypeMapEntry(DIGVocabulary.Language.SVAL,
                DIGVocabulary.Tell.RANGE_STRING,
                DIGVocabulary.Language.STRING_EQUALS) {
            public String getRenderering(Object value) {
                return value.toString();
            }
        });

        // Float - Simulate using integers
        map.put(Float.class, new ValueTypeMapEntry(DIGVocabulary.Language.IVAL,
                DIGVocabulary.Tell.RANGE_INT,
                DIGVocabulary.Language.INT_EQUALS) {
            public String getRenderering(Object value) {
                return Integer.toString((int) ((Float) value).floatValue() * REAL_MULTIPLIER);
            }
        });

        // Boolean - Simulate using integer
        map.put(Boolean.class, new ValueTypeMapEntry(DIGVocabulary.Language.IVAL,
                DIGVocabulary.Tell.RANGE_INT,
                DIGVocabulary.Language.INT_EQUALS) {
            public String getRenderering(Object value) {
                if (((Boolean) value).booleanValue() == true) {
                    return "1";
                }
                else {
                    return "0";
                }
            }
        });

    }


    public static synchronized DIGDataTypes getInstance() {
        if (instance == null) {
            instance = new DIGDataTypes();
        }

        return instance;
    }


    /**
     * Determines whether or not the datatype that
     * is represented by the Protege ValueType is
     * supported
     */
    public boolean isSupported(ValueType valueType) {
        return map.containsKey(valueType.getJavaType());
    }


    /**
     * Dermines if the object is of a supported
     * datatype.
     *
     * @param value The object to be tested.  This is typically
     *              an instance of a String, Number (Java Number), Boolean etc.
     */
    public boolean isSupported(Object value) {
        return map.containsKey(value.getClass());
    }


    /**
     * Gets the XML DIG Document tag name for the
     * specified specified object (e.g. ival for integers,
     * sval for strings).  This is the tag name that is used
     * to specify that an individual is in an attribute (datatype
     * property) relationship with a value.
     *
     * @param value The value that is the filler for the relationship.
     * @return The tag name, or <code>null</code> if the datatype
     *         that the value belongs to is not supported.
     */
    public String getIndividualAxiomValueTagName(Object value) {
        String ret = null;

        ValueTypeMapEntry valueTypeMapEntry = (ValueTypeMapEntry) map.get(value.getClass());

        if (valueTypeMapEntry != null) {
            ret = valueTypeMapEntry.getValueTag();
        }

        return ret;
    }


    /**
     * Gets the XML DIG Document element tag name that
     * is used to specify the range of a datatype property
     * for the specified value type.  e.g. rangeint if the
     * range of a datatype property is an integer.
     *
     * @param valueType The value type who's range tag we want
     * @return The tag name, or <code>null</code> is the valuetype
     *         is not supported.
     */
    public String getPropertyRangeTagName(ValueType valueType) {
        String ret = null;

        ValueTypeMapEntry valueTypeMapEntry = (ValueTypeMapEntry) map.get(valueType.getJavaType());

        if (valueTypeMapEntry != null) {
            ret = valueTypeMapEntry.getRangeTag();
        }

        return ret;
    }


    public String getConcreteDomainExpressionTagName(Object value) {
        String ret = null;

        ValueTypeMapEntry valueTypeMapEntry = (ValueTypeMapEntry) map.get(value.getClass());

        if (valueTypeMapEntry != null) {
            ret = valueTypeMapEntry.getValueRestrictionTag();
        }

        return ret;
    }


    /**
     * Gets the lexical rendering for the specified
     * value
     *
     * @param value The object whose lexical rendering
     *              is required.
     */
    public String getDataTypeRendering(Object value) {
        String ret = null;

        ValueTypeMapEntry valueTypeMapEntry = (ValueTypeMapEntry) map.get(value.getClass());

        if (valueTypeMapEntry != null) {
            ret = valueTypeMapEntry.getRenderering(value);
        }

        return ret;
    }


    /**
     * Gets the XML Schema Datatype for the specified
     * ValueType.
     */
    public String getXMLSchemaDatatype(ValueType valueType) {
        return XMLSchemaDatatypes.getDefaultAlias(valueType);
    }


    private abstract class ValueTypeMapEntry {

        private String valueTag;

        private String rangeTag;

        private String valueRestrictionTag;


        public ValueTypeMapEntry(String valueTag, String rangeTag, String valueRestrictionTag) {
            this.valueTag = valueTag;

            this.rangeTag = rangeTag;

            this.valueRestrictionTag = valueRestrictionTag;
        }


        public String getValueTag() {
            return valueTag;
        }


        public String getRangeTag() {
            return rangeTag;
        }


        public String getValueRestrictionTag() {
            return valueRestrictionTag;
        }


        public abstract String getRenderering(Object value);
    }

}

