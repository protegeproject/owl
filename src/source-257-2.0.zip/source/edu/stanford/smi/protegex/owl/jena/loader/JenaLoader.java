package edu.stanford.smi.protegex.owl.jena.loader;

import com.hp.hpl.jena.datatypes.xsd.XSDDatatype;
import com.hp.hpl.jena.datatypes.xsd.XSDDateTime;
import com.hp.hpl.jena.datatypes.xsd.XSDDuration;
import com.hp.hpl.jena.ontology.*;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.shared.PrefixMapping;
import com.hp.hpl.jena.util.FileUtils;
import com.hp.hpl.jena.util.ResourceUtils;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.plugin.PluginUtilities;
import edu.stanford.smi.protege.plugin.ProjectPlugin;
import edu.stanford.smi.protege.util.ApplicationProperties;
import edu.stanford.smi.protege.util.SystemUtilities;
import edu.stanford.smi.protegex.owl.jena.Jena;
import edu.stanford.smi.protegex.owl.jena.JenaNormalizer;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.jena.JenaProjectPlugin;
import edu.stanford.smi.protegex.owl.jena.rdf2owl.RDF2OWL;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.framestore.OWLFrameStore;
import edu.stanford.smi.protegex.owl.model.impl.AbstractOWLModel;
import edu.stanford.smi.protegex.owl.model.impl.OWLUtil;
import edu.stanford.smi.protegex.owl.model.impl.XMLSchemaDatatypes;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLNames;
import edu.stanford.smi.protegex.owl.ui.jena.OntPolicy;
import junit.framework.Assert;

import java.io.File;
import java.io.InputStream;
import java.io.Reader;
import java.net.URI;
import java.util.*;

/**
 * An object that writes the contents of a Jena ontology into a Protege KnowledgeBase.
 * This is used by the JenaKnowledgeBaseFactory to load an OWL file into Protege.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class JenaLoader {

    public static JenaLoaderFactory factory = new DefaultJenaLoaderFactory();

    public final static String ROOT_FOLDER = "edu.stanford.smi.protegex.owl";

    public final static String DEFAULT_ONT_POLICY_FILE_PATH =
            new File(new File(new File(ApplicationProperties.getApplicationDirectory(),
                    "plugins"),
                    ROOT_FOLDER),
                    "ont-policy.rdf").toURI().toString();

    private boolean hasImports = false;

    /**
     * A flag that ignores annotation property values if true (so that
     * the size of an ontology in memory be reduced).
     */
    private boolean ignoreAnnotations = false;

    /**
     * Indicates whether logging is turned on or not
     */
    private static boolean logging = false;

    /**
     * Set this to "true" in protege.properties to enable logging
     */
    public static String LOGGING_PROPERTY = JenaLoader.class.getName() + ".logging";

    public final static String ONT_POLICY_PROPERTY = JenaLoader.class.getName() + ".ontPolicy";

    /**
     * The JenaOWLModel to fill
     */
    private JenaOWLModel owlModel;

    /**
     * A Hashtable that stores the references from Jena OntClasses to Protege Clses.
     * This is needed to establish links between anonymous classes, which cannot be found
     * through their name.
     */
    private Hashtable ontClass2Cls = new Hashtable();

    private final Resource[] primaryTypes = new Resource[]{
        OWL.Class,
        RDFS.Class,
        OWL.ObjectProperty,
        OWL.DatatypeProperty,
        RDF.Property
    };

    private boolean protegeImported = false;

    private Map properties2Slots = new HashMap();


    /**
     * The Set of all properties which are handled differently (i.e.
     * are not loaded in the generic property value loop)
     */
    private final static Set specialProperties = new HashSet();


    static {
        specialProperties.add(RDF.type);
        specialProperties.add(RDFS.range);
        specialProperties.add(RDFS.subClassOf);
        specialProperties.add(RDFS.subPropertyOf);
        specialProperties.add(OWL.onProperty);
        specialProperties.add(OWL.allValuesFrom);
        specialProperties.add(OWL.someValuesFrom);
        specialProperties.add(OWL.hasValue);
        specialProperties.add(OWL.cardinality);
        specialProperties.add(OWL.maxCardinality);
        specialProperties.add(OWL.minCardinality);
        specialProperties.add(OWL.intersectionOf);
        specialProperties.add(OWL.unionOf);
        specialProperties.add(OWL.complementOf);
        specialProperties.add(OWL.equivalentClass);
    }


    /**
     * A Hashtable from URIs to FrameNames to speed up lookup during loading
     */
    private Hashtable uri2FrameName = new Hashtable();


    public JenaLoader(JenaOWLModel owlModel, URI uri, String language) throws Exception {
        long startTime = init(owlModel, uri);
        ontModel.read(uri.toString(), language);
        go(language, owlModel, startTime);
    }


    public JenaLoader(JenaOWLModel owlModel, InputStream is, String language) throws Exception {
        String uri = "http://www.owl-ontologies.com/default.owl";
        long startTime = init(owlModel, new URI(uri));
        ontModel.read(is, uri);
        go(language, owlModel, startTime);
    }


    public JenaLoader(JenaOWLModel owlModel, Reader reader, String language) throws Exception {
        String uri = "http://www.owl-ontologies.com/default.owl";
        long startTime = init(owlModel, new URI(uri));
        ontModel.read(reader, uri);
        go(language, owlModel, startTime);
    }


    private void go(String language, JenaOWLModel owlModel, long startTime) {
        if (!Jena.isXMLLanguage(language)) {
            String d = ontModel.getNsPrefixURI(JenaOWLModel.DEFAULT_PREFIX);
            if (d != null) {
                ontModel.removeNsPrefix(JenaOWLModel.DEFAULT_PREFIX);
                ontModel.setNsPrefix("", d);
            }
        }

        String ontModelNS = ontModel.getNsPrefixURI("");
        if (ontModelNS != null) {
            owlModel.getNamespaceManager().setDefaultNamespace(ontModelNS);
        }
        ensureDefaultJenaOntologyExists();
        long endTime = System.currentTimeMillis();
        System.out.println("... stream loading completed after " + (endTime - startTime) + " ms at " + new Date());

        ontModel.setNsPrefix("", owlModel.getNamespaceManager().getDefaultNamespace());
        owlModel.initPrefixes(ontModel);

        Iterator it = PluginUtilities.getAvailableProjectPluginClassNames().iterator();
        while (it.hasNext()) {
            String className = (String) it.next();
            ProjectPlugin plugin = (ProjectPlugin) SystemUtilities.newInstance(className);
            if (plugin instanceof JenaProjectPlugin) {
                ((JenaProjectPlugin) plugin).afterJenaLoad(owlModel.getProject(), ontModel);
            }
        }

        log("Running RDF2OWL...");
        new RDF2OWL(ontModel).run();
        log("Normalizing...");
        new JenaNormalizer(ontModel, owlFullModel, owlModel.getNamespaceManager());
        log("Converting...");
        OWLFrameStore.allowDuplicateOwnSlotValues = true; // To speed up - no errors are assumed in files

        renameResourcesWithIllegalNames(ontModel);

        hasImports = getDefaultJenaOntology().listImports().hasNext();
        protegeImported = ontModel.getOntProperty(ProtegeNames.NS + ProtegeNames.READ_ONLY) != null;

        System.out.println("JenaLoader starts conversion at " + new Date());
        startTime = System.currentTimeMillis();
        owlModel.setLoadDefaults(false);
        addPropertyValues(getDefaultJenaOntology(), owlModel.getDefaultOWLOntology());
        createOntologies(ontModel);
        createClses(ontModel);
        createRDFProperties(ontModel);
        createRDFIndividuals(ontModel);
        createAllDifferents(ontModel);
        owlModel.updateProtegeMetaOntologyImported();
        owlModel.setLoadDefaults(true);
        OWLUtil.sortSubclasses(owlModel);
        endTime = System.currentTimeMillis();
        System.out.println("JenaLoader completed after " + (endTime - startTime) + " ms at " + new Date());

        OWLFrameStore.allowDuplicateOwnSlotValues = false;
        log("... completed conversion.");
        owlModel.setGenerateEventsEnabled(true);
    }


    private long init(JenaOWLModel owlModel, URI uri) {
        this.owlModel = owlModel;

        createOntModel();

        updateLoggingStatus();
        owlModel.setGenerateEventsEnabled(false);
        initCache(owlModel.getProject(), ontModel.getDocumentManager());
        String defaultNamespace = uri.toString() + Jena.DEFAULT_NAMESPACE_SEPARATOR;
        owlModel.getNamespaceManager().setDefaultNamespace(defaultNamespace);
        log("Loading stream " + uri);
        System.out.println("Starting to load OWL stream at " + new Date());
        long startTime = System.currentTimeMillis();
        return startTime;
    }


    private void createOntModel() {
        PrefixMapping prefixMapping = PrefixMapping.Factory.create()
                .setNsPrefix(RDFSNames.RDFS_PREFIX, RDFS.getURI())
                .setNsPrefix(RDFNames.RDF_PREFIX, RDF.getURI())
                .setNsPrefix(OWLNames.OWL_PREFIX, OWL.getURI())
                .setNsPrefix(RDFNames.XSD_PREFIX, XSDDatatype.XSD + "#")
                .lock();

        OntModelSpec spec = factory.getOntModelSpec(owlModel.getProject());
        ontModel = factory.createOntModel(spec);

        owlFullModel = Jena.addOWLFullModel(ontModel);
        for (Iterator it = ontModel.getNsPrefixMap().keySet().iterator(); it.hasNext();) {
            String prefix = (String) it.next();
            if (prefixMapping.getNsPrefixURI(prefix) == null) {
                ontModel.removeNsPrefix(prefix);
            }
        }
        initCache(owlModel.getProject(), ontModel.getDocumentManager());
    }


    private void addPropertyValues(Resource resource, RDFResource instance) {
        for (Iterator it = cloneIt(resource.listProperties()); it.hasNext();) {
            Statement statement = (Statement) it.next();
            Property property = statement.getPredicate();
            if (ignoreAnnotations && property.canAs(AnnotationProperty.class)) {
                continue;
            }
            if (!isSpecialProperty(property)) {
                RDFNode object = statement.getObject();
                RDFProperty rdfProperty = (RDFProperty) properties2Slots.get(property);
                if (rdfProperty != null) {
                    addPropertyValue(instance, rdfProperty, object);
                }
                else if (protegeImported) {
                    String propertyNameSpace = property.getNameSpace();
                    String localName = property.getLocalName();
                    if (propertyNameSpace.equals(ProtegeNames.NS) &&
                            (localName.equals(ProtegeNames.ABSTRACT))) {
                        addProtegeOwnSlotValues(property, instance, statement);
                    }
                    else if (property.canAs(OntProperty.class) || Jena.canAsOWLProperty(property)) {
                        addPropertyValue(instance, property, object);
                    }
                }
                else if (property.canAs(OntProperty.class) || Jena.canAsOWLProperty(property)) {
                    OntProperty ontProperty = Jena.asOntProperty(property);
                    rdfProperty = getRDFProperty(ontProperty);
                    properties2Slots.put(property, rdfProperty);
                    addPropertyValue(instance, property, object);
                }
            }
        }
    }


    private void addPropertyValue(RDFResource instance, Property property, RDFNode object) {
        OntProperty ontProperty = Jena.asOntProperty(property);
        RDFProperty rdfProperty = getRDFProperty(ontProperty);
        addPropertyValue(instance, rdfProperty, object);
    }


    private void addPropertyValue(RDFResource instance, RDFProperty property, RDFNode object) {
        if (object instanceof Literal) { // was: isObjectProperty()
            addDatatypePropertyValueSafe(instance, property, (Literal) object);
        }
        else {
            if (instance instanceof RDFSClass && property.getName().equals(OWLNames.Slot.ONE_OF)) {
                return;
            }
            Individual refIndividual = (Individual) object.as(Individual.class);
            Object newValue = null;
            newValue = getRDFResource(refIndividual);
            // Check whether value is already there - this may happen with
            // inverse properties that have been assigned before
            if (newValue != null && !instance.getPropertyValues(property).contains(newValue)) {
                instance.addPropertyValue(property, newValue);
            }
        }
    }


    private void addDatatypePropertyValue(RDFResource instance, RDFProperty slot, RDFNode object) {
        if (object.canAs(Literal.class) && instance != null) {
            Literal literal = (Literal) object.as(Literal.class);
            addDatatypePropertyValueSafe(instance, slot, literal);
        }
    }


    private void addDatatypePropertyValueSafe(RDFResource instance, RDFProperty property, Literal literal) {

        Object value = null;
        String language = literal.getLanguage();
        if (language != null && language.length() > 0) {
            value = owlModel.createRDFSLiteral(literal.getString(), literal.getLanguage());
        }
        else if (literal.getDatatype() != null) {
            Object litValue = literal.getValue();
            if (litValue instanceof XSDDateTime) {
                value = createXSDDateTimeLiteral(literal);
            }
            else {
                RDFSDatatype dt = owlModel.getRDFSDatatypeByURI(literal.getDatatypeURI());
                if (dt != null) {
                    String lexicalForm = literal.getLexicalForm();
                    value = owlModel.createRDFSLiteral(lexicalForm, dt);
                }
                else {
                    logError("Ignoring literal with unknown datatype " + literal.getDatatypeURI());
                }
            }
        }
        else {
            ValueType valueType = ((Cls) instance.getProtegeType()).getTemplateSlotValueType(property);
            if (valueType == ValueType.STRING || valueType == ValueType.SYMBOL) {
                try {
                    value = createPropertyValueFromLiteral(literal);
                }
                catch (Exception ex) {
                }
            }
            else if (valueType == ValueType.BOOLEAN) {
                value = new Boolean(literal.getBoolean());
            }
            else if (valueType == ValueType.INTEGER) {
                value = new Integer(literal.getValue().toString());
            }
            else if (valueType == ValueType.FLOAT) {
                value = new Float(literal.getValue().toString());
            }
            else if (valueType == ValueType.ANY) {
                try {
                    value = literal.getValue();
                    if (value instanceof XSDDateTime || value instanceof XSDDuration) {
                        value = value.toString();
                    }
                    else if (value instanceof Double) {
                        value = new Float(((Double) value).floatValue());
                    }
                    else if (value instanceof Long) {
                        value = new Integer(((Long) value).intValue());
                    }
                }
                catch (Exception ex) {
                }
            }
        }

        if (value == null) {
            logError("Ignoring illegal value for property " +
                    property.getName() + " at resource " + instance.getBrowserText());
            System.err.println("              The RDFNode of the illegal value is: " + literal);
        }
        else {
            instance.addPropertyValue(property, value);
            //log("+ Adding property value " + value + " to " + property.getBrowserText() + " at " + instance.getBrowserText());
        }
    }


    private Object createPropertyValueFromLiteral(Literal literal) {
        Object value;
        value = literal.getValue(); // was: getString()
        if (value instanceof String) {
            String lang = literal.getLanguage();
            if (lang != null) {
                value = owlModel.createRDFSLiteralOrString((String) value, lang);
            }
        }
        else if (value != null) {
            if (value instanceof XSDDateTime) {
                value = createXSDDateTimeLiteral(literal);
            }
            else {
                value = value.toString();
            }
        }
        return value;
    }


    private Object createXSDDateTimeLiteral(Literal literal) {
        Object value = literal.getValue();
        XSDDateTime dt = (XSDDateTime) value;
        RDFSDatatype rdfsDatatype = owlModel.getRDFSDatatypeByURI(literal.getDatatypeURI());
        if (XSDDatatype.XSDtime.getURI().equals(literal.getDatatype().getURI())) {
            String str = XMLSchemaDatatypes.getTimeString(dt.getHours(), dt.getMinutes(), dt.getFullSeconds());
            return owlModel.createRDFSLiteral(str, rdfsDatatype);
        }
        else if (XSDDatatype.XSDdateTime.getURI().equals(literal.getDatatype().getURI())) {
            String s = value.toString();
            int index = s.lastIndexOf("Z");
            if (index >= 0) {
                s = s.substring(0, index);
            }
            return owlModel.createRDFSLiteral(s, rdfsDatatype);
        }
        else {
            return owlModel.createRDFSLiteral(value.toString(), rdfsDatatype);
        }
    }


    private void addProtegeOwnSlotValues(Property property, RDFResource instance, Statement statement) {
        if (instance instanceof RDFSClass) {
            RDFSClass rdfsClass = (RDFSClass) instance;
            addProtegeOwnSlotValuesOfOWLCls(rdfsClass, property.getURI(), statement);
        }
    }


    private void addProtegeOwnSlotValuesOfOWLCls(RDFSClass aClass, String propertyName, Statement statement) {
        if (propertyName.equals(ProtegeNames.NS + ProtegeNames.ABSTRACT)) {
            RDFNode object = statement.getObject();
            Literal literal = (Literal) object.as(Literal.class);
            boolean abs = literal.getBoolean();
            ((Cls) aClass).setAbstract(abs);
            OntProperty property = (OntProperty) statement.getPredicate().as(OntProperty.class);
            Slot abstractSlot = getRDFProperty(property);
            ((Cls) aClass).setDirectOwnSlotValue(abstractSlot, new Boolean(abs));
            log("* Class " + aClass.getName() + " set abstract " + abs);
        }
    }


    private void addTemplateSlotsForDomain(OntProperty ontProperty, RDFProperty property) {
        OntResource domain = ontProperty.getDomain();
        if (domain == null) {
            property.setDomainDefined(false);
        }
        //else {
        //    property.setDomainDefined(true);
        //    addTemplateSlotsForDomainWithoutChangeToDomainDefined(ontProperty, property);
        //}
    }


    private void addTemplateSlotsForDomainWithoutChangeToDomainDefined(OntProperty ontProperty, RDFProperty property) {
        OntResource domain = ontProperty.getDomain();
        final Set domainSet = Jena.set(ontProperty.listDomain());
        if (domainSet.size() == 1 &&
                domain.canAs(UnionClass.class) &&
                domain.asClass().isAnon()) {
            log("+ Splitting unionClass domain of " + ontProperty + " into single Protege domains:");
            UnionClass unionClass = (UnionClass) domain.as(UnionClass.class);
            for (Iterator it = unionClass.listOperands(); it.hasNext();) {
                OntClass domainClass = (OntClass) it.next();
                Cls cls = getCls(domainClass);
                cls.addDirectTemplateSlot(property);
                log("  + Added " + cls.getBrowserText() + " to union domain of " + property.getName());
            }
        }
        else {
            List operands = new ArrayList();
            for (Iterator it = ontProperty.listDomain(); it.hasNext();) {
                Resource d = (Resource) it.next();
                if (d != null && Jena.canAsOntClass(d)) {
                    OntClass domainOntClass = Jena.asOntClass(d);
                    Cls domainCls = getCls(domainOntClass);
                    operands.add(domainCls);
                }
                else {
                    logError("Domain of " + ontProperty.getURI() + " is not an OntClass (ignored).");
                }
            }
            if (operands.size() == 1) {
                Cls domainCls = (Cls) operands.get(0);
                domainCls.addDirectTemplateSlot(property);
                log("  + Added " + domainCls.getBrowserText() + " to union domain of " + property.getName());
            }
            else if (operands.size() > 1) {
                OWLIntersectionClass intersectionCls = owlModel.createOWLIntersectionClass(operands);
                property.addUnionDomainClass(intersectionCls);
                log("+ Added artificial intersection class to domain of " + property.getName());
            }
        }
    }


    /**
     * Just creates a cloning Iterator to avoid concurrent modification exceptions.
     *
     * @param it the source Iterator
     * @return a new, independent Iterator
     */
    private Iterator cloneIt(Iterator it) {
        List list = new ArrayList();
        while (it.hasNext()) {
            list.add(it.next());
        }
        return list.iterator();
    }


    private void createAllDifferents(OntModel ontModel) {
        for (Iterator it = ontModel.listAllDifferent(); it.hasNext();) {
            AllDifferent allDifferent = (AllDifferent) it.next();
            OWLAllDifferent adi = owlModel.createOWLAllDifferent();
            for (Iterator mit = allDifferent.listDistinctMembers(); mit.hasNext();) {
                Resource resource = (Resource) mit.next();
                Object instance = getRDFResource(resource);
                if (instance instanceof RDFResource) {
                    adi.addDistinctMember((RDFResource) instance);
                }
            }
            setIncludedIfNotInBaseModel(allDifferent, adi);
        }
    }


    private OWLAllValuesFrom createOWLAllValuesFrom(RDFProperty property, AllValuesFromRestriction allValuesFromRestriction) {
        Resource allValuesFrom = allValuesFromRestriction.getAllValuesFrom();
        RDFResource filler = (RDFResource) getRDFResource(allValuesFrom);
        return owlModel.createOWLAllValuesFrom(property, filler);
    }


    private OWLAnonymousClass createAnonymousClass(OntClass ontClass) {
        OWLAnonymousClass cls = null;
        if (ontClass.isRestriction()) {
            cls = createOWLRestriction(ontClass.asRestriction());
        }
        else if (ontClass.isIntersectionClass()) {
            cls = createIntersectionCls(ontClass.asIntersectionClass());
        }
        else if (ontClass.isUnionClass()) {
            cls = createUnionCls(ontClass.asUnionClass());
        }
        else if (ontClass.isComplementClass()) {
            cls = createComplementCls(ontClass.asComplementClass());
        }
        else if (ontClass.isEnumeratedClass()) {
            cls = createOWLEnumeratedClass(ontClass.asEnumeratedClass());
        }
        addPropertyValues(ontClass, cls);
        setIncludedIfNotInBaseModel(ontClass, cls);
        return cls;
    }


    private Map anonResource2RDFResource = new HashMap();


    private RDFIndividual createAnonymousRDFIndividual(com.hp.hpl.jena.ontology.Individual individual) {
        return createRDFIndividual(individual, null, null);
    }


    private RDFSClass createRDFSClass(OntClass ontClass) {
        if (ontClass.isAnon()) {
            OWLAnonymousClass cls = createAnonymousClass(ontClass);
            if (cls != null) {
                if (logging) {
                    log("+ Created anonymous class: " + cls.getBrowserText());
                }
                registerOntClass(cls, ontClass);
            }
            return cls;
        }
        else {
            return createRDFSNamedClass(ontClass);
        }
    }


    private void createClses(OntModel ontModel) {
        final Iterator it = cloneIt(ontModel.listNamedClasses());
        while (it.hasNext()) {
            final OntClass ontClass = (OntClass) it.next();
            if (!Jena.isSystemClass(ontClass)) {
                getCls(ontClass);
            }
        }
    }


    private OWLComplementClass createComplementCls(OntClass ontClass) {
        ComplementClass complementClass = (ComplementClass) ontClass.as(ComplementClass.class);
        OWLComplementClass complementCls = owlModel.createOWLComplementClass();
        OntClass operandOntClass = complementClass.getOperand();
        if (operandOntClass != null) {
            RDFSClass complement = getRDFSClass(operandOntClass);
            complementCls.setComplement(complement);
        }
        return complementCls;
    }


    private void createDirectSuperclasses(OntClass ontClass, RDFSNamedClass aClass) {

        final Set namedClses = new HashSet();

        final List anonClasses = new ArrayList();

        // Named direct superclasses
        for (Iterator it = ontClass.listSuperClasses(); it.hasNext();) {
            final OntClass superOntClass = (OntClass) it.next();
            if (superOntClass.isAnon()) {
                anonClasses.add(superOntClass);
            }
            else {
                final Cls superCls = getCls(superOntClass);
                namedClses.add(superCls);
            }
        }

        // Add named operands from equivalent intersections
        for (Iterator it = ontClass.listEquivalentClasses(); it.hasNext();) {
            final OntClass equivalentClass = (OntClass) it.next();
            if (equivalentClass.canAs(IntersectionClass.class)) {
                final IntersectionClass intersectionClass = equivalentClass.asIntersectionClass();
                for (Iterator oit = intersectionClass.listOperands(); oit.hasNext();) {
                    final Resource operand = (Resource) oit.next();
                    if (operand.canAs(OntClass.class)) {
                        final OntClass operandClass = (OntClass) operand.as(OntClass.class);
                        if (!operandClass.isAnon()) {
                            final Cls superCls = getCls(operandClass);
                            namedClses.add(superCls);
                        }
                    }
                }
            }
        }

        namedClses.remove(aClass);

        if (namedClses.size() == 0) {
            namedClses.add(owlModel.getRootCls());
        }
        for (Iterator it = namedClses.iterator(); it.hasNext();) {
            final RDFSNamedClass superClass = (RDFSNamedClass) it.next();
            aClass.addSuperclass(superClass);
            if (logging) {
                log("  + Added " + superClass.getBrowserText() + " to superclasses of " + aClass.getBrowserText());
            }
        }

        // Anonymous super classes
        for (Iterator it = anonClasses.iterator(); it.hasNext();) {
            final OntClass superOntClass = (OntClass) it.next();
            final RDFSClass superCls = (RDFSClass) getCls(superOntClass);
            aClass.addSuperclass(superCls);
            if (superCls instanceof OWLAnonymousClass && !aClass.isEditable()) {
                if (Jena.isImportedResource(getOntModel(), getOWLFullModel(), ontClass)) {
                    setNotEditable(superCls);
                }
            }
            if (logging) {
                log("  + Added anonymous class " + superCls.getBrowserText() + " to superclasses of " + ontClass);
            }
        }
    }


    private void createDisjointClasses(OntClass ontClass, OWLNamedClass cls) {
        for (Iterator it = ontClass.listDisjointWith(); it.hasNext();) {
            final OntClass disjointOntClass = (OntClass) it.next();
            final RDFSClass disjointClass = getRDFSClass(disjointOntClass);
            if (!cls.getDisjointClasses().contains(disjointClass)) {
                cls.addDisjointClass(disjointClass);
                if (disjointClass instanceof OWLAnonymousClass && !cls.isEditable()) {
                    setNotEditable(disjointClass);
                }
                if (logging) {
                    log("* Added " + disjointClass.getBrowserText() + " as disjoint class to " + cls.getBrowserText());
                }
            }
        }
    }


    private OWLEnumeratedClass createOWLEnumeratedClass(EnumeratedClass enumeratedClass) {
        Collection instances = new ArrayList();
        for (Iterator it = enumeratedClass.listOneOf(); it.hasNext();) {
            Resource value = (Resource) it.next();
            if (value.canAs(com.hp.hpl.jena.ontology.Individual.class)) {
                com.hp.hpl.jena.ontology.Individual individual = (com.hp.hpl.jena.ontology.Individual) value.as(com.hp.hpl.jena.ontology.Individual.class);
                Object instance = getRDFResource(individual);
                if (instance != null) {
                    instances.add(instance);
                }
            }
        }
        return owlModel.createOWLEnumeratedClass(instances);
    }


    private void createEquivalentClasses(OntClass ontClass, OWLNamedClass cls) {
        for (Iterator it = Jena.cloneIt(ontClass.listEquivalentClasses()); it.hasNext();) {
            final OntClass equivalentOntClass = (OntClass) it.next();
            final RDFSClass equivalentClass = getRDFSClass(equivalentOntClass);
            if (equivalentClass != null) {
                cls.addEquivalentClass(equivalentClass);
                if (equivalentClass instanceof OWLAnonymousClass &&
                        !cls.isEditable() &&
                        Jena.isImportedResource(getOntModel(), getOWLFullModel(), equivalentOntClass)) {
                    setNotEditable(equivalentClass);
                }
                if (logging) {
                    log("* Added " + equivalentClass.getBrowserText() + " as equivalent class to " + cls.getBrowserText());
                }
            }
        }
    }


    private OWLHasValue createHasValueRestriction(RDFProperty property, HasValueRestriction hasValueRestriction) {
        RDFNode hasValueNode = hasValueRestriction.getHasValue();
        if (hasValueNode instanceof Literal) {
            Literal literal = (Literal) hasValueNode;
            Object value = literal.getValue();
            return owlModel.createOWLHasValue(property, value);
        }
        else {
            RDFResource filler = (RDFResource) getRDFResource((com.hp.hpl.jena.ontology.Individual) hasValueNode.as(com.hp.hpl.jena.ontology.Individual.class));
            return owlModel.createOWLHasValue(property, filler);
        }
    }


    private Instance createInstance(Individual individual) {

        if (Jena.canAsOntClass(individual)) {
            final OntClass ontClass = Jena.asOntClass(individual);
            if (!Jena.isSystemClass(ontClass)) {
                return createRDFSClass(ontClass);
            }
            else {
                return null;
            }
        }
        else if (Jena.canAsOWLProperty(individual)) {
            final OntProperty ontProperty = Jena.asOntProperty(individual);
            if (!Jena.isSystemProperty(ontProperty)) {
                return createRDFProperty(ontProperty, getFrameNameForURI(ontProperty.getURI()));
            }
            else {
                return null;
            }
        }
        else {
            return createRDFIndividual(individual);
        }
    }


    private void createRDFIndividuals(OntModel ontModel) {

        for (Iterator it = Jena.cloneIt(ontModel.listIndividuals()); it.hasNext();) {
            Individual individual = (Individual) it.next();
            if (!individual.canAs(Ontology.class) && !individual.canAs(AllDifferent.class)) {
                String ns = individual.getNameSpace();
                if (!OWL.getURI().equals(ns) && !RDFS.getURI().equals(ns) && !RDF.getURI().equals(ns) && individual.getRDFType() != null) {
                    getRDFResource(individual);
                }
            }
        }

        /* Iterate on all instances of all user-defined rdfs:Classes
        OntClass rdfsMetaclass = ontModel.getOntClass(RDFS.Class.getURI());
        Iterator classes = rdfsMetaclass.listInstances();
        while (classes.hasNext()) {
            Resource c = (Resource) classes.next();
            String ns = c.getNameSpace();
            if (!OWL.getURI().equals(ns) && !RDFS.getURI().equals(ns) && !RDF.getURI().equals(ns)) {
                if (Jena.canAsOntClass(c)) {
                    OntClass ontClass = Jena.asOntClass(c);
                    Iterator instances = ontClass.listInstances();
                    while (instances.hasNext()) {
                        Resource instance = (Resource) instances.next();
                        getRDFResource(instance);
                    }
                }
            }
        } */
    }


    private OWLIntersectionClass createIntersectionCls(IntersectionClass intersectionClass) {
        OWLIntersectionClass intersectionCls = owlModel.createOWLIntersectionClass();
        createLogicalClsOperands(intersectionClass, intersectionCls);
        if (logging) {
            log("+ Created intersection class " + intersectionCls.getBrowserText() + " for " + intersectionClass);
        }
        return intersectionCls;
    }


    private void createLogicalClsOperands(BooleanClassDescription booleanClass, OWLLogicalClass logicalCls) {
        for (Iterator it = booleanClass.listOperands(); it.hasNext();) {
            Resource next = (Resource) it.next();
            OntClass operandOntClass = Jena.asOntClass(next);
            RDFSClass operandClass = (RDFSClass) getCls(operandOntClass);
            if (operandClass != null) {
                if (logicalCls instanceof OWLNAryLogicalClass) {
                    ((OWLNAryLogicalClass) logicalCls).addOperand(operandClass);
                }
                else {
                    ((OWLComplementClass) logicalCls).setComplement(operandClass);
                    return;
                }
            }
        }
    }


    private OWLDataRange createOWLDataRange(DataRange dataRange) {
        List rdfsLiterals = new ArrayList();
        com.hp.hpl.jena.rdf.model.RDFList oneOf = dataRange.getOneOf();
        if (oneOf != null) {
            Iterator it = oneOf.iterator();
            while (it.hasNext()) {
                Literal literal = (Literal) it.next();
                rdfsLiterals.add(createRDFSLiteral(literal));
            }
        }
        return owlModel.createOWLDataRange((RDFSLiteral[]) rdfsLiterals.toArray(new RDFSLiteral[0]));
    }


    private RDFSLiteral createRDFSLiteral(Literal literal) {
        if (literal.getLanguage() != null && literal.getLanguage().length() > 0) {
            return owlModel.createRDFSLiteral(literal.getString(), literal.getLanguage());
        }
        else if (literal.getDatatypeURI() != null) {
            RDFSDatatype datatype = owlModel.getRDFSDatatypeByURI(literal.getDatatypeURI());
            return owlModel.createRDFSLiteral(literal.getLexicalForm(), datatype);
        }
        else {
            return owlModel.createRDFSLiteral(literal.getValue());
        }
    }


    /*private Object createPropertyValue(Literal literal) {
        if (literal.getLanguage() != null && literal.getLanguage().length() > 0) {
            return owlModel.createRDFSLiteralOrString(literal.getString(), literal.getLanguage());
        }
        else if (literal.getDatatypeURI() != null) {
            RDFSDatatype datatype = owlModel.getRDFSDatatypeByURI(literal.getDatatypeURI());
            return owlModel.createRDFSLiteral(literal.getLexicalForm(), datatype);
        }
        else {
            return owlModel.createRDFSLiteral(literal.getValue());
        }
    } */

    private RDFSNamedClass createRDFSNamedClass(OntClass ontClass) {

        final String classURI = ontClass.getURI();
        final String className = getFrameNameForURI(classURI);
        RDFSNamedClass aClass = null;
        Resource type = getPrimaryType(ontClass);
        RDFSClass directType = getRDFSClass((OntClass) type.as(OntClass.class));
        if (logging) {
            log("+ Created named class " + className + " with type " + directType.getBrowserText());
        }
        aClass = (RDFSNamedClass) owlModel.createCls(className, Collections.EMPTY_LIST, directType, false);

        /*if (ontClass.hasProtegeType(OWL.Class)) {
            aClass = (OWLNamedClass) owlModel.createCls(className, Collections.EMPTY_LIST, owlModel.getOWLNamedClassClass(), false);
            if (logging) {
                log("+ Created named owl:Class: " + className + " for " + classURI);
            }
        }
        else {
            aClass = (RDFSNamedClass) owlModel.createCls(className, Collections.EMPTY_LIST, owlModel.getRDFSNamedClassClass(), false);
            if (logging) {
                log("+ Created named rdfs:Class: " + className + " for " + classURI);
            }
        } */

        setIncludedIfNotInBaseModel(ontClass, aClass);

        if (ontClass.hasRDFType(OWL.DeprecatedClass)) {
            aClass.setDeprecated(true);
        }

        setRDFTypes(ontClass, aClass);
        createDirectSuperclasses(ontClass, aClass);

        if (aClass instanceof OWLNamedClass) {
            OWLNamedClass namedCls = (OWLNamedClass) aClass;
            createEquivalentClasses(ontClass, namedCls);
            createDisjointClasses(ontClass, namedCls);
        }

        addPropertyValues(ontClass, aClass);

        return aClass;
    }


    private OntClass getPrimaryType(OntResource resource) {
        for (int i = 0; i < primaryTypes.length; i++) {
            Resource type = primaryTypes[i];
            if (!getOWLFullModel().contains(resource, RDF.type, type)) {
                if (getOntModel().contains(resource, RDF.type, type)) {
                    return getOntModel().getOntClass(type.getURI());
                }
            }
        }
        return getOntModel().getOntClass(resource.getRDFType().getURI());
    }


    private void createOntologies(OntModel ontModel) {
        for (Iterator it = ontModel.listOntologies(); it.hasNext();) {
            Ontology ontology = (Ontology) it.next();
            String uri = ontology.getURI();
            if (uri != null) {
                OWLOntology owlOntology = owlModel.getOWLOntologyByURI(uri);
                if (owlOntology == null) {
                    createOWLOntology(ontology);
                }
                //else {
                //    addPropertyValues(ontology, owlOntology);
                //}
            }
            else {
                logError("owl:Ontology without URI will be ignored: " + ontology);
            }
        }
    }


    private OWLOntology createOWLOntology(Ontology ontology) {

        String uri = ontology.getURI();
        if (uri == null) {
            return null;
        }
        else {
            String defaultNamespace = owlModel.getNamespaceManager().getDefaultNamespace();
            String match = uri;
            if (!Jena.isNamespaceWithSeparator(match)) {
                match += Jena.DEFAULT_NAMESPACE_SEPARATOR;
            }
            OWLOntology oi;
            if (defaultNamespace.equals(match)) {
                oi = owlModel.getDefaultOWLOntology();
            }
            else {
                String prefix = ontModel.getNsURIPrefix(match);
                log("+ Created OWLOntology for " + match + " (prefix: " + prefix + ")");
                oi = owlModel.createOWLOntology(prefix);
                setIncludedIfNotInBaseModel(ontology, oi);
            }
            addPropertyValues(ontology, oi);
            return oi;
        }
    }


    private RDFProperty createRDFProperty(String propertyName, OntProperty property) {
        OntClass type = getPrimaryType(property);
        RDFSClass directType = getRDFSClass(type);
        RDFProperty rdfProperty = (RDFProperty) owlModel.createSlot(propertyName, directType);
        if (logging) {
            log("+ Created property " + propertyName + " with rdf:type " + directType.getBrowserText());
        }
        createSuperproperties(property, rdfProperty);
        setRDFPropertyRanges(rdfProperty, property);
        setRDFTypes(property, rdfProperty);
        setInverseProperty(property, rdfProperty);

        addTemplateSlotsForDomain(property, rdfProperty);
        return rdfProperty;
    }


    private void setRDFPropertyRanges(RDFProperty rdfProperty, OntProperty property) {
        if (property.getRange() == null || property.hasRange(RDFS.Literal)) {
            // Leave range empty
        }
        else {
            Collection ranges = new ArrayList();
            for (Iterator it = property.listPropertyValues(RDFS.range); it.hasNext();) {
                Resource range = (Resource) it.next();
                Object resource = getRDFResource(range);
                if (resource != null) {
                    ranges.add(resource);
                }
            }
            rdfProperty.setPropertyValues(owlModel.getRDFSRangeProperty(), ranges);
        }
    }


    private OWLRestriction createOWLRestriction(Restriction restriction) {
        RDFProperty property = getRDFProperty(restriction.getOnProperty());
        if (restriction.isAllValuesFromRestriction()) {
            return createOWLAllValuesFrom(property, restriction.asAllValuesFromRestriction());
        }
        else if (restriction.isSomeValuesFromRestriction()) {
            return createOWLSomeValuesFrom(property, restriction.asSomeValuesFromRestriction());
        }
        else if (restriction.isHasValueRestriction()) {
            return createHasValueRestriction(property, restriction.asHasValueRestriction());
        }
        else if (restriction.isCardinalityRestriction()) {
            return owlModel.createOWLCardinality(property, restriction.asCardinalityRestriction().getCardinality());
        }
        else if (restriction.isMaxCardinalityRestriction()) {
            return owlModel.createOWLMaxCardinality(property, restriction.asMaxCardinalityRestriction().getMaxCardinality());
        }
        else if (restriction.isMinCardinalityRestriction()) {
            return owlModel.createOWLMinCardinality(property, restriction.asMinCardinalityRestriction().getMinCardinality());
        }
        throw new IllegalArgumentException("Unexpected OWLRestriction type for " + restriction.getRDFType());
    }


    private RDFIndividual createRDFIndividual(Individual individual) {
        String uri = individual.getURI();
        String name = getFrameNameForURI(uri);
        return createRDFIndividual(individual, name, uri);
    }


    private int anonIndex = 1;


    private RDFIndividual createRDFIndividual(com.hp.hpl.jena.ontology.Individual individual, String name, String uri) {
        RDFIndividual result = (RDFIndividual) anonResource2RDFResource.get(individual);
        if (result != null) {
            return result;
        }
        Collection types = new HashSet();
        for (Iterator it = individual.listRDFTypes(true); it.hasNext();) {
            Resource rdfType = (Resource) it.next();
            if (Jena.canAsOntClass(rdfType)) {
                OntClass ontClass = Jena.asOntClass(rdfType);
                Cls type = getCls(ontClass);
                types.add(type);
            }
            // else: Usually only owl:Thing
        }
        Cls type = null;
        if (types.size() > 0) {
            type = (Cls) types.iterator().next();
            types.remove(type);
        }
        else {
            type = owlModel.getRootCls();
        }
        RDFIndividual instance = null;
        if (name != null) {
            instance = (RDFIndividual) owlModel.getInstance(name);  // Perhaps it was created in the meantime
        }
        if (instance == null) {
            if (name == null) {
                // Weird case: listIndividuals in JenaNormalizer did not deliver this
                do {
                    name = AbstractOWLModel.ANONYMOUS_BASE + anonIndex++;
                }
                while (owlModel.getFrame(name) != null ||
                        getOntModel().getIndividual(owlModel.getURIForResourceName(name)) != null);
                final String newURI = owlModel.getURIForResourceName(name);
                individual = (com.hp.hpl.jena.ontology.Individual) Jena.renameResource(getOntModel(),
                        individual, newURI).as(com.hp.hpl.jena.ontology.Individual.class);
            }
            if (uri != null) {
                log("+ Created individual " + name + " of type " + type + " for " + uri);
            }
            else {
                Resource rdfType = individual.getRDFType();
                if (rdfType == null) {
                    log("+ Created instance " + name + " of type " + type + " for typeless anonymous resource");
                }
                else {
                    log("+ Created instance " + name + " of type " + type + " for anonymous " + rdfType);
                }
            }
            instance = (RDFIndividual) owlModel.createInstance(name, type, false);
            anonResource2RDFResource.put(individual, instance);
            for (Iterator it = types.iterator(); it.hasNext();) {
                RDFSClass cls = (RDFSClass) it.next();
                instance.addProtegeType(cls);
                log("  + Added direct type " + cls.getBrowserText());
            }
            addPropertyValues(individual, instance);
            setIncludedIfNotInBaseModel(individual, instance);
        }
        //if (instance instanceof RDFList) {
        //    registerRDFList((RDFList) instance, individual);
        //}
        return instance;
    }


    private RDFProperty createRDFProperty(OntProperty property, String slotName) {
        RDFProperty rdfProperty = createRDFProperty(slotName, property);
        addPropertyValues(property, rdfProperty);
        setIncludedIfNotInBaseModel(property, rdfProperty);
        return rdfProperty;
    }


    private void createRDFProperties(OntModel ontModel) {
        for (Iterator it = ontModel.listOntProperties(); it.hasNext();) {
            OntProperty ontProperty = (OntProperty) it.next();
            if (ontProperty.canAs(DatatypeProperty.class)) {
                if (!Jena.isSystemProperty(ontProperty)) {
                    getOWLProperty(ontProperty);
                }
            }
            else if (ontProperty.canAs(ObjectProperty.class)) {
                if (!Jena.isSystemProperty(ontProperty)) {
                    getOWLProperty(ontProperty);
                }
            }
            else { // Plain RDF Property
                if (!Jena.isSystemProperty(ontProperty)) {
                    getRDFProperty(ontProperty);
                }
            }
        }
    }


    private OWLSomeValuesFrom createOWLSomeValuesFrom(RDFProperty property, SomeValuesFromRestriction someValuesFromRestriction) {
        Resource someValuesFrom = someValuesFromRestriction.getSomeValuesFrom();
        RDFResource filler = (RDFResource) getRDFResource(someValuesFrom);
        return owlModel.createOWLSomeValuesFrom(property, (RDFResource) filler);
    }


    private void createSuperproperties(OntProperty property, RDFProperty rdfProperty) {
        for (Iterator it = property.listSuperProperties(true); it.hasNext();) {
            OntProperty superProperty = (OntProperty) it.next();
            RDFProperty superSlot = getRDFProperty(superProperty);
            rdfProperty.addSuperproperty(superSlot);
            log("* Added " + superSlot.getName() + " to super slots of " + rdfProperty.getName());
        }
    }


    private OWLUnionClass createUnionCls(UnionClass unionClass) {
        OWLUnionClass unionCls = owlModel.createOWLUnionClass();
        createLogicalClsOperands(unionClass, unionCls);
        return unionCls;
    }


    private Cls getCls(OntClass ontClass) {
        Cls cls = getCls2(ontClass);
        if (cls == null) {
            cls = createRDFSClass(ontClass);
        }
        return cls;
    }


    public Cls getCls2(OntClass ontClass) {
        if (ontClass == null) {
            return null;
        }
        else {
            if (ontClass.isAnon()) {
                return (Cls) ontClass2Cls.get(ontClass);
            }
            else {
                final String uri = ontClass.getURI();
                final String frameName = getFrameNameForURI(uri);
                if (frameName != null) {
                    return owlModel.getCls(frameName);
                }
                else {
                    return null;
                }
            }
        }
    }


    private String getFrameNameForURI(String uri) {
        return getFrameNameForURI(uri, true);
    }


    private String getFrameNameForURI(String uri, boolean generatePrefix) {
        String result = (String) uri2FrameName.get(uri);
        if (result == null) {
            result = owlModel.getFrameNameForURI(uri, generatePrefix);
            if (result != null) {
                uri2FrameName.put(uri, result);
            }
        }
        return result;
    }


    //private RDFList getRDFList(Individual individual) {
    //    for (Iterator it = owlModel.getRDFListClass().getInstances(true).iterator(); it.hasNext();) {
    //        RDFList listInstance = (RDFList) it.next();
    //        if (individual.equals(getRDFList(listInstance))) {
    //            return listInstance;
    //        }
    //    }
    //    return null;
    //}


    public static String getOntPolicyFilePath(Project project) {
        String str = project.getSources().getString(ONT_POLICY_PROPERTY);
        if (str == null) {
            return DEFAULT_ONT_POLICY_FILE_PATH;
        }
        else {
            return str;
        }
    }


    private RDFSClass getRDFSClass(OntClass ontClass) {
        return (RDFSClass) getCls(ontClass);
    }


    private OWLProperty getOWLProperty(Property property) {
        String slotURI = property.getURI();
        String slotName = getFrameNameForURI(slotURI);
        OWLProperty owlProperty = owlModel.getOWLProperty(slotName);
        if (owlProperty == null && property instanceof OntProperty) {
            RDFProperty newProperty = createRDFProperty((OntProperty) property, slotName);
            if (newProperty instanceof OWLProperty) {
                owlProperty = (OWLProperty) newProperty;
            }
        }
        return owlProperty;
    }


    private RDFProperty getRDFProperty(Property property) {
        String slotURI = property.getURI();
        String slotName = getFrameNameForURI(slotURI);
        RDFProperty rdfProperty = owlModel.getRDFProperty(slotName);
        if (rdfProperty == null && property instanceof OntProperty) {
            rdfProperty = createRDFProperty((OntProperty) property, slotName);
        }
        return rdfProperty;
    }


    private Object getRDFResource(Resource resource) {
        if (Jena.canAsOntProperty(resource)) {
            return getRDFProperty((Property) resource.as(Property.class));
        }
        else if (Jena.canAsObjectProperty(resource) || Jena.canAsDatatypeProperty(resource)) {
            return getOWLProperty((OntProperty) resource.as(OntProperty.class));
        }
        else if (Jena.canAsOntClass(resource)) {
            return getRDFSClass(Jena.asOntClass(resource));
        }
        else if (resource.canAs(Ontology.class)) {
            OWLOntology owlOntology = owlModel.getOWLOntologyByURI(resource.getURI());
            if (owlOntology == null) {
                Ontology ontology = (Ontology) resource.as(Ontology.class);
                owlOntology = createOWLOntology(ontology);
            }
            return owlOntology;
        }
        else if (resource.canAs(DataRange.class)) {
            return createOWLDataRange((DataRange) resource.as(DataRange.class));
        }
        else if (resource.canAs(Individual.class)) {
            Individual individual = (Individual) resource.as(Individual.class);
            if (resource.isAnon()) {
                return createAnonymousRDFIndividual(individual);
            }
            else {
                String instanceURI = resource.getURI();
                String name = getFrameNameForURI(instanceURI, true); // false);
                Frame frame = name == null ? null : owlModel.getFrame(name);
                if (frame instanceof RDFResource) {
                    return (RDFResource) frame;
                }
                else {
                    //if (instanceURI == null) {
                    //    RDFList li = getRDFList(individual);
                    //    if (li != null) {
                    //        return li;
                    //    }
                    //    else {
                    //        return createAnonymousRDFIndividual(individual);
                    //    }
                    //}
                    //else {
                    Instance instance = name == null ? null : owlModel.getInstance(name);
                    if (instance == null) {
                        if (individual.getRDFType() != null) {
                            getFrameNameForURI(instanceURI, true);
                            instance = createInstance(individual);
                        }
                        else {
                            RDFExternalResource externalResource = owlModel.getRDFExternalResource(resource.getURI());
                            if (externalResource == null) {
                                externalResource = owlModel.createRDFExternalResource(resource.getURI());
                            }
                            return externalResource;
                        }
                    }
                    if (instance instanceof RDFResource) {
                        return (RDFResource) instance;
                    }
                    //}
                }
            }
        }
        logError("Could not get RDFResource for " + resource.getURI());
        return null;
    }


    public static boolean isSpecialProperty(Resource resource) {
        return specialProperties.contains(resource);
    }


    public static void loadFile(JenaOWLModel owlModel, URI uri,
                                String language) throws Exception {
        new JenaLoader(owlModel, uri, language);
    }


    private static void log(String message) {
        if (logging) {
            System.out.println("[JenaLoader]  " + message);
        }
    }


    private static void logError(String message) {
        System.err.println("[JenaLoader]  Warning: " + message);
    }


    /**
     * Establishes the link between a Cls and an OntClass.
     * This must be called when either one has been created for the other one.
     * Technically, this puts bidirectional links into a hashtable, if cls is anonymous.
     * Otherwise, no hashing is required because the reference can be resolved by name.
     * This method is usually not needed by API users.
     *
     * @param cls      the Protege Cls
     * @param ontClass the Jena OntClass
     */
    public void registerOntClass(Cls cls, OntClass ontClass) {
        if (cls instanceof OWLAnonymousClass) {
            ontClass2Cls.put(ontClass, cls);
        }
    }


    private void renameResourcesWithIllegalNames(OntModel ontModel) {
        renameResourcesWithIllegalNames(ontModel.listNamedClasses());
        renameResourcesWithIllegalNames(ontModel.listDatatypeProperties());
        renameResourcesWithIllegalNames(ontModel.listObjectProperties());
        renameResourcesWithIllegalNames(ontModel.listIndividuals());
    }


    private void renameResourcesWithIllegalNames(Iterator resources) {
        for (Iterator it = cloneIt(resources); it.hasNext();) {
            Resource resource = (Resource) it.next();
            if (!resource.canAs(Ontology.class)) {
                String namespace = resource.getNameSpace();
                if (namespace != null) {  // Anonymous class might be interpreted as individual
                    String newURI = renameResourcesHelper(resource, owlModel);
                    if (newURI != null) {
                        ResourceUtils.renameResource(resource, newURI);
                    }
                }
            }
        }
    }


    // Public for testing purposes only
    public static String renameResourcesHelper(Resource resource, AbstractOWLModel owlModel) {
        String namespace = resource.getNameSpace();
        String localName = resource.getLocalName();
        if (localName.length() == 0) {
            String uri = resource.getURI();
            int index = uri.lastIndexOf("#");
            if (index >= 0) {
                namespace = uri.substring(0, index + 1);
                localName = uri.substring(index + 1);
            }
        }
        if (!Jena.isNamespaceWithSeparator(namespace)) {
            throw new IllegalArgumentException("Cannot load ontology: Resource " + localName +
                    " has an invalid namespace \"" + namespace + "\"");
        }
        if (!AbstractOWLModel.isValidOWLFrameName(owlModel.getNamespaceManager(), localName)) {
            String validName = AbstractOWLModel.getValidOWLFrameName(owlModel, localName);
            String newURI = namespace + validName;
            logError("Invalid resource named " + resource.getURI() + " renamed to " + newURI);
            return newURI;
        }
        return null;
    }


    private void setIncludedIfNotInBaseModel(OntResource ontResource, Frame frame) {
        if (hasImports && isImportedResource(ontResource)) {
            frame.setIncluded(true);
        }
    }


    private void setInverseProperty(OntProperty property, RDFProperty rdfProperty) {
        if (property.hasInverse()) {
            Property inverseProperty = (Property) property.getInverse();
            RDFProperty inverseRDFProperty = getRDFProperty(inverseProperty);
            rdfProperty.setInverseProperty(inverseRDFProperty);
        }
    }


    public static void setOntPolicyFilePath(Project project, String path) {
        project.getSources().setString(ONT_POLICY_PROPERTY, path);
    }


    private void setNotEditable(Cls cls) {
        cls.setEditable(false);
        if (cls instanceof OWLAnonymousClass) {
            OWLAnonymousClass anonCls = (OWLAnonymousClass) cls;
            for (Iterator it = anonCls.getDependingClasses().iterator(); it.hasNext();) {
                Cls d = (Cls) it.next();
                d.setEditable(false);
            }
        }
    }


    private void setRDFTypes(OntResource ontResource, RDFResource instance) {
        for (StmtIterator it = ontResource.listProperties(RDF.type); it.hasNext();) {
            Statement s = it.nextStatement();
            if (!getOWLFullModel().contains(s)) {
                Resource type = (Resource) s.getObject();
                if (Jena.canAsOntClass(type)) {
                    RDFSClass metaclass = getRDFSClass(Jena.asOntClass(type));
                    if (!instance.hasProtegeType(metaclass)) {
                        instance.addProtegeType(metaclass);
                        log("  + Added " + metaclass.getBrowserText() + " to rdf:types of " + instance.getBrowserText());
                    }
                }
            }
        }
    }


    private static void updateLoggingStatus() {
        String str = ApplicationProperties.getString(LOGGING_PROPERTY, "false");
        logging = str != null && str.equalsIgnoreCase("true");
    }


    /**
     * The OntModel that is synchronized with this KnowledgeBase
     */
    private OntModel ontModel;

    /**
     * The Model that is added to represent owl:Class as OntClass, and to hold additional
     * triples so that metaclass instances can be handled as OntClasses etc.
     */
    private com.hp.hpl.jena.rdf.model.Model owlFullModel;


    public void dumpRDF() {
        try {
            String namespace = owlModel.getNamespaceManager().getDefaultNamespace();
            final String language = FileUtils.langXMLAbbrev;

            System.out.println("OntModel:");
            RDFWriter writer = ontModel.getWriter(language);
            Jena.prepareWriter(writer, language, namespace);
            writer.write(ontModel.getBaseModel(), System.out, namespace);

            System.out.println("OWL Full Model:");
            writer = owlFullModel.getWriter(language);
            Jena.prepareWriter(writer, language, namespace);
            writer.write(owlFullModel, System.out, namespace);
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }


    private void ensureDefaultJenaOntologyExists() {
        if (getDefaultJenaOntology() == null) {
            String uri = owlModel.getNamespaceManager().getDefaultNamespace();
            if (uri.endsWith(Jena.DEFAULT_NAMESPACE_SEPARATOR)) {
                uri = uri.substring(0, uri.length() - 1);
            }
            ontModel.createOntology(uri);
            // System.err.println("[JenaOWLModel]  Created default ontology: " + uri);
        }
    }


    /**
     * Gets the default Ontology object in this project.
     *
     * @return the Ontology or null (should never happen)
     */
    public Ontology getDefaultJenaOntology() {
        String namespace = owlModel.getNamespaceManager().getDefaultNamespace();
        return Jena.getDefaultJenaOntology(namespace, ontModel);
    }


    /**
     * Gets the URI of the model that contains the "definition" of an (imported)
     * instance.  This is the model where the rdf:type triple of it appears.
     * This will return the default namespace URI if this is not imported.
     *
     * @param instance the instance to get the source URI from
     * @return the URI  (typically ending with #)
     */
    public URI getImportSource(RDFResource instance) {
        try {
            OntResource ontResource = (OntClass) ontModel.getResource(instance.getURI()).as(OntClass.class);
            String uriString = Jena.getImportSource(ontModel, ontResource);
            return new URI(uriString);
        }
        catch (Exception ex) {
        }
        return null;
    }


    public Individual getIndividual(Instance instance) {
        Assert.assertTrue(instance instanceof RDFResource);
        String individualName = ((RDFResource) instance).getURI();
        return (Individual) ontModel.getResource(individualName).as(Individual.class);
    }


    /**
     * Gets the internal Model that is used to store additional triples which make the
     * instances of user-defined metaclasses real metaclass instances in Jena.
     * This method is usually only for testing purposes.
     *
     * @return the internal OWL Full model
     */
    public com.hp.hpl.jena.rdf.model.Model getOWLFullModel() {
        return owlFullModel;
    }


    public boolean isImportedResource(OntResource ontResource) {
        return Jena.isImportedResource(ontModel, owlFullModel, ontResource);
    }


    public Resource getValueTypeResource(ValueType valueType) {
        String uri = owlModel.getValueTypeURI(valueType);
        return ontModel.getResource(uri);
    }


    public static void initCache(Project project, OntDocumentManager docManager) {

        String applDir = ApplicationProperties.getApplicationDirectory().getAbsolutePath();
        String protege = new File(new File(new File(applDir, "plugins"),
                JenaLoader.ROOT_FOLDER), "protege.owl").toURI().toString();
        docManager.addAltEntry("http://protege.stanford.edu/plugins/owl/protege", protege);

        //"file:" + applDir + "/plugins/" + JenaLoader.ROOT_FOLDER + "/protege.owl");
        String swrl = new File(new File(new File(applDir, "plugins"),
                JenaLoader.ROOT_FOLDER), "swrl.owl").toURI().toString();
        docManager.addAltEntry(SWRLNames.SWRL_IMPORT, swrl);
        String swrlb = new File(new File(new File(applDir, "plugins"),
                JenaLoader.ROOT_FOLDER), "swrlb.owl").toURI().toString();
        docManager.addAltEntry(SWRLNames.SWRLB_IMPORT, swrlb);
        try {
            com.hp.hpl.jena.rdf.model.Model ontPolicy = OntPolicy.loadOntPolicy(project);
            Iterator it = OntPolicy.listOntologySpecs(ontPolicy);
            while (it.hasNext()) {
                Resource ontologySpec = (Resource) it.next();
                String uri = OntPolicy.getPublicURL(ontologySpec);
                String altURI = OntPolicy.getAltURL(ontologySpec);
                if (altURI != null && uri != null) {
                    docManager.addAltEntry(uri, altURI);
                    //System.out.println("[JenaOWLModel.initCache] Using alias:");
                    //System.out.println("[JenaOWLModel.initCache]   publicURI: " + uri);
                    //System.out.println("[JenaOWLModel.initCache]   altURI: " + altURI);
                }
            }
        }
        catch (Exception ex) {
            // ex.printStackTrace();
            System.err.println("[JenaOWLModel.initCache] Warning: " + ex);
        }
        String owlURI = OWL.getURI();
        docManager.addIgnoreImport(owlURI.substring(0, owlURI.length() - 1));
        String rdfsURI = RDFS.getURI();
        docManager.addIgnoreImport(rdfsURI.substring(0, rdfsURI.length() - 1));
        docManager.setCacheModels(false);
        docManager.setProcessImports(true);
    }


    public OntModel getOntModel() {
        return ontModel;
    }
}
