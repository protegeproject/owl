package edu.stanford.smi.protegex.owl.model.impl.tests;

import edu.stanford.smi.protegex.owl.model.RDFExternalResource;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultRDFExternalResourceTestCase extends AbstractJenaTestCase {

    public void testSetURI() {
        String oldURI = "http://aldi.de";
        RDFExternalResource eri = owlModel.createRDFExternalResource(oldURI);
        assertEquals(oldURI, eri.getResourceURI());
        String newURI = "http://neo.de";
        eri.setResourceURI(newURI);
        assertEquals(newURI, eri.getResourceURI());
    }


    public void testGetBrowserText() {
        String oldURI = "http://aldi.de";
        RDFExternalResource eri = owlModel.createRDFExternalResource(oldURI);
        assertEquals(oldURI, eri.getBrowserText());
    }
}
