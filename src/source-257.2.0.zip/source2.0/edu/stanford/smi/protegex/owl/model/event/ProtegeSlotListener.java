package edu.stanford.smi.protegex.owl.model.event;

import edu.stanford.smi.protege.event.SlotListener;
import edu.stanford.smi.protege.event.SlotEvent;

/**
 * An interface that wraps the core Protege SlotListener to declare
 * those methods deprecated that should not be used with OWL.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface ProtegeSlotListener extends SlotListener {


    /**
     * @deprecated
     * @see PropertyListener#unionDomainClassAdded
     */
    void templateSlotClsAdded(SlotEvent event);

    /**
     * @deprecated
     * @see PropertyListener#unionDomainClassRemoved
     */
    void templateSlotClsRemoved(SlotEvent event);

    /**
     * @deprecated
     * @see PropertyListener#subpropertyAdded
     */
    void directSubslotAdded(SlotEvent event);

    /**
     * @deprecated
     * @see PropertyListener#subpropertyRemoved
     */
    void directSubslotRemoved(SlotEvent event);


    /**
     * @deprecated  not supported in OWL
     */
    void directSubslotMoved(SlotEvent event);

    /**
     * @deprecated
     * @see PropertyListener#superpropertyAdded
     */
    void directSuperslotAdded(SlotEvent event);

    /**
     * @deprecated
     * @see PropertyListener#superpropertyRemoved
     */
    void directSuperslotRemoved(SlotEvent event);
}
