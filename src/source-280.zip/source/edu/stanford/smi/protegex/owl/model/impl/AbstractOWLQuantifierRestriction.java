package edu.stanford.smi.protegex.owl.model.impl;

import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protegex.owl.compactparser.OWLCompactParser;
import edu.stanford.smi.protegex.owl.compactparser.ParseException;
import edu.stanford.smi.protegex.owl.compactparser.Token;
import edu.stanford.smi.protegex.owl.model.*;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;

/**
 * The common base class of DefaultOWLAllValuesFrom and DefaultOWLSomeValuesFrom.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public abstract class AbstractOWLQuantifierRestriction extends AbstractOWLRestriction
        implements OWLQuantifierRestriction {


    AbstractOWLQuantifierRestriction(KnowledgeBase kb, FrameID id) {
        super(kb, id);
    }


    AbstractOWLQuantifierRestriction() {
    }


    public void checkFillerText(String text) throws Exception {
        final RDFProperty slot = getOnProperty();
        if (slot != null) {
            checkFillerText(text, slot);
        }
        else {
            checkFillerText(text, slot, (OWLModel) getKnowledgeBase());
        }
    }


    public static void checkFillerText(String text, final RDFProperty property) throws ParseException {
        checkFillerText(text, property, property.getOWLModel());
    }


    public static void checkFillerText(String text, RDFProperty property, OWLModel owlModel) throws ParseException {
        if (text.startsWith(XSDNames.PREFIX)) {
            if (property instanceof OWLObjectProperty) {
                OWLCompactParser.errorMessage = text + " cannot be applied to object properties";
                throw new ParseException();
            }
            OWLCompactParser.checkValueType(owlModel, text);
        }
        else {
            if (property instanceof OWLDatatypeProperty) {
                OWLCompactParser.errorMessage = text + " cannot be applied to datatype properties";
                throw new ParseException();
            }
            OWLCompactParser.checkClass(owlModel, text);
        }
    }


    public String getBrowserText() {
        String filler = "?";
        if (isDefined()) {
            RDFResource resource = getFiller();
            if (resource instanceof RDFSClass) {
                RDFSClass fillerClass = (RDFSClass) resource;
                if (fillerClass != null) {
                    filler = fillerClass.getNestedBrowserText();
                }
                else {
                    filler = "<null>";
                }
            }
            else {
                filler = getFillerText();
            }
        }
        return getOperator() + " " + getBrowserTextPropertyName() + " " + filler;
    }


    public Collection getDependingClasses() {
        if (getFiller() instanceof OWLAnonymousClass) {
            return Collections.singleton(getFiller());
        }
        else {
            return Collections.EMPTY_LIST;
        }
    }


    public RDFResource getFiller() {
        return (RDFResource) getPropertyValue(getFillerProperty());
    }


    public String getFillerText() {
        RDFResource filler = getFiller();
        if (filler != null) {
            return filler.getBrowserText();
        }
        else {
            return "";
        }
    }


    public void getNestedNamedClasses(Set set) {
        if (getFiller() instanceof RDFSClass) {
            ((RDFSClass) getFiller()).getNestedNamedClasses(set);
        }
    }


    public void setFiller(RDFResource filler) {
        setPropertyValue(getFillerProperty(), filler);
    }


    public void setFillerText(String text) throws Exception {
        OWLModel kb = getOWLModel();
        if (text.startsWith(XSDNames.PREFIX)) {
            Object valueType = OWLCompactParser.parseValueType(kb, text);
            if (valueType instanceof RDFSDatatype) {
                setFiller((RDFSDatatype) valueType);
            }
            else {
                OWLDataRange dataRange = getOWLModel().createOWLDataRange((RDFSLiteral[]) valueType);
                setFiller(dataRange);
            }
        }
        else {
            RDFSClass filler = OWLCompactParser.parseCls(kb, text);
            setFiller(filler);
        }
    }


    static void throwParseException(String text) throws ParseException {
        ParseException ex = new ParseException();
        ex.currentToken = new Token();
        ex.currentToken.image = text;
        OWLCompactParser.errorMessage = "Unknown datatype";
        throw ex;
    }
}
