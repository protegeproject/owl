package edu.stanford.smi.protegex.owl.jena.parser.tests;

import edu.stanford.smi.protegex.owl.model.OWLObjectProperty;
import edu.stanford.smi.protegex.owl.model.RDFProperty;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadOWLDeprecatedPropertyTestCase extends AbstractProtegeOWLParserTestCase {


    public void testLoadDeprecatedProperty() throws Exception {
        loadRemoteOntology("deprecated.owl");
        assertTrue(owlModel.getSlot("drives") instanceof OWLObjectProperty);
        RDFProperty property = (RDFProperty) owlModel.getSlot("hasDriver");
        assertNotNull(property);
        // assertFalse(property instanceof OWLObjectProperty);
        assertTrue(property.isDeprecated());
    }
}
