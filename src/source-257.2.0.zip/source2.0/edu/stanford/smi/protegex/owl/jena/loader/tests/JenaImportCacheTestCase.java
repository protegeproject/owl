package edu.stanford.smi.protegex.owl.jena.loader.tests;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.graph.impl.SimpleGraphMaker;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntDocumentManager;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.impl.ModelMakerImpl;
import com.hp.hpl.jena.util.FileUtils;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;
import edu.stanford.smi.protegex.owl.jena.Jena;
import junit.framework.TestCase;

import java.util.Collection;
import java.util.Iterator;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class JenaImportCacheTestCase extends TestCase {

    public void testImportCache() {
        final String BASE = "http://protege.stanford.edu/plugins/owl/testdata/";
        OntModelSpec spec = new OntModelSpec(OntModelSpec.OWL_MEM);
        spec.setReasoner(null);
        OntDocumentManager dm = OntDocumentManager.getInstance();
        dm.reset();
        dm.setCacheModels(false);
        spec.setDocumentManager(dm);

        OntModel oldOntModel = ModelFactory.createOntologyModel(spec, null);
        oldOntModel.read(BASE + "Import-normalizerBug.owl", FileUtils.langXMLAbbrev);
        Graph oldSubGraph = (Graph) oldOntModel.getSubGraphs().iterator().next();
        final int oldTripleCount = getTripleCount(oldSubGraph);
        OntClass ontClass = oldOntModel.getOntClass(BASE + "normalizerBug.owl#SuperClass");
        oldSubGraph.add(new Triple(ontClass.getNode(), RDF.type.getNode(), OWL.DeprecatedClass.getNode()));
        assertEquals(oldTripleCount + 1, getTripleCount(oldSubGraph));

        SimpleGraphMaker sgm = (SimpleGraphMaker) ((ModelMakerImpl) spec.getModelMaker()).getGraphMaker();
        Collection toGo = Jena.set(sgm.listGraphs());
        for (Iterator i = toGo.iterator(); i.hasNext(); sgm.removeGraph((String) i.next())) ;
        dm.clearCache();

        OntModel newOntModel = ModelFactory.createOntologyModel(spec, null);
        newOntModel.read(BASE + "Import-normalizerBug.owl", FileUtils.langXMLAbbrev);
        Graph newSubGraph = (Graph) newOntModel.getSubGraphs().iterator().next();
        assertFalse(newOntModel == oldOntModel);
        assertFalse(newSubGraph == oldSubGraph);  // FAILS: He reuses the old Graph!
        final int newTripleCount = getTripleCount(newSubGraph);
        assertEquals(oldTripleCount, newTripleCount);
    }


    private int getTripleCount(Graph graph) {
        int count = 0;
        for (Iterator it = graph.find(null, null, null); it.hasNext();) {
            it.next();
            count++;
        }
        return count;
    }
}
