package edu.stanford.smi.protegex.owl.database.triplestore;

import edu.stanford.smi.protege.model.framestore.NarrowFrameStore;
import edu.stanford.smi.protegex.owl.database.OWLDatabaseModel;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreModel;
import edu.stanford.smi.protegex.owl.model.triplestore.impl.AbstractTripleStore;

import java.util.Iterator;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DatabaseTripleStore extends AbstractTripleStore {


    public DatabaseTripleStore(OWLDatabaseModel owlModel,
                               TripleStoreModel tripleStoreModel,
                               NarrowFrameStore frameStore) {
        super(owlModel, tripleStoreModel, frameStore);
    }


    public String getName() {
        return "TheDatabase";
    }


    public Iterator listTriples() {
        throw new UnsupportedOperationException("Not implemented yet.");
    }
}
