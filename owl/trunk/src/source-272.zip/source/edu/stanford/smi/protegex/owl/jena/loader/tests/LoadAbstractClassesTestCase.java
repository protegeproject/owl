package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protegex.owl.model.OWLDatatypeProperty;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadAbstractClassesTestCase extends AbstractJenaTestCase {

    public void testLoadAbstractFlag() throws Exception {
        loadRemoteOntologyWithJenaLoader("abstractClass.owl");
        OWLDatatypeProperty abstractSlot = (OWLDatatypeProperty) owlModel.getSlot("protege:abstract");
        assertNotNull(abstractSlot);
        OWLNamedClass cls = owlModel.getOWLNamedClass("Cls");
        assertEquals(Boolean.TRUE, cls.getPropertyValue(abstractSlot));
        assertTrue(((Cls) cls).isAbstract());
    }
}
