package edu.stanford.smi.protegex.owl.jena.parser.tests;

import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.net.URI;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadAktorsOntologyTestCase extends AbstractJenaTestCase {

    public void testLoadPortal() throws Exception {
        loadTestOntology(new URI("http://www.aktors.org/ontology/portal"));
    }
}
