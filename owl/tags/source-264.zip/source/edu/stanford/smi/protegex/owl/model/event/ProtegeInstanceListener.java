package edu.stanford.smi.protegex.owl.model.event;

import edu.stanford.smi.protege.event.InstanceListener;
import edu.stanford.smi.protege.event.InstanceEvent;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface ProtegeInstanceListener extends InstanceListener {

    /**
     * @deprecated
     * @see ResourceListener#typeAdded
     */
    void directTypeAdded(InstanceEvent event);

    /**
     * @deprecated
     * @see ResourceListener#typeRemoved
     */
    void directTypeRemoved(InstanceEvent event);
}
