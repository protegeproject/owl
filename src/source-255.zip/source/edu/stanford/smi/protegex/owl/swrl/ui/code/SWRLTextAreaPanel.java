package edu.stanford.smi.protegex.owl.swrl.ui.code;

import edu.stanford.smi.protege.ui.InstanceDisplay;
import edu.stanford.smi.protege.util.ModalDialog;
import edu.stanford.smi.protegex.owl.compactparser.OWLCompactParser;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLImp;
import edu.stanford.smi.protegex.owl.swrl.parser.SWRLParser;
import edu.stanford.smi.protegex.owl.ui.code.OWLTextFormatter;

import javax.swing.*;
import java.awt.*;

/**
 * A panel which can be used to edit an OWL expression in a multi-line dialog.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class SWRLTextAreaPanel extends JPanel implements ModalDialog.CloseCallback {

    private OWLModel okb;

    private SWRLSymbolPanel symbolPanel;

    private SWRLTextArea textArea;


    public SWRLTextAreaPanel(OWLModel okb) {
        this(okb, null);
    }


    public SWRLTextAreaPanel(OWLModel okb, SWRLImp imp) {
        this.okb = okb;
        symbolPanel = new SWRLSymbolPanel(okb, false, false);
        textArea = new SWRLTextArea(okb, symbolPanel) {
            protected void checkExpression(String text) throws Throwable {
                OWLCompactParser.checkClass(SWRLTextAreaPanel.this.okb, text);
            }
        };
        if (imp != null && imp.getHead() != null) {
            String text = imp.getBrowserText();
            textArea.setText(text);
            textArea.reformatText();
        }
        symbolPanel.setSymbolEditor(textArea);

        InstanceDisplay id = new InstanceDisplay(okb.getProject(), false, false);
        id.setInstance(imp);

        setLayout(new BorderLayout(0, 8));
        add(BorderLayout.NORTH, id);
        add(BorderLayout.CENTER, new JScrollPane(textArea));
        add(BorderLayout.SOUTH, symbolPanel);
        setPreferredSize(new Dimension(600, 400));
    }


    public boolean canClose(int result) {
        if (result == ModalDialog.OPTION_OK) {
            String uniCodeText = textArea.getText();
            if (uniCodeText.length() == 0) {
                return false;
            }
            else {
                try {
                    SWRLParser parser = new SWRLParser(okb);
                    parser.parse(uniCodeText);
                    return true;
                }
                catch (Exception ex) {
                    symbolPanel.displayError(ex);
                    return false;
                }
            }
        }
        else
            return true;

    }


    public SWRLImp getResultAsImp() {
        try {
            String uniCodeText = textArea.getText();
            SWRLParser parser = new SWRLParser(okb);
            parser.setParseOnly(false);
            return parser.parse(uniCodeText);
        }
        catch (Exception ex) {
            return null;
        }
    }


    public String getResultAsString() {
        String uniCodeText = textArea.getText();
        return OWLTextFormatter.getParseableString(uniCodeText);
    }


    public static boolean showEditDialog(Component parent, OWLModel okb, SWRLImp imp) {
        SWRLTextAreaPanel panel = new SWRLTextAreaPanel(okb, imp);
        String title = "Edit SWRL Rule";
        if (ModalDialog.showDialog(parent, panel, title, ModalDialog.MODE_OK_CANCEL, panel) == ModalDialog.OPTION_OK) {
            try {
                imp.setExpression(panel.getResultAsString());
                return true;
            }
            catch (Exception ex) {
                System.err.println("[SWRLTextAreaPanel]  Fatal error");
                ex.printStackTrace();
            }
        }
        return false;
    }
}
