package edu.stanford.smi.protegex.owl.swrl.ui.tab;

import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.widget.AbstractTabWidget;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.OWLOntology;
import edu.stanford.smi.protegex.owl.model.impl.OWLUtil;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLNames;
import edu.stanford.smi.protegex.owl.swrl.ui.SWRLProjectPlugin;
import edu.stanford.smi.protegex.owl.swrl.ui.icons.SWRLIcons;
import edu.stanford.smi.protegex.owl.swrl.ui.table.SWRLTablePanel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

/**
 * A tab widget displaying all SWRL rules in the current ontology.
 *
 * @author Martin O'Connor  <moconnor@smi.stanford.edu>
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class SWRLTab extends AbstractTabWidget {

    private SWRLTablePanel panel;


    private void activateSWRL() {
        OWLModel owlModel = (OWLModel) getKnowledgeBase();
        activateSWRL(owlModel);
        if (OWLUtil.confirmSaveAndReload()) {
            OWLUtil.saveAndReloadProject();
        }
    }


    public static void activateSWRL(OWLModel owlModel) {
        OWLOntology owlOntology = owlModel.getDefaultOWLOntology();
        owlOntology.addImports(SWRLNames.SWRL_IMPORT);
        owlOntology.addImports(SWRLNames.SWRLB_IMPORT);
        owlModel.getNamespaceManager().setPrefix(SWRLNames.SWRL_NAMESPACE, SWRLNames.SWRL_PREFIX);
        owlModel.getNamespaceManager().setPrefix(SWRLNames.SWRLB_NAMESPACE, SWRLNames.SWRLB_PREFIX);
    }


    public void initialize() {
        setLabel("SWRL Rules");
        setIcon(SWRLIcons.getImpsIcon());
        setLayout(new BorderLayout());
        if (getKnowledgeBase() instanceof OWLModel) {
            OWLModel okb = (OWLModel) getKnowledgeBase();
            if (SWRLProjectPlugin.isSWRLImported(okb)) {
                panel = new SWRLTablePanel(okb, null);
                add(BorderLayout.CENTER, panel);
            }
            else {
                setLayout(new FlowLayout());
                add(new JLabel("Your ontology needs to import the SWRL ontology (" +
                        SWRLNames.SWRL_NAMESPACE + ")."));
                JButton activateButton = new JButton("Activate SWRL...");
                activateButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        activateSWRL();
                    }
                });
                add(activateButton);
            }
        }
        else {
            add(BorderLayout.CENTER, new JLabel("This tab can only be used with OWL projects."));
        }
    }


    public static boolean isSuitable(Project p, Collection errors) {
        if (p.getKnowledgeBase() instanceof OWLModel) {
            return true;
        }
        else {
            errors.add("This tab can only be used with OWL projects.");
            return false;
        }
    }
}
