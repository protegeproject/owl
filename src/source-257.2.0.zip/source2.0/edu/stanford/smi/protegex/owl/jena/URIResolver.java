package edu.stanford.smi.protegex.owl.jena;

import java.net.URI;
import java.net.URL;

/**
 * An interface for objects used by the ProtegeOWLParser to convert logical URIs to physical URLs.
 * This is used to redirect imports and file loading in general, and to determine the file to save
 * a model into.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface URIResolver {

    /**
     * Converts a logical URI into a physical URL.
     *
     * @param uri the logical URI
     * @return the physical URL (often the same as url)
     */
    URL getPhysicalURL(URI uri);


    /**
     * Sets the physical URL of an URI.
     *
     * @param uri         the URI to set the URL of
     * @param physicalURL the new physcial URL or null to reset this URI
     */
    void setPhysicalURL(URI uri, URL physicalURL);
}
