package edu.stanford.smi.protegex.owl.jena.loader;

import com.hp.hpl.jena.graph.impl.SimpleGraphMaker;
import com.hp.hpl.jena.ontology.OntDocumentManager;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.impl.ModelMakerImpl;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protegex.owl.jena.Jena;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultJenaLoaderFactory implements JenaLoaderFactory {

    public OntModel createOntModel(OntModelSpec spec) {
        return ModelFactory.createOntologyModel(spec, null);
    }


    public OntModelSpec getOntModelSpec(Project project) {
        OntModelSpec spec = new OntModelSpec(OntModelSpec.OWL_MEM);
        spec.setReasoner(null);
        OntDocumentManager dm = OntDocumentManager.getInstance(); // new OntDocumentManager();

        // Temporary hack to circumnavigate a Jena bug
        SimpleGraphMaker sgm = (SimpleGraphMaker) ((ModelMakerImpl) spec.getModelMaker()).getGraphMaker();
        Collection toGo = Jena.set(sgm.listGraphs());
        for (Iterator i = toGo.iterator(); i.hasNext(); sgm.removeGraph((String) i.next())) ;
        dm.clearCache();

        String path = new File(JenaLoader.getOntPolicyFilePath(project)).toURI().toString() + ";" +
                new File(new File("etc"), "ont-policy.rdf").toURI().toString();
        dm.setMetadataSearchPath(path, true);
        spec.setDocumentManager(dm);
        return spec;
    }
}
