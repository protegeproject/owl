package edu.stanford.smi.protegex.owl.jena;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.util.FileUtils;
import edu.stanford.smi.protege.Application;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.plugin.ExportPlugin;
import edu.stanford.smi.protege.ui.ProjectManager;
import edu.stanford.smi.protege.util.ModalDialog;
import edu.stanford.smi.protege.util.WaitCursor;
import edu.stanford.smi.protegex.owl.database.OWLDatabaseModel;
import edu.stanford.smi.protegex.owl.storage.ProtegeSaver;
import edu.stanford.smi.protegex.owl.ui.widget.OWLUI;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class JenaExportPlugin implements ExportPlugin {

    public void dispose() {
    }


    public String getName() {
        return "OWL";
    }


    public void handleExportRequest(Project project) {
        if (project.getKnowledgeBase() instanceof JenaOWLModel) {
            OWLUI.showMessageDialog("This project is already an OWL Files project.");
        }
        else {
            JenaFilePanel panel = new JenaFilePanel();
            int rval = ModalDialog.showDialog(Application.getMainWindow(),
                    panel, "OWL File to Export", ModalDialog.MODE_OK_CANCEL);
            if (rval == ModalDialog.OPTION_OK) {
                String filePath = panel.getOWLFilePath();
                WaitCursor cursor = new WaitCursor(ProjectManager.getProjectManager().getMainPanel());
                try {
                    exportProject(project.getKnowledgeBase(), filePath);
                }
                finally {
                    cursor.hide();
                }
            }
        }
    }


    private void exportProject(KnowledgeBase kb, String filePath) {
        Collection errors = new ArrayList();
        JenaKnowledgeBaseFactory factory = new JenaKnowledgeBaseFactory();
        Project newProject = Project.createNewProject(factory, errors);
        URI fileURI = new File(filePath).toURI();
        newProject.setProjectURI(fileURI);
        JenaOWLModel owlModel = (JenaOWLModel) newProject.getKnowledgeBase();
        if (kb instanceof OWLDatabaseModel) {
            OntModel newModel = ((OWLDatabaseModel) kb).getOntModel();
            owlModel.save(fileURI, FileUtils.langXMLAbbrev, errors, newModel);
        }
        else {  // Any other Protege format
            // TODO: owlModel.initWithProtegeMetadataOntology(errors);
            new ProtegeSaver(kb, owlModel).run();
            owlModel.save(fileURI, FileUtils.langXMLAbbrev, errors);
        }
        if (errors.size() == 0) {
            OWLUI.showMessageDialog("Project has been exported to " + filePath);
        }
        else {
            OWLUI.showErrorMessageDialog("Error: " + errors.iterator().next(),
                    "Export Failed");
        }
    }
}
