package edu.stanford.smi.protegex.owl.inference.ui;

import edu.stanford.smi.protege.Application;
import edu.stanford.smi.protege.plugin.ProjectPluginAdapter;
import edu.stanford.smi.protege.ui.ProjectMenuBar;
import edu.stanford.smi.protege.ui.ProjectToolBar;
import edu.stanford.smi.protege.ui.ProjectView;
import edu.stanford.smi.protegex.owl.inference.ui.action.*;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.ui.actions.ResourceActionManager;

/**
 * User: matthewhorridge<br>
 * The Univeristy Of Manchester<br>
 * Medical Informatics Group<br>
 * Date: Jul 1, 2004<br><br>
 * <p/>
 * matthew.horridge@cs.man.ac.uk<br>
 * www.cs.man.ac.uk/~horridgm<br><br>
 */
public class ProtegeOWLReasonerLoader extends ProjectPluginAdapter {

    private OWLModel kb;


    public void afterShow(ProjectView projectView, ProjectToolBar projectToolBar, ProjectMenuBar projectMenuBar) {
        // Make sure that we are dealing with an OWLModel
        if (projectView.getProject().getKnowledgeBase() instanceof OWLModel) {
            kb = (OWLModel) projectView.getProject().getKnowledgeBase();

            // Toolbar actions - classify, consistency check, classify individuals
            projectToolBar.addButton(new ClassifyTaxonomyAction(kb));

            projectToolBar.addButton(new CheckConsistencyAction(kb));

            projectToolBar.addButton(new ComputeInferredTypesAction(kb));

            ResourceActionManager.addResourceActionClass(CheckSingleConceptConsistencyAction.class);

            ResourceActionManager.addResourceActionClass(ComputeSingleIndividualTypesAction.class);

            ResourceActionManager.addResourceActionClass(ComputeIndividualsBelongingToClassAction.class);

            ResourceActionManager.addResourceActionClass(GetInferredSuperClassesAction.class);
        }
    }


    /**
     * Main method for debugging purposes
     */
    public static void main(String[] args) {
        Application.main(args);
    }
}

