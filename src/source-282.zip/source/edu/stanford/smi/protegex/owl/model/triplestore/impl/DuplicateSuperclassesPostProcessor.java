package edu.stanford.smi.protegex.owl.model.triplestore.impl;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protegex.owl.model.OWLAnonymousClass;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
class DuplicateSuperclassesPostProcessor {


    DuplicateSuperclassesPostProcessor(OWLModel owlModel) {
        owlModel.getOWLFrameStore().setSuperclassSynchronizationBlocked(true);
        Collection clses = owlModel.getUserDefinedOWLNamedClasses();
        Iterator it = clses.iterator();
        while (it.hasNext()) {
            OWLNamedClass cls = (OWLNamedClass) it.next();
            removeDuplicateSuperclasses(cls);
        }
        owlModel.getOWLFrameStore().setSuperclassSynchronizationBlocked(false);
    }


    private void removeDuplicateSuperclasses(RDFSNamedClass cls) {
        List superclasses = new ArrayList(cls.getPureSuperclasses());
        for (int i = 0; i < superclasses.size() - 1; i++) {
            if (superclasses.get(i) instanceof OWLAnonymousClass) {
                OWLAnonymousClass anon = (OWLAnonymousClass) superclasses.get(i);
                for (int j = superclasses.size() - 1; j > i; j--) {
                    if (superclasses.get(j).getClass() == anon.getClass()) {
                        String browserText = ((Cls) superclasses.get(i)).getBrowserText();
                        OWLAnonymousClass other = (OWLAnonymousClass) superclasses.get(j);
                        if (other.getBrowserText().equals(browserText)) {
                            ((Cls) cls).removeDirectSuperclass(other);
                        }
                    }
                }
            }
        }
    }
}
