package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.model.OWLAllDifferent;
import edu.stanford.smi.protegex.owl.model.OWLIndividual;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadAllDifferentTestCase extends AbstractJenaTestCase {

    public void testLoadAllDifferent() throws Exception {

        OWLNamedClass colorClass = owlModel.createOWLNamedClass("Color");
        OWLIndividual red = colorClass.createOWLIndividual("red");
        OWLIndividual blue = colorClass.createOWLIndividual("blue");
        OWLAllDifferent owlAllDifferent = owlModel.createOWLAllDifferent();
        owlAllDifferent.addDistinctMember(red);
        owlAllDifferent.addDistinctMember(blue);

        JenaOWLModel newOWLModel = reloadWithJenaLoader(owlModel);

        OWLIndividual newRed = newOWLModel.getOWLIndividual(red.getName());
        OWLIndividual newBlue = newOWLModel.getOWLIndividual(blue.getName());
        RDFSNamedClass allDifferentClass = newOWLModel.getOWLAllDifferentClass();
        assertSize(1, allDifferentClass.getInstances(false));
        OWLAllDifferent newAllDifferent = (OWLAllDifferent) allDifferentClass.getInstances(false).iterator().next();
        assertSize(2, newAllDifferent.getDistinctMembers());
        assertContains(newRed, newAllDifferent.getDistinctMembers());
        assertContains(newBlue, newAllDifferent.getDistinctMembers());
    }
}
