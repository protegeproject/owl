package edu.stanford.smi.protegex.owl.swrl.model;

import edu.stanford.smi.protegex.owl.model.RDFResource;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface SWRLIndividualsAtom extends SWRLAtom {

    RDFResource getArgument1();


    void setArgument1(RDFResource instance);


    RDFResource getArgument2();


    void setArgument2(RDFResource instance);
}
