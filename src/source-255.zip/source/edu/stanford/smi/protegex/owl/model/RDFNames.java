package edu.stanford.smi.protegex.owl.model;


/**
 * Defines the names of the RDF(S) related parts of the OWL system ontology.
 * This corresponds to the Model interface in general Protege.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface RDFNames {

    public static interface Cls {

        final static String EXTERNAL_RESOURCE = "protege:ExternalResource";

        final static String LIST = "rdf:List";

        final static String PROPERTY = "rdf:Property";

        final static String STATEMENT = "rdf:Statement";
    }

    public static interface Slot {

        final static String FIRST = "rdf:first";

        final static String OBJECT = "rdf:object";

        final static String PREDICATE = "rdf:predicate";

        final static String REST = "rdf:rest";

        final static String SUBJECT = "rdf:subject";

        final static String TYPE = "rdf:type";

        final static String VALUE = "rdf:value";
    }


    public static interface Instance {

        final static String NIL = "rdf:nil";
    }

    final static String RDF_PREFIX = "rdf";

    final static String XSD_PREFIX = "xsd";

    final static String XML_LITERAL = "rdf:XMLLiteral";
}
