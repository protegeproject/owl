package edu.stanford.smi.protegex.owl.jena.loader.tests;

import com.hp.hpl.jena.datatypes.xsd.XSDDatatype;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadXMLSchemaDatatypesTestCase extends AbstractJenaTestCase {


    public void testLoadDateTime() throws Exception {
        String t = "2004-12-21T11:12:13";
        loadRemoteOntology("xsdDateTime.owl");
        RDFProperty property = owlModel.getRDFProperty("dateTime");
        RDFIndividual instance = owlModel.getRDFIndividual("Instance");
        RDFSLiteral literal = (RDFSLiteral) instance.getPropertyValue(property);
        assertEquals(XSDDatatype.XSDdateTime.getURI(), literal.getDatatype().getURI());
        assertEquals(t, literal.getString());
    }


    public void testLoadTime() throws Exception {
        String t = "01:54:59";
        loadRemoteOntology("xsdTime.owl");
        RDFProperty property = owlModel.getRDFProperty("time");
        RDFIndividual instance = owlModel.getRDFIndividual("Instance");
        RDFSLiteral literal = (RDFSLiteral) instance.getPropertyValue(property);
        assertEquals(XSDDatatype.XSDtime.getURI(), literal.getDatatype().getURI());
        assertEquals(t, literal.getString());
    }


    public void testLoadUnsupportedXMLSchemaDatatypes() throws Exception {
        loadRemoteOntology("xml-schema-datatypes.owl");
    }


    public void testLoadAnyURI() throws Exception {
        OWLDatatypeProperty property = owlModel.createAnnotationOWLDatatypeProperty("property");
        RDFSDatatype xsdAnyURI = owlModel.getRDFSDatatypeByName("xsd:anyURI");
        property.setRange(xsdAnyURI);
        RDFSLiteral literal = owlModel.createRDFSLiteral("http://aldi.de", xsdAnyURI);
        property.setPropertyValue(property, literal);

        JenaOWLModel newModel = reload(owlModel);
        OWLDatatypeProperty newProperty = newModel.getOWLDatatypeProperty(property.getName());
        assertNotNull(newProperty);
        assertSize(1, newProperty.getPropertyValues(newProperty));
        RDFSLiteral newLiteral = (RDFSLiteral) newProperty.getPropertyValue(newProperty);
        assertEquals(newLiteral.getDatatype().getName(), literal.getDatatype().getName());
        assertEquals(newLiteral.getString(), literal.getString());
    }


    public void testLoadBase64Binary() throws Exception {
        OWLDatatypeProperty oldProperty = owlModel.createOWLDatatypeProperty("oldProperty");
        oldProperty.setRange(owlModel.getXSDbase64Binary());
        byte[] values = new byte[]{1, 2, 3};
        RDFSLiteral oldLiteral = owlModel.createRDFSLiteral(values);
        assertEquals(owlModel.getXSDbase64Binary(), oldLiteral.getDatatype());
        oldProperty.setPropertyValue(oldProperty, oldLiteral);

        OWLModel newModel = reload(owlModel);
        OWLDatatypeProperty newProperty = newModel.getOWLDatatypeProperty(oldProperty.getName());
        assertEquals(newModel.getXSDbase64Binary(), newProperty.getRange());
        Object newValue = newProperty.getPropertyValue(newProperty);
        assertTrue(newValue instanceof RDFSLiteral);
        RDFSLiteral newLiteral = (RDFSLiteral) newValue;
        assertEquals(newModel.getXSDbase64Binary(), newLiteral.getDatatype());
        byte[] newValues = newLiteral.getBytes();
        assertEquals(values.length, newValues.length);
        for (int i = 0; i < values.length; i++) {
            assertEquals(values[i], newValues[i]);
        }
    }
}
