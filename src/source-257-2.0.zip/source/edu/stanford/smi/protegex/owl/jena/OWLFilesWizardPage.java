package edu.stanford.smi.protegex.owl.jena;

import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protegex.owl.ui.widget.OWLUI;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URI;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class OWLFilesWizardPage extends WizardPage {

    private boolean callback = false; // Avoids infite recursion exception

    public static final String EXTENSION = "owl";

    private JComboBox languageComboBox;

    private URIField owlFileURIField;

    private JCheckBox parserCheckBox;

    private OWLFilesPlugin plugin;


    public OWLFilesWizardPage(Wizard wizard, OWLFilesCreateProjectPlugin aPlugin) {
        super("OWL Files", wizard);

        this.plugin = aPlugin;

        languageComboBox = new JComboBox(JenaKnowledgeBaseFactory.fileLanguages);
        languageComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String path = getProjectPath();
                updatePath(path);
            }
        });
        LabeledComponent languagePanel = new LabeledComponent("Language", languageComboBox);

        owlFileURIField = new URIField("OWL file name or URL",
                null, EXTENSION,
                "Web Ontology Language (OWL) files");
        owlFileURIField.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                updateSetPageComplete();
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(8, 8));
        panel.add(BorderLayout.NORTH, owlFileURIField);
        panel.add(BorderLayout.CENTER, languagePanel);

        try {
            if (Class.forName("edu.stanford.smi.protegex.owl.jena.parser.ProtegeOWLParser") != null) {
                parserCheckBox = new JCheckBox("Use new Protege-OWL triple parser (beta)");
                panel.add(BorderLayout.SOUTH, parserCheckBox);
            }
        }
        catch (ClassNotFoundException ex) {
            // Ignore
        }

        add(panel);

        updateSetPageComplete();
    }


    public String getProjectPath() {
        String path = ""; // super.getProjectPath();

        if (path == null) {
            if (owlFileURIField != null) {
                URI absoluteURI = owlFileURIField.getAbsoluteURI();
                if (absoluteURI != null) {
                    path = absoluteURI.toString();
                    path = FileUtilities.replaceExtension(path, ".pprj");
                }
                else {
                    path = "";
                }
            }
            else {
                path = "";
            }
        }
        return path;
    }


    private URI getURI(String str) {
        try {
            return new URI(str);
        }
        catch (Exception ex) {
            return URIUtilities.createURI(str);
        }
    }


    public void onFinish() {
        String lang = (String) languageComboBox.getSelectedItem();
        plugin.setLanguage(lang);

        final URI uri = owlFileURIField.getAbsoluteURI();
        String owlFileURI = uri != null ? uri.toString() : "";
        plugin.setFile(owlFileURI);

        if (parserCheckBox != null) {
            plugin.setUseARP(parserCheckBox.isSelected());
        }
    }


    protected void onProjectPathChange(String oldPath, String newPath) {
        if (newPath != null) {
            updatePath(newPath);
        }
    }


    private void updatePath(String newPath) {
        if (getProjectPath() != null && !callback) {
            String language = (String) languageComboBox.getSelectedItem();
            String ext = "." + JenaKnowledgeBaseFactory.getExtension(language);
            int index = newPath.lastIndexOf('/');
            if (index >= 0) {
                newPath = newPath.substring(index + 1);
            }
            String name = new File(newPath).getName();
            String fieldText = FileUtilities.replaceExtension(name, ext);
            owlFileURIField.setURI(getURI(fieldText));
        }
    }


    public boolean validateContents() {
        if (owlFileURIField.getRelativeURI() == null) {
            OWLUI.showErrorMessageDialog("You need to enter a valid URI for an OWL/RDF file.\n" +
                    "Currently, these URIs should not contain spaces.", "Invalid URI");
            return false;
        }
        else {
            return true;
        }
    }


    private void updateSetPageComplete() {
        setPageComplete(owlFileURIField.getRelativeURI() != null);
    }
}
