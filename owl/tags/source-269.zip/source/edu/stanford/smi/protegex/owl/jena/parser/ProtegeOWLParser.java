package edu.stanford.smi.protegex.owl.jena.parser;

import com.hp.hpl.jena.rdf.arp.*;
import com.hp.hpl.jena.vocabulary.RDFS;
import edu.stanford.smi.protege.Application;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.model.framestore.MergingNarrowFrameStore;
import edu.stanford.smi.protegex.owl.jena.Jena;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.jena.URIResolver;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.factory.OWLJavaFactoryUpdater;
import edu.stanford.smi.protegex.owl.model.impl.*;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreModel;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreUtil;
import edu.stanford.smi.protegex.owl.model.triplestore.impl.RDFListPostProcessor;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLNames;
import edu.stanford.smi.protegex.owl.swrl.model.factory.SWRLJavaFactory;
import edu.stanford.smi.protegex.owl.ui.jena.OntPolicy;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URI;
import java.net.URL;
import java.util.*;

/**
 * An OWL parser that reads an OWL stream triple-by-triple and writes the
 * corresponding Protege-OWL Triples into one or more TripleStores.
 * The current implementation uses the Jena ARP parser for triple loading.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class ProtegeOWLParser {

    private int count = 29920;

    /**
     * The default namespace to use if the current file does not define one by itself.
     * This is typically the file's URL (import URI).
     */
    private String currentDefaultNamespace;

    private Frame currentType;

    /**
     * A rather ugly flag that can be activated to prompt the user if a local
     * file was found as a possible import redirection.
     */
    public static boolean inUI = false;

    private boolean isRDFList = false;

    private KnowledgeBase kb;

    private ProtegeOWLParserLogger logger;

    private Cls owlNamedClassClass;

    private OWLModel owlModel;

    private RDFProperty rdfFirstProperty;

    private RDFProperty rdfRestProperty;

    private RDFProperty rdfTypeProperty;

    private TripleStore tripleStore;

    private TripleStoreModel tripleStoreModel;

    private Collection tripleStores = new ArrayList();

    private URI2NameConverter uri2NameConverter;

    private URIResolver uriResolver;

    private static final String RDFS_RESOURCE_URI = RDFS.Resource.getURI();

    private String prefixForDefaultNamespace;


    public ProtegeOWLParser(OWLModel owlModel, boolean incremental) {
        this.owlModel = owlModel;
        this.kb = owlModel;
        this.tripleStoreModel = owlModel.getTripleStoreModel();
        this.rdfTypeProperty = owlModel.getRDFTypeProperty();
        rdfFirstProperty = owlModel.getRDFFirstProperty();
        rdfRestProperty = owlModel.getRDFRestProperty();
        if (incremental) {
            int max = count;
            for (Iterator it = owlModel.getRDFResources().iterator(); it.hasNext();) {
                RDFResource resource = (RDFResource) it.next();
                max = Math.max(max, ((Instance) resource).getFrameID().getLocalPart());
            }
            count = max + 1;
        }
        logger = createLogger();
        owlNamedClassClass = owlModel.getOWLNamedClassClass();
        uri2NameConverter = createURI2NameConverter(owlModel, incremental);
        uriResolver = owlModel.getURIResolver();
    }


    private void addNamespaceToImports(String defaultNamespace, Set imports) {
        if (Jena.namespaceEndsWithSeparator(defaultNamespace)) {
            imports.add(defaultNamespace.substring(0, defaultNamespace.length() - 1));
        }
        else {
            imports.add(defaultNamespace);
        }
    }


    /**
     * A convenience method that dynamically adds an import to a JenaOWLModel.
     * This will immediately load the file into a new TripleStore.  Prior to
     * invoking this method, the caller should define a prefix for the expected
     * namespace (e.g., URI + "#").  Following the call, the caller should add
     * an import statement to an existing OWLOntology (usually the default ontology).
     *
     * @param owlModel
     * @param uri
     * @throws Exception
     */
    public static void addImport(JenaOWLModel owlModel, URI uri) throws Exception {
        TripleStore activeTripleStore = owlModel.getTripleStoreModel().getActiveTripleStore();
        TripleStore ts = owlModel.getTripleStoreModel().createTripleStore(uri.toString());
        ProtegeOWLParser parser = new ProtegeOWLParser(owlModel, true);
        parser.run(uri, owlModel.getNamespaceManager().getDefaultNamespace(), ts);
        owlModel.getTripleStoreModel().setActiveTripleStore(activeTripleStore);
        owlModel.getOWLFrameStore().copyFacetValuesIntoNamedClses();
    }


    /**
     * A convenience method that dynamically adds an import to a JenaOWLModel.
     * This will immediately load the file into a new TripleStore.
     * Following the call, the caller should add an import statement to an
     * existing OWLOntology (usually the default ontology).
     *
     * @param owlModel
     * @param uri
     * @param prefixForDefaultNamespace an (optional) prefix that shall be used for the
     *                                  the default namespace of the directly imported ontology
     * @throws Exception
     */
    public static void addImport(JenaOWLModel owlModel, URI uri, String prefixForDefaultNamespace) throws Exception {
        TripleStore activeTripleStore = owlModel.getTripleStoreModel().getActiveTripleStore();
        TripleStore ts = owlModel.getTripleStoreModel().createTripleStore(uri.toString());
        ProtegeOWLParser parser = new ProtegeOWLParser(owlModel, true);
        parser.setPrefixForDefaultNamespace(prefixForDefaultNamespace);
        parser.run(uri, owlModel.getNamespaceManager().getDefaultNamespace(), ts);
        owlModel.getTripleStoreModel().setActiveTripleStore(activeTripleStore);
        owlModel.getOWLFrameStore().copyFacetValuesIntoNamedClses();
    }


    protected ARP createARP() {
        ARP arp = new ARP();
        ARPHandlers handlers = new ARPHandlers();
        handlers.setStatementHandler(new MyStatementHandler());
        handlers.setErrorHandler(new MyErrorHandler());
        handlers.setNamespaceHandler(new MyNamespaceHandler());
        arp.setHandlersWith(handlers);
        return arp;
    }


    private void createDefaultNamespace(TripleStore tripleStore) {
        Slot prefixesSlot = kb.getSlot(OWLNames.Slot.ONTOLOGY_PREFIXES);
        Instance owlOntology = TripleStoreUtil.getFirstOntology(owlModel, tripleStore);
        String name = owlOntology.getName();
        if (uri2NameConverter.isTemporaryRDFResourceName(name)) {
            String namespace = uri2NameConverter.getURIFromTemporaryName(name);
            namespace = Jena.getNamespaceFromURI(namespace);
            String value = ":" + namespace;
            final List oldValues = owlOntology.getDirectOwnSlotValues(prefixesSlot);
            if (!oldValues.contains(value)) {
                uri2NameConverter.addPrefix(namespace, "");
                for (Iterator it = new ArrayList(oldValues).iterator(); it.hasNext();) {
                    String s = (String) it.next();
                    if (s.startsWith(":")) {
                        owlOntology.removeOwnSlotValue(prefixesSlot, s);
                    }
                }
                owlOntology.addOwnSlotValue(prefixesSlot, ":" + namespace);
            }
        }
    }


    private Object createLiteralObject(ALiteral node, RDFProperty property) {
        DefaultRDFSLiteral literal = (DefaultRDFSLiteral) createRDFSLiteral(node, property);
        Object plain = literal.getPlainValue();
        if (plain != null) {
            return plain;
        }
        else {
            return literal.getRawValue();
        }
    }


    protected ProtegeOWLParserLogger createLogger() {
        return new DefaultProtegeOWLParserLogger();
    }


    private RDFSLiteral createRDFSLiteral(ALiteral literal, RDFProperty property) {
        if (literal.getLang() != null && literal.getLang().length() > 0) {
            return owlModel.createRDFSLiteral(literal.toString(), literal.getLang());
        }
        else if (literal.getDatatypeURI() != null) {
            RDFSDatatype datatype = owlModel.getRDFSDatatypeByURI(literal.getDatatypeURI());
            return owlModel.createRDFSLiteral(literal.toString(), datatype);
        }
        else {
            // If literal has no datatype, make a qualified guess using the property's range
            RDFResource range = property.getRange();
            if (range instanceof RDFSDatatype) {
                RDFSDatatype datatype = owlModel.getRDFSDatatypeByURI(range.getURI());
                return owlModel.createRDFSLiteral(literal.toString(), datatype);
            }
            else {
                return owlModel.createRDFSLiteral(literal.toString());
            }
        }
    }


    private RDFResource createRDFResource(String name) {
        FrameID id = FrameID.createLocal(count++);
        RDFResource r = null;
        if (owlNamedClassClass.equals(currentType)) {
            r = new DefaultOWLNamedClass(owlModel, id);
        }
        else if (isRDFList) {
            r = new DefaultRDFList(owlModel, id);
        }
        else {
            r = new DefaultRDFProperty(owlModel, id);
        }
        if (name == null) {
            name = owlModel.getNextAnonymousResourceName();
        }
        tripleStore.setRDFResourceName(r, name);
        return r;
    }


    protected URI2NameConverter createURI2NameConverter(OWLModel owlModel, boolean incremental) {
        return new DefaultURI2NameConverter(owlModel, logger, incremental);
    }


    private RDFResource findResource(String name) {
        for (Iterator it = tripleStores.iterator(); it.hasNext();) {
            TripleStore ts = (TripleStore) it.next();
            RDFResource resource = ts.getHomeResource(name);
            if (resource != null) {
                return resource;
            }
        }
        return null;
    }


    protected ProtegeOWLParserLogger getLogger() {
        return logger;
    }


    private RDFProperty getRDFProperty(AResource propertyNode) {
        return (RDFProperty) getRDFResource(propertyNode);
    }


    private RDFResource getRDFResource(AResource aResource) {
        final String uri = aResource.isAnonymous() ? aResource.getAnonymousID() : aResource.getURI();
        if (uri.equals(RDFS_RESOURCE_URI)) {
            return owlModel.getOWLThingClass();
        }
        else {
            final String tempName = uri2NameConverter.getTemporaryRDFResourceName(aResource);
            RDFResource existingTemp = findResource(tempName);
            if (existingTemp != null) {
                return existingTemp;
            }
            String name = uri2NameConverter.getRDFResourceName(uri);
            if (name == null) {
                name = tempName;
            }
            RDFResource resource = findResource(name);
            if (resource == null) {
                resource = createRDFResource(name);
            }
            return resource;
        }
    }


    private void replaceNamespace(TripleStore tripleStore, RDFResource ontology, String prefix, String namespace) {
        RDFProperty property = ontology.getOWLModel().getRDFProperty(OWLNames.Slot.ONTOLOGY_PREFIXES);
        Collection values = ontology.getPropertyValues(property);
        for (Iterator it = values.iterator(); it.hasNext();) {
            String value = (String) it.next();
            if (value.startsWith(prefix + ":")) {
                ontology.removePropertyValue(property, value);
            }
        }
        tripleStore.add(ontology, property, prefix + ":" + namespace);
    }


    private void replaceTemporaryNames() {
        TripleStore activeTripleStore = tripleStoreModel.getActiveTripleStore();
        Iterator it = owlModel.getTripleStoreModel().listUserTripleStores();
        while (it.hasNext()) {
            TripleStore tripleStore = (TripleStore) it.next();
            tripleStoreModel.setActiveTripleStore(tripleStore);
            replaceTemporaryNames(tripleStore);
        }
        tripleStoreModel.setActiveTripleStore(activeTripleStore);
    }


    private void replaceTemporaryNames(TripleStore tripleStore) {

        Collection homeResources = Jena.set(tripleStore.listHomeResources());

        OWLNamedClass owlOntologyClass = owlModel.getOWLOntologyClass();
        boolean changed = false;
        for (Iterator it = homeResources.iterator(); it.hasNext();) {
            RDFResource ontology = (RDFResource) it.next();
            //if(ontology.getName().equals("^http://www.daml.org/services/owl-s/1.1/generic/Expression.owl#Condition")) {
            if (ontology.hasRDFType(owlOntologyClass)) {
                String name = ontology.getName();
                if (uri2NameConverter.isTemporaryRDFResourceName(name)) {
                    String uri = uri2NameConverter.getURIFromTemporaryName(name);
                    uri = Jena.getNamespaceFromURI(uri);
                    name = uri2NameConverter.getTemporaryRDFResourceName(uri);
                    replaceTemporaryName(tripleStore, ontology, name, true);
                    changed = true;
                }
            }
        }
        if (changed) {
            owlModel.flushCache();
            owlModel.getNamespaceManager().update();
            uri2NameConverter.updateInternalState();
        }

        final Slot directTypesSlot = kb.getSlot(Model.Slot.DIRECT_TYPES);
        for (Iterator it = homeResources.iterator(); it.hasNext();) {
            final Instance instance = (Instance) it.next();
            if (!instance.isSystem()) {
                final String name = instance.getName();
                if (instance.getDirectOwnSlotValues(directTypesSlot).isEmpty()) {  // External resource
                    instance.getDirectOwnSlotValues(directTypesSlot);
                    if (instance instanceof RDFProperty &&
                            !tripleStore.getNarrowFrameStore().getFramesWithAnyValue((Slot) instance, null, false).isEmpty()) {
                        // Convert into rdf:Property if this has been used as any property value
                        if (uri2NameConverter.isTemporaryRDFResourceName(name)) {
                            replaceTemporaryName(tripleStore, (RDFResource) instance, name, false);
                        }
                        tripleStore.add((RDFResource) instance, owlModel.getRDFTypeProperty(), owlModel.getRDFPropertyClass());
                    }
                    else if (tripleStore.listSubjects(owlModel.getRDFSRangeProperty(), instance).hasNext() ||
                            tripleStore.listSubjects(owlModel.getRDFSDomainProperty(), instance).hasNext() ||
                            tripleStore.listSubjects(owlModel.getRDFSSubClassOfProperty(), instance).hasNext()) {
                        if (uri2NameConverter.isTemporaryRDFResourceName(name)) {
                            replaceTemporaryName(tripleStore, (RDFResource) instance, name, false);
                        }
                        tripleStore.add((RDFResource) instance, owlModel.getRDFTypeProperty(), owlModel.getRDFSNamedClassClass());
                    }
                    else {
                        instance.setDirectType(kb.getCls(RDFNames.Cls.EXTERNAL_RESOURCE));
                        RDFExternalResource externalResource = (RDFExternalResource) kb.getFrame(name);
                        String uri = uri2NameConverter.getURIFromTemporaryName(name);
                        externalResource.setResourceURI(uri);
                        String newName = uri2NameConverter.getRDFExternalResourceName();
                        owlModel.getOWLFrameStore().setFrameName(externalResource, newName);
                        // System.out.println("External Resource for " + uri);
                    }
                }
                else {
                    if (uri2NameConverter.isTemporaryRDFResourceName(name)) {
                        replaceTemporaryName(tripleStore, (RDFResource) instance, name, false);
                    }
                }
            }
        }
        owlModel.flushCache();
    }


    private void replaceTemporaryName(TripleStore tripleStore, RDFResource resource,
                                      String name, boolean isOntology) {
        if (uri2NameConverter.isAnonymousRDFResourceName(name)) {
            String newName = uri2NameConverter.createAnonymousRDFResourceName();
            tripleStore.setRDFResourceName(resource, newName);
        }
        else {
            String uri = uri2NameConverter.getURIFromTemporaryName(name);
            String newName = uri2NameConverter.getRDFResourceName(uri);
            if (newName == null) {
                if (isOntology) {
                    uri = Jena.getNamespaceFromURI(uri);
                }
                String prefix = uri2NameConverter.createNewPrefix(uri);
                String namespace = uri2NameConverter.getResourceNamespace(uri);
                newName = uri2NameConverter.getRDFResourceName(uri);
                RDFResource ontology = TripleStoreUtil.getFirstOntology(owlModel, tripleStore);
                replaceNamespace(tripleStore, ontology, prefix, namespace);
                if (newName == null) {
                    namespace = uri2NameConverter.getResourceNamespace(uri);
                    prefix = uri2NameConverter.createNewPrefix(namespace);
                    replaceNamespace(tripleStore, ontology, prefix, namespace);
                    newName = uri2NameConverter.getRDFResourceName(uri);
                }
            }
            // System.out.println("Replacing " + name + " with \"" + newName + "\"");
            tripleStore.setRDFResourceName(resource, newName);
        }
    }


    public void run(final URI uri, TripleStore tripleStore) throws Exception {
        run(uri, uri.toString(), tripleStore);
    }


    public void run(final URI uri, String defaultNamespace, TripleStore tripleStore) throws Exception {
        run(tripleStore, defaultNamespace, new ARPInvokation() {
            public void invokeARP(ARP arp) throws Exception {
                URL physicalURL = uriResolver.getPhysicalURL(uri);
                InputStream is = physicalURL.openStream();
                arp.load(is, uri.toString());
            }
        });
    }


    public void run(TripleStore tripleStore, String defaultNamespace, ARPInvokation invokation) throws Exception {

        Set imports = owlModel.getAllImports();

        // To avoid cyclic imports: Mark this as already imported
        addNamespaceToImports(defaultNamespace, imports);

        currentDefaultNamespace = defaultNamespace;
        this.tripleStore = tripleStore;
        tripleStores.addAll(tripleStoreModel.getTripleStores());
        ARP arp = createARP();
        long startTime = System.currentTimeMillis();
        OWLOntology defaultOntology = owlModel.getDefaultOWLOntology();
        if (tripleStore.contains(defaultOntology, owlModel.getRDFTypeProperty(), owlModel.getOWLOntologyClass())) {
            defaultOntology.delete();
        }
        invokation.invokeARP(arp);
        if (owlModel.getRDFResource(":") == null) {
            createDefaultNamespace(tripleStore);
        }
        String dns = owlModel.getNamespaceManager().getDefaultNamespace();
        if (dns != null) {
            addNamespaceToImports(dns, imports);
        }
        runImports(tripleStore, imports);
        long endTime = System.currentTimeMillis();
        System.out.println("[ProtegeOWLParser] Completed triple loading after " + (endTime - startTime) + " ms");

        tripleStoreModel.setActiveTripleStore(tripleStore);
        owlModel.getNamespaceManager().update();
        owlModel.flushCache();

        owlModel.setUndoEnabled(false);

        // Assign rdf:List to any untyped lists
        new RDFListPostProcessor(owlModel);

        tripleStoreModel.setActiveTripleStore(tripleStore);
        uri2NameConverter.updateInternalState();

        // Replace all temporary names with the final ones
        replaceTemporaryNames();
        owlModel.getNamespaceManager().update();

        // Clean up the temporary mess
        tripleStoreModel.endTripleStoreChanges();

        TripleStoreUtil.updateFrameInclusion(MergingNarrowFrameStore.get(owlModel),
                ((KnowledgeBase) owlModel).getSlot(Model.Slot.NAME));

        if (imports.contains(SWRLNames.SWRL_IMPORT)) {
            SWRLJavaFactory factory = new SWRLJavaFactory(owlModel);
            owlModel.setOWLJavaFactory(factory);
            if (owlModel instanceof JenaOWLModel) {
                OWLJavaFactoryUpdater.run((JenaOWLModel) owlModel);
            }
        }

        owlModel.setUndoEnabled(true);

        System.out.println("... Loading completed after " + (System.currentTimeMillis() - startTime) + " ms");
    }


    private void runImports(TripleStore tripleStore, Set imports) throws SAXException, IOException {
        prefixForDefaultNamespace = null;
        RDFProperty owlImportsProperty = owlModel.getRDFProperty(OWLNames.Slot.IMPORTS);
        Iterator ontologies = tripleStore.listSubjects(owlImportsProperty);
        while (ontologies.hasNext()) {
            RDFResource ontology = (RDFResource) ontologies.next();
            Iterator imps = ontology.listPropertyValues(owlImportsProperty);
            while (imps.hasNext()) {
                Instance imp = (Instance) imps.next();
                String impName = imp.getName();
                String uri = null;
                if (uri2NameConverter.isTemporaryRDFResourceName(impName)) {
                    uri = uri2NameConverter.getURIFromTemporaryName(impName);
                }
                else if (imp instanceof RDFResource) {
                    uri = ((RDFResource) imp).getURI();
                }
                if (uri != null) {
                    URI logicalURI = null;
                    try {
                        logicalURI = new URI(uri);
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    URL physicalURL = uriResolver.getPhysicalURL(logicalURI);
                    if (physicalURL != null) {
                        if (physicalURL.toString().startsWith("file:") &&
                                !new File(physicalURL.getFile()).exists()) {
                            logger.logWarning("Local file " + physicalURL + " could not be found for import");
                            physicalURL = logicalURI.toURL();
                            logger.logWarning("  Attempting to use " + physicalURL + " instead.");
                        }
                        if (!physicalURL.toString().startsWith("file:") && inUI) {
                            File path = OntPolicy.getPossibleFilePath(kb.getProject());
                            if (path != null) {
                                String str = logicalURI.toString();
                                int index = str.lastIndexOf('/');
                                if (index > 0 && index < str.length() - 1) {
                                    String localNameStart = str.substring(index + 1);
                                    String[] suffixes = new String[]{
                                        "", ".owl", ".rdf", ".rdfs"
                                    };
                                    for (int i = 0; i < suffixes.length; i++) {
                                        String suffix = suffixes[i];
                                        String localName = localNameStart + suffix;
                                        File suggestedFile = new File(path, localName);
                                        if (suggestedFile.exists()) {
                                            if (JOptionPane.showConfirmDialog(Application.getMainWindow(),
                                                    "A local file has been found that could match the import" +
                                                    "\n" + logicalURI + "." +
                                                    "\nShould " + suggestedFile + " be used instead of the URI?",
                                                    "Confirm import redirection...", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                                                uriResolver.setPhysicalURL(logicalURI, localName);
                                                physicalURL = suggestedFile.toURL();
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        String physicalURLString = physicalURL.toString();
                        if (!imports.contains(uri) &&
                                !imports.contains(physicalURLString)) {
                            imports.add(uri);
                            imports.add(physicalURLString);
                            currentDefaultNamespace = uri;
                            this.tripleStore = tripleStoreModel.createTripleStore(uri);
                            tripleStores.add(this.tripleStore);
                            tripleStoreModel.setActiveTripleStore(this.tripleStore);
                            ARP arp = createARP();
                            logger.logImport(uri, physicalURLString);
                            arp.load(physicalURL.openStream(), uri);
                            runImports(this.tripleStore, imports);
                        }
                    }
                    else {
                        logger.logWarning("Ignoring import " + uri);
                    }
                }
            }
        }
    }


    public void run(final InputStream is, final String uri) throws Exception {
        run(owlModel.getTripleStoreModel().getActiveTripleStore(), uri, new ARPInvokation() {
            public void invokeARP(ARP arp) throws Exception {
                arp.load(is, uri);
            }
        });
    }


    public void run(final Reader reader, final String uri) throws Exception {
        run(owlModel.getTripleStoreModel().getActiveTripleStore(), uri, new ARPInvokation() {
            public void invokeARP(ARP arp) throws Exception {
                arp.load(reader, uri);
            }
        });
    }


    public void run(URI uri) throws Exception {
        final TripleStoreModel tripleStoreModel = owlModel.getTripleStoreModel();
        final TripleStore activeTripleStore = tripleStoreModel.getActiveTripleStore();
        run(uri, activeTripleStore);
        activeTripleStore.setName(uri.toString());
    }


    public void setLogger(ProtegeOWLParserLogger logger) {
        this.logger = logger;
    }


    private void setPrefixForDefaultNamespace(String prefixForDefaultNamespace) {
        this.prefixForDefaultNamespace = prefixForDefaultNamespace;
    }


    public void setURI2NameConverter(URI2NameConverter converter) {
        this.uri2NameConverter = converter;
    }


    public void setURLResolver(URIResolver urlResolver) {
        this.uriResolver = urlResolver;
    }


    private class MyErrorHandler implements ErrorHandler {

        public void error(SAXParseException exception) throws SAXException {
            System.err.println("Error");
            exception.printStackTrace();
        }


        public void fatalError(SAXParseException exception) throws SAXException {
            System.err.println("Fatal Error");
            exception.printStackTrace();
        }


        public void warning(SAXParseException exception) throws SAXException {
            logger.logWarning(exception.toString());
            exception.printStackTrace();
        }
    }


    private class MyNamespaceHandler implements NamespaceHandler {

        private RDFResource ontology;

        private Map prefix2Namespace = new HashMap();


        public void startPrefixMapping(String prefix, String namespace) {
            if (!namespace.endsWith("#") && !namespace.endsWith("/") && !namespace.endsWith(":")) {
                logger.logWarning("Invalid namespace \"" + namespace + "\" for prefix \"" + prefix + "\" ignored.");
            }
            else {
                // System.out.println("Starting mapping \"" + prefix + "\" -> " + namespace);
                if (prefixForDefaultNamespace != null && prefix.length() == 0) {
                    owlModel.getNamespaceManager().setPrefix(namespace, prefixForDefaultNamespace);
                    prefix = prefixForDefaultNamespace;
                    prefixForDefaultNamespace = null;
                }
                prefix = uri2NameConverter.addPrefix(namespace, prefix);
                prefix2Namespace.put(prefix, namespace);
            }
        }


        public void endPrefixMapping(String prefix) {
            if (ontology == null) {
                ontology = TripleStoreUtil.getFirstOntology(owlModel, tripleStore);
                if (ontology == null) {
                    String defaultNamespace = (String) prefix2Namespace.get("");
                    if (defaultNamespace == null) {
                        logger.logWarning("No default namespace found in file.  Will use " + currentDefaultNamespace);
                        defaultNamespace = currentDefaultNamespace;
                        prefix2Namespace.put("", defaultNamespace);
                    }
                    FrameID id = FrameID.createLocal(count++);
                    ontology = new DefaultOWLOntology(owlModel, id);
                    String tempName = uri2NameConverter.getTemporaryRDFResourceName(defaultNamespace);
                    tripleStore.setRDFResourceName(ontology, tempName);
                    tripleStore.add(ontology, owlModel.getRDFTypeProperty(), owlModel.getOWLOntologyClass());
                    tripleStore.getNarrowFrameStore().addValues(ontology,
                            ((KnowledgeBase) owlModel).getSlot(OWLNames.Slot.ONTOLOGY_PREFIXES),
                            null, false, Collections.singleton(":" + defaultNamespace));
                    // ontology = owlModel.getDefaultOWLOntology();
                }
            }
            String namespace = (String) prefix2Namespace.get(prefix);
            if (namespace != null) {
                //System.out.println("- Registering \"" + prefix + "\" : " + namespace);
                replaceNamespace(tripleStore, ontology, prefix, namespace);
                owlModel.getNamespaceManager().update();
            }
        }
    }


    private class MyStatementHandler implements StatementHandler {

        public void statement(AResource aSubject, AResource aPredicate, AResource aObject) {
            //System.out.println("URI: " + aSubject + " " + aPredicate + " " + " " + aObject);
            RDFProperty predicate = getRDFProperty(aPredicate);
            if (rdfRestProperty.equals(predicate)) {
                isRDFList = true;
            }
            RDFResource object = getRDFResource(aObject);
            if (predicate.equals(rdfTypeProperty)) {
                currentType = object;
            }
            isRDFList = rdfFirstProperty.equals(predicate) || rdfRestProperty.equals(predicate);
            RDFResource subject = getRDFResource(aSubject);
            isRDFList = false;
            currentType = null;
            if (tripleStoreModel.getPropertyValues(subject, predicate).contains(object)) {
                //System.out.println(" -> Duplicated");
            }
            else {
                tripleStore.add(subject, predicate, object);
                logger.logTripleAdded(subject, predicate, object);
            }
        }


        public void statement(AResource aSubject, AResource aPredicate, ALiteral aLiteral) {
            // System.out.println("Lit: " + aSubject + " " + aPredicate + " " + " " + aLiteral);
            RDFResource subject = getRDFResource(aSubject);
            RDFProperty predicate = getRDFProperty(aPredicate);
            Object object = createLiteralObject(aLiteral, predicate);
            tripleStore.add(subject, predicate, object);
            logger.logTripleAdded(subject, predicate, object);
        }
    }


    /**
     * An interface needed as an abstraction of the various methods to invoke the Jena ARP
     * (the various load methods with different parameters).
     */
    public interface ARPInvokation {

        public void invokeARP(ARP arp) throws Exception;
    }
}
