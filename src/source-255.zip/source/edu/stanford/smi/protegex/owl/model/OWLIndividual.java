package edu.stanford.smi.protegex.owl.model;


/**
 * A simple instance of an owl:Class (i.e. neither a class nor a property).
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLIndividual extends RDFIndividual {

}
