package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.model.OWLIndividual;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadSameAsTestCase extends AbstractJenaTestCase {

    public void testLoadSameAs() throws Exception {
        OWLNamedClass cls = owlModel.createOWLNamedClass("Class");
        OWLIndividual a = cls.createOWLIndividual("A");
        OWLIndividual b = cls.createOWLIndividual("B");
        a.addSameAs(b);

        OWLModel newModel = reload(owlModel);
        OWLIndividual newA = newModel.getOWLIndividual(a.getName());
        OWLIndividual newB = newModel.getOWLIndividual(b.getName());
        assertSize(1, newA.getSameAs());
        assertContains(newB, newA.getSameAs());
    }
}
