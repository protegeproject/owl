package edu.stanford.smi.protegex.owl.javacode;

import edu.stanford.smi.protege.Application;
import edu.stanford.smi.protege.resource.Icons;
import edu.stanford.smi.protege.util.ModalDialog;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.ui.actions.ResourceActionManager;
import edu.stanford.smi.protegex.owl.ui.widget.OWLUI;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class JavaCodeGeneratorAction extends AbstractAction {

    private OWLModel owlModel;


    static {
        ResourceActionManager.addResourceActionClass(JavaCodeGeneratorResourceAction.class);
    }


    public JavaCodeGeneratorAction(OWLModel owlModel) {
        super("Generate Protege-OWL Java Code...", Icons.getBlankIcon());
        this.owlModel = owlModel;
    }


    public void actionPerformed(ActionEvent e) {
        EditableJavaCodeGeneratorOptions options = new ProjectBasedJavaCodeGeneratorOptions(owlModel.getProject());
        JavaCodeGeneratorPanel panel = new JavaCodeGeneratorPanel(options);
        if (ModalDialog.showDialog(Application.getMainWindow(), panel,
                (String) getValue(Action.NAME), ModalDialog.MODE_OK_CANCEL) == ModalDialog.OPTION_OK) {
            panel.ok();
            JavaCodeGenerator creator = new JavaCodeGenerator(owlModel, options);
            try {
                creator.createAll();
                OWLUI.showMessageDialog("Java code successfully generated.");
            }
            catch (Exception ex) {
                ex.printStackTrace();
                OWLUI.showMessageDialog("Could not create Java code:\n" + ex, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
