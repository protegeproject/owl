package edu.stanford.smi.protegex.owl.model.triplestore;

import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.model.framestore.MergingNarrowFrameStore;
import edu.stanford.smi.protege.model.framestore.NarrowFrameStore;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;

import java.util.Iterator;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class TripleStoreUtil {


    public static RDFResource getFirstOntology(OWLModel owlModel, TripleStore tripleStore) {
        RDFSNamedClass owlOntologyClass = owlModel.getOWLOntologyClass();
        Iterator ontologies = tripleStore.listSubjects(owlModel.getRDFTypeProperty(), owlOntologyClass);
        if (ontologies.hasNext()) {
            return (RDFResource) ontologies.next();
        }
        else {
            return null;
        }
    }


    /**
     * Updates the "isIncluded()" flag for all Frames, so that only those Frames that have their
     * :NAME in the active FrameStore are not included.
     *
     * @param mnfs the MergingNarrowFrameStore
     */
    public static void updateFrameInclusion(MergingNarrowFrameStore mnfs, Slot nameSlot) {
        NarrowFrameStore activeFrameStore = mnfs.getActiveFrameStore();
        updateFrameInclusion(activeFrameStore, nameSlot, false);
        NarrowFrameStore systemFrameStore = mnfs.getSystemFrameStore();
        Iterator frameStores = mnfs.getAllFrameStores().iterator();
        while (frameStores.hasNext()) {
            NarrowFrameStore frameStore = (NarrowFrameStore) frameStores.next();
            if (frameStore != systemFrameStore && frameStore != activeFrameStore) {
                updateFrameInclusion(frameStore, nameSlot, true);
            }
        }
    }


    private static void updateFrameInclusion(NarrowFrameStore frameStore, Slot nameSlot, boolean included) {
        for (Iterator it = frameStore.getFrames().iterator(); it.hasNext();) {
            Frame frame = (Frame) it.next();
            if (!frame.isSystem()) {
                if (frameStore.getValuesCount(frame, nameSlot, null, false) > 0) {
                    frame.setIncluded(included);
                    // System.out.println("- " + frame.getName() + ": " + included);
                }
            }
        }
    }
}
