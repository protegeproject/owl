package edu.stanford.smi.protegex.owl.model;

import java.util.Collection;

/**
 * An interface for objects capable of mapping true URI namespaces into their
 * prefixed (e.g., "owl") and vice-versa.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface NamespaceMap {


    String getDefaultNamespace();


    String getNamespaceForPrefix(String prefix);


    String getPrefix(String namespace);


    Collection getPrefixes();


    void removePrefix(String prefix);


    void setDefaultNamespace(String value);


    void setPrefix(String namespace, String prefix);
}
