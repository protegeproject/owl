package edu.stanford.smi.protegex.owl.swrl.model;


/**
 * @author Martin O'Connor  <moconnor@smi.stanford.edu>
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface SWRLVariable extends SWRLIndividual {

} // SWRLVariable

