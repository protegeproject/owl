package edu.stanford.smi.protegex.owl.model.impl.tests;

import edu.stanford.smi.protegex.owl.model.RDFList;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.util.Arrays;
import java.util.Collection;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultRDFListTestCase extends AbstractJenaTestCase {

    public void testRDFListsAreAnonymous() {
        Collection values = Arrays.asList(new String[]{"A", "B"});
        RDFList list = owlModel.createRDFList(values.iterator());
        assertTrue(list.isAnonymous());
        assertTrue(list.getRest().isAnonymous());
    }


    public void testRDFNilIsNotAnonymous() {
        assertFalse(owlModel.getRDFNil().isAnonymous());
    }
}
