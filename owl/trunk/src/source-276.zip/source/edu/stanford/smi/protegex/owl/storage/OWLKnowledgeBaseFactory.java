package edu.stanford.smi.protegex.owl.storage;

import edu.stanford.smi.protege.model.KnowledgeBaseFactory;

/**
 * An interface for KnowledgeBaseFactories which can save proper OWL.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLKnowledgeBaseFactory extends KnowledgeBaseFactory {

}
