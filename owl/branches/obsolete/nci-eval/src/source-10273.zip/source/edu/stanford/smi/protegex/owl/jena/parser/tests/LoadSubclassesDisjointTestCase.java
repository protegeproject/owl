package edu.stanford.smi.protegex.owl.jena.parser.tests;

import edu.stanford.smi.protegex.owl.model.OWLNamedClass;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadSubclassesDisjointTestCase extends AbstractProtegeOWLParserTestCase {

    public void testLoadSubclassesDisjoint() throws Exception {
        loadRemoteOntology("subclassesDisjoint.owl");
        OWLNamedClass b = owlModel.getOWLNamedClass("B");
        assertSize(2, b.getDisjointClasses());
    }
}
