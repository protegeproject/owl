package edu.stanford.smi.protegex.owl.javacode;

import edu.stanford.smi.protege.Application;
import edu.stanford.smi.protege.resource.Icons;
import edu.stanford.smi.protege.util.ModalDialog;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;
import edu.stanford.smi.protegex.owl.ui.actions.ResourceAction;
import edu.stanford.smi.protegex.owl.ui.cls.ExtractTaxonomyAction;
import edu.stanford.smi.protegex.owl.ui.widget.OWLUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class JavaCodeGeneratorResourceAction extends ResourceAction {

    public JavaCodeGeneratorResourceAction() {
        super("Generate Protege-OWL Java Code for class...", Icons.getBlankIcon(),
                ExtractTaxonomyAction.GROUP);
    }


    public void actionPerformed(ActionEvent e) {
        OWLModel owlModel = getOWLModel();
        EditableJavaCodeGeneratorOptions options = new ProjectBasedJavaCodeGeneratorOptions(owlModel.getProject());
        JavaCodeGeneratorPanel panel = new JavaCodeGeneratorPanel(options);
        if (ModalDialog.showDialog(Application.getMainWindow(), panel,
                (String) getValue(Action.NAME), ModalDialog.MODE_OK_CANCEL) == ModalDialog.OPTION_OK) {
            panel.ok();
            JavaCodeGenerator creator = new JavaCodeGenerator(owlModel, options);
            try {
                RDFSNamedClass cls = (RDFSNamedClass) getResource();
                creator.createInterface(cls);
                creator.createImplementation(cls);
                creator.createFactoryClass();
                OWLUI.showMessageDialog("Java code successfully generated for " + cls.getLocalName() + ".");
            }
            catch (Exception ex) {
                ex.printStackTrace();
                OWLUI.showMessageDialog("Could not create Java code:\n" + ex, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    public boolean isSuitable(Component component, RDFResource resource) {
        return resource instanceof RDFSNamedClass && !resource.isSystem();
    }
}
