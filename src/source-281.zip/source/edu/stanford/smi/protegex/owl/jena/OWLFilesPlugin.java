package edu.stanford.smi.protegex.owl.jena;


/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLFilesPlugin extends OWLCreateProjectPlugin {

    void addImport(String uri, String prefix);


    void setFile(String fileURI);


    void setLanguage(String lang);
}
