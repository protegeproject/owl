package edu.stanford.smi.protegex.owl.model.triplestore.impl;

import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;

/**
 * A class that can be used to perform various post processing steps on an OWLModel
 * after triples have been changed.  This only delegates to other classes.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class TripleChangePostProcessor {


    public static void postProcess(OWLModel owlModel) {
        TripleStore activeTripleStore = owlModel.getTripleStoreModel().getActiveTripleStore();
        long startTime = System.currentTimeMillis();

        new RDFListPostProcessor(owlModel);
        System.out.println("Completed lists after " + (System.currentTimeMillis() - startTime));

        new OWLAnonymousClassPostProcessor(owlModel);
        System.out.println("Completed anonymous classes after " + (System.currentTimeMillis() - startTime));

        new OWLDeprecatedClassPostProcessor(owlModel);
        System.out.println("Completed deprecated classes after " + (System.currentTimeMillis() - startTime));

        new RDFPropertyPostProcessor(owlModel);
        System.out.println("Completed properties after " + (System.currentTimeMillis() - startTime));

        new RDFSNamedClassPostProcessor(owlModel);
        System.out.println("Completed named classes after " + (System.currentTimeMillis() - startTime));
        owlModel.getTripleStoreModel().setActiveTripleStore(activeTripleStore);
    }
}
