package edu.stanford.smi.protegex.owl.jena.parser.tests;


/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadOWLHasValueTestCase extends AbstractProtegeOWLParserTestCase {

    public void testHasRestriction() throws Exception {
        loadRemoteOntology("hasRestrictionOnDoubleProperty.owl");
    }
}
