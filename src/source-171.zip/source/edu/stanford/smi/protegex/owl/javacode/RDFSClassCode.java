package edu.stanford.smi.protegex.owl.javacode;

import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * An object providing metadata about an RDFSNamedClass
 * or OWLNamedClass, suitable for Java code generation.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class RDFSClassCode {

    private RDFSNamedClass cls;


    public RDFSClassCode(RDFSNamedClass cls) {
        this.cls = cls;
    }


    public String getJavaName() {
        return getValidJavaName(cls.getLocalName());
    }


    /**
     * @return a List of RDFPropertyAtClassCodes
     * @see RDFPropertyAtClassCode
     */
    public List getPropertyCodes() {
        List codes = new ArrayList();
        for (Iterator it = cls.getUnionDomainProperties().iterator(); it.hasNext();) {
            RDFProperty property = (RDFProperty) it.next();
            RDFPropertyAtClassCode code = new RDFPropertyAtClassCode(cls, property);
            codes.add(code);
        }
        Collections.sort(codes);
        return codes;
    }


    public static String getValidJavaName(String name) {
        for (int i = 1; i < name.length(); i++) {
            char c = name.charAt(i);
            if (!Character.isJavaIdentifierPart(c)) {
                name = name.replace(c, '_');
            }
        }
        return name;
    }
}
