package edu.stanford.smi.protegex.owl.tests;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntResource;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.util.FileUtils;
import edu.stanford.smi.protegex.owl.ProtegeOWL;
import edu.stanford.smi.protegex.owl.jena.Jena;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.jena.loader.JenaLoader;

import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.net.URI;
import java.util.Iterator;

/**
 * The base class of various JUnit tests in this package.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public abstract class AbstractJenaTestCase extends AbstractOWLTestCase {

    protected OntModel ontModel;

    protected Model owlFullModel;


    protected int getNamedClassesCount() {
        return list(ontModel.listNamedClasses()).size();
    }


    public void loadRemoteOntology(String localFileName) throws Exception {
        loadTestOntology(getRemoteOntologyURI(localFileName));
    }


    protected void loadRemoteOntologyWithProtegeMetadataOntology() throws Exception {
        loadRemoteOntology("import-protege.owl");
    }


    public void loadTestOntology(String localFileName) throws Exception {
        URI uri = getTestOntologyURI(localFileName);
        loadTestOntology(uri);
    }


    public void loadTestOntology(URI uri) throws Exception {
        JenaLoader jenaLoader = new JenaLoader(owlModel, uri, FileUtils.langXMLAbbrev);
        ontModel = jenaLoader.getOntModel();
        owlFullModel = jenaLoader.getOWLFullModel();
    }


    protected boolean ontResourceExists(Iterator it, String uri) {
        while (it.hasNext()) {
            OntResource ontResource = (OntResource) it.next();
            String otherURI = ontResource.getURI();
            if (otherURI.equals(uri)) {
                return true;
            }
        }
        return false;
    }


    public JenaOWLModel reload(JenaOWLModel owlModel) throws Exception {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        Jena.dumpRDF(owlModel.getOntModel(), stream);
        String str = stream.toString();
        return ProtegeOWL.createJenaOWLModelFromReader(new StringReader(str));
    }
}
