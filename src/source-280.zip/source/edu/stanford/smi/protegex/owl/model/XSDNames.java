package edu.stanford.smi.protegex.owl.model;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface XSDNames {

    final static String PREFIX = "xsd:";


    final static String ANY_URI = PREFIX + "anyURI";

    final static String BASE_64_BINARY = PREFIX + "base64Binary";

    final static String BOOLEAN = PREFIX + "boolean";

    final static String BYTE = PREFIX + "byte";

    final static String DATE = PREFIX + "date";

    final static String DATE_TIME = PREFIX + "dateTime";

    final static String DECIMAL = PREFIX + "decimal";

    final static String DOUBLE = PREFIX + "double";

    final static String DURATION = PREFIX + "duration";

    final static String FLOAT = PREFIX + "float";

    final static String INT = PREFIX + "int";

    final static String INTEGER = PREFIX + "integer";

    final static String LONG = PREFIX + "long";

    final static String SHORT = PREFIX + "short";

    final static String STRING = PREFIX + "string";

    final static String TIME = PREFIX + "time";
}
