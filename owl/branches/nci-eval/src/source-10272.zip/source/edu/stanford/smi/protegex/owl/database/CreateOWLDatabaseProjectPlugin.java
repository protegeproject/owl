package edu.stanford.smi.protegex.owl.database;

import edu.stanford.smi.protege.model.KnowledgeBaseFactory;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.model.framestore.FrameStore;
import edu.stanford.smi.protege.plugin.AbstractCreateProjectPlugin;
import edu.stanford.smi.protege.plugin.CreateProjectWizard;
import edu.stanford.smi.protege.storage.database.DatabaseKnowledgeBaseFactory;
import edu.stanford.smi.protege.util.Log;
import edu.stanford.smi.protege.util.PropertyList;
import edu.stanford.smi.protege.util.WizardPage;
import edu.stanford.smi.protegex.owl.jena.parser.ProtegeOWLParser;
import edu.stanford.smi.protegex.owl.model.OWLModel;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * @author Ray Fergerson  <fergerson@smi.stanford.edu>
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class CreateOWLDatabaseProjectPlugin extends
        AbstractCreateProjectPlugin implements OWLDatabasePlugin {

    private String driver;

    private String table;

    private String username;

    private String password;

    private URI ontologyFileURI;

    private String url;


    public CreateOWLDatabaseProjectPlugin() {
        super("OWL Database");
    }


    public boolean canCreateProject(KnowledgeBaseFactory factory, boolean useExistingSources) {
        return factory.getClass() == OWLDatabaseKnowledgeBaseFactory.class;
    }


    public Project createNewProject(KnowledgeBaseFactory factory) {
        Collection errors = new ArrayList();
        Project project = super.createNewProject(factory);
        initializeSources(project.getSources());
        try {
            File tempProjectFile = File.createTempFile("protege", "temp");
            project.setProjectFilePath(tempProjectFile.getPath());
            project.save(errors);
            project = Project.loadProjectFromFile(tempProjectFile.getPath(), errors);
            List fss = project.getKnowledgeBase().getFrameStores();
            for (Iterator ir = fss.iterator(); ir.hasNext();) {
                FrameStore frameStore = (FrameStore) ir.next();
                System.out.println("FrameStore: " + frameStore.getClass());
            }
            FrameStore last = (FrameStore) fss.get(fss.size() - 1);
            System.out.println("Last: " + last);
            if (ontologyFileURI != null) {
                OWLModel owlModel = (OWLModel) project.getKnowledgeBase();
                ProtegeOWLParser parser = new ProtegeOWLParser(owlModel, false);
                try {
                    parser.run(ontologyFileURI);
                }
                catch (Exception ex) {
                    Log.getLogger().severe("Could not load OWL file into database: " + ex);
                    ex.printStackTrace();
                    errors.add(ex);
                }
            }
            handleErrors(errors);
            project.setProjectFilePath(null);
            tempProjectFile.delete();
        }
        catch (IOException e) {
            Log.getLogger().severe(Log.toString(e));
        }
        return project;
    }


    public WizardPage createCreateProjectWizardPage(CreateProjectWizard wizard,
                                                    boolean useExistingSources) {
        return new OWLDatabaseWizardPage(wizard, this, useExistingSources);
    }


    protected void initializeSources(PropertyList sources) {
        DatabaseKnowledgeBaseFactory.setSources(sources, driver, url, table, username, password);
    }


    public void setDriver(String driver) {
        this.driver = driver;
    }


    public void setOntologyFileURI(URI uri) {
        this.ontologyFileURI = uri;
    }


    public void setTable(String table) {
        this.table = table;
    }


    public void setURL(String url) {
        this.url = url;
    }


    public void setUsername(String username) {
        this.username = username;
    }


    public void setPassword(String password) {
        this.password = password;
    }
}