package edu.stanford.smi.protegex.owl.swrl.model.impl;

import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLDataRangeAtom;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLNames;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLVariable;

import java.util.Set;

public class DefaultSWRLDataRangeAtom extends DefaultSWRLAtom implements SWRLDataRangeAtom {

    public DefaultSWRLDataRangeAtom(KnowledgeBase kb, FrameID id) {
        super(kb, id);
    } // DefaultSWRLDataRangeAtom


    public DefaultSWRLDataRangeAtom() {
    }


    public void getReferencedInstances(Set set) {
        Object argument1 = getArgument1();
        if (argument1 != null) {
            set.add(argument1);
        }
        Instance dataRange = getDataRange();
        if (dataRange != null) {
            set.add(dataRange);
        }
    }


    public SWRLVariable getArgument1() {
        return (SWRLVariable) getDirectOwnSlotValue(getKnowledgeBase().getSlot(SWRLNames.Slot.ARGUMENT1));
    } // getArgument1


    public void setArgument1(SWRLVariable variable) {
        setOwnSlotValue(getKnowledgeBase().getSlot(SWRLNames.Slot.ARGUMENT1), variable);
    } // setArgument1


    public RDFResource getDataRange() {
        return (RDFResource) getDirectOwnSlotValue(getKnowledgeBase().getSlot(SWRLNames.Slot.DATA_RANGE));
    } // getDataRange


    public void setDataRange(RDFResource instance) {
        setOwnSlotValue(getKnowledgeBase().getSlot(SWRLNames.Slot.DATA_RANGE), instance);
    } // setDataRange


    public String getBrowserText() {
        String s = "";

        if (getDataRange() == null || getArgument1() == null) return super.getBrowserText();

        s += getDataRange().getBrowserText() + "(";
        s += getArgument1().getBrowserText() + ")";

        return s;

    } // getBrowserText

} // DefaultSWRLDataRangeAtom


