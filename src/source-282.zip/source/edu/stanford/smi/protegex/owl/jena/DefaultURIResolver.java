package edu.stanford.smi.protegex.owl.jena;

import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.util.ApplicationProperties;
import edu.stanford.smi.protegex.owl.model.ProtegeNames;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLNames;
import edu.stanford.smi.protegex.owl.ui.jena.OntPolicyManager;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

/**
 * The default implementation of URIResolver, using the project's OntPolicy file.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultURIResolver implements URIResolver {


    private Project project;


    public DefaultURIResolver(Project project) {
        this.project = project;
    }


    private String getApplicationDirectory() {
        return ApplicationProperties.getApplicationDirectory().getAbsolutePath();
    }


    public URL getPhysicalURL(URI uri) {
        final String str = uri.toString();
        if (isIgnoredImport(str)) {
            return null;
        }

        try {
            if (SWRLNames.SWRL_IMPORT.equals(str)) {
                return getLocalSWRLURL();
            }
            else if (SWRLNames.SWRLB_IMPORT.equals(str)) {
                return getLocalSWRLBURL();
            }
            else if (ProtegeNames.FILE.equals(str)) {
                return getLocalProtegeURL();
            }
            String alt = OntPolicyManager.getAltURL(project, str);
            if (alt != null) {
                return new URL(alt);
            }
        }
        catch (Exception ex) {
            System.err.println("[DefaultURIResolver] Warning: Could not resolve " + uri + ": " + ex);
        }

        try {
            return uri.toURL();
        }
        catch (MalformedURLException ex) {
            System.err.println("[DefaultURIResolver] Error: Could not resolve " + uri + ": " + ex);
            return null;
        }
    }


    public String getRelativePhysicalFileName(URI uri) {
        return OntPolicyManager.getRelativePhysicalFileName(project, uri.toString());
    }


    public String getPreferredNamespacePrefix(String namespace) {
        return OntPolicyManager.getPrefix(project, namespace);
    }


    public boolean isEditableImport(URI uri) {
        return OntPolicyManager.isEditable(project, uri.toString());
    }


    protected URL getLocalProtegeURL() throws MalformedURLException {
        return new File(new File(new File(getApplicationDirectory(), "plugins"),
                Jena.ROOT_FOLDER), "protege.owl").toURL();
    }


    protected URL getLocalSWRLURL() throws MalformedURLException {
        return new File(new File(new File(getApplicationDirectory(), "plugins"),
                Jena.ROOT_FOLDER), "swrl.owl").toURL();
    }


    protected URL getLocalSWRLBURL() throws MalformedURLException {
        return new File(new File(new File(getApplicationDirectory(), "plugins"),
                Jena.ROOT_FOLDER), "swrlb.owl").toURL();
    }


    protected boolean isIgnoredImport(String uri) {
        return uri.equals(OWL.getURI()) ||
                uri.equals(RDF.getURI()) ||
                uri.equals(RDFS.getURI()) ||
                uri.equals("http://www.w3.org/2002/07/owl") ||
                uri.equals("http://www.w3.org/2000/01/rdf-schema");
    }


    public void setEditableImport(URI uri, boolean value) {
        OntPolicyManager.setEditableImport(project, uri.toString(), value);
        save();
    }


    public void setPhysicalURL(URI uri, URL physicalURL) {
        String url = physicalURL == null ? null : physicalURL.toString();
        OntPolicyManager.setAltURI(project, uri.toString(), url);
        save();
    }


    public void setPhysicalURL(URI uri, String relativeFileName) {
        OntPolicyManager.setAltURI(project, uri.toString(), relativeFileName);
        save();
    }


    private void save() {
        try {
            OntPolicyManager.saveCurrentModel(project);
        }
        catch (Exception ex) {
            System.err.println("Warning: Could not save ont-policy file!");
            ex.printStackTrace();
        }
    }
}
