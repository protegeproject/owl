package edu.stanford.smi.protegex.owl.swrl.ui.table;

import edu.stanford.smi.protege.event.KnowledgeBaseAdapter;
import edu.stanford.smi.protege.event.KnowledgeBaseEvent;
import edu.stanford.smi.protege.event.KnowledgeBaseListener;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.RDFSClass;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.event.ModelAdapter;
import edu.stanford.smi.protegex.owl.model.event.ModelListener;
import edu.stanford.smi.protegex.owl.ui.results.ResultsPanel;

import javax.swing.*;
import java.awt.*;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class SWRLResultsPanel extends ResultsPanel {

    private RDFResource instance;

    private ModelListener listener = new ModelAdapter() {
        public void classDeleted(RDFSClass cls) {
            if (instance.equals(cls)) {
                closeSoon();
            }
        }


        public void individualDeleted(RDFResource resource) {
            if (instance.equals(resource)) {
                closeSoon();
            }
        }


        public void propertyDeleted(RDFProperty property) {
            if (instance.equals(property)) {
                closeSoon();
            }
        }
    };

    private SWRLTablePanel tablePanel;


    public SWRLResultsPanel(RDFResource instance) {
        this.instance = instance;
        OWLModel okb = instance.getOWLModel();
        okb.addModelListener(listener);
        tablePanel = new SWRLTablePanel(okb, instance);
        add(BorderLayout.CENTER, tablePanel);
    }


    private void closeSoon() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                close();
            }
        });
    }


    public void dispose() {
        tablePanel.dispose();
        OWLModel okb = instance.getOWLModel();
        okb.removeModelListener(listener);
    }


    public String getTabName() {
        return "SWRL Rules about " + instance.getBrowserText();
    } // getTabName
}
