package edu.stanford.smi.protegex.owl.inference.ui.inspector;

import edu.stanford.smi.protege.util.ModalDialog;
import edu.stanford.smi.protegex.owl.inference.ui.icons.InferenceIcons;
import edu.stanford.smi.protegex.owl.model.OWLModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * User: matthewhorridge<br>
 * The Univeristy Of Manchester<br>
 * Medical Informatics Group<br>
 * Date: Sep 15, 2004<br><br>
 * <p/>
 * matthew.horridge@cs.man.ac.uk<br>
 * www.cs.man.ac.uk/~horridgm<br><br>
 */
public class ShowReasonerInspectorAction extends AbstractAction {

    private OWLModel kb;

    private Component parent;


    public ShowReasonerInspectorAction(Component parent, OWLModel kb) {
        super("Reasoner inspector...", InferenceIcons.getReasonerInspectorIcon());
        this.parent = parent;
        this.kb = kb;
    }


    /**
     * Invoked when an action occurs.
     */
    public void actionPerformed(ActionEvent e) {
        ModalDialog.showDialog(parent, new ReasonerInspectorPanel(kb), "Reasoner Inspector", ModalDialog.MODE_CLOSE);
    }
}

