package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.model.OWLObjectProperty;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadDeprecatedTestCase extends AbstractJenaTestCase {

    public void testLoadDeprecatedClass() throws Exception {
        loadRemoteOntology("deprecated.owl");
        RDFSNamedClass carClass = owlModel.getRDFSNamedClass("Car");
        assertNotNull(carClass);
        //assertFalse(carClass instanceof OWLNamedClass);
        assertTrue(carClass.isDeprecated());
    }


    public void testLoadDeprecatedProperty() throws Exception {
        loadRemoteOntology("deprecated.owl");
        assertTrue(owlModel.getSlot("drives") instanceof OWLObjectProperty);
        RDFProperty property = (RDFProperty) owlModel.getSlot("hasDriver");
        assertNotNull(property);
        // assertFalse(property instanceof OWLObjectProperty);
        assertTrue(property.isDeprecated());
    }
}
