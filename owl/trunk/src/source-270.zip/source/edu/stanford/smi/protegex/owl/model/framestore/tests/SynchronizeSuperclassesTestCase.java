package edu.stanford.smi.protegex.owl.model.framestore.tests;

import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;
import edu.stanford.smi.protegex.owl.model.RDFSNames;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class SynchronizeSuperclassesTestCase extends AbstractJenaTestCase {

    public void testDefaultSuperclass() {
        RDFProperty subClassOfProperty = owlModel.getRDFProperty(RDFSNames.Slot.SUB_CLASS_OF);
        RDFSNamedClass cls = owlModel.createRDFSNamedClass("Class");
        assertEquals(1, cls.getSuperclassCount());
        assertContains(owlThing, cls.getSuperclasses(false));
        assertSize(1, cls.getPropertyValues(subClassOfProperty));
        assertContains(owlThing, cls.getPropertyValues(subClassOfProperty));
    }


    public void testChangingSuperclass() {
        RDFProperty subClassOfProperty = owlModel.getRDFProperty(RDFSNames.Slot.SUB_CLASS_OF);
        RDFSNamedClass superclass = owlModel.createRDFSNamedClass("Superclass");
        RDFSNamedClass subclass = owlModel.createRDFSNamedClass("Subclass");
        subclass.addSuperclass(superclass);
        assertSize(2, subclass.getPropertyValues(subClassOfProperty));
        assertContains(owlThing, subclass.getPropertyValues(subClassOfProperty));
        assertContains(superclass, subclass.getPropertyValues(subClassOfProperty));
        subclass.removeSuperclass(owlThing);
        assertSize(1, subclass.getPropertyValues(subClassOfProperty));
        assertContains(superclass, subclass.getPropertyValues(subClassOfProperty));
    }


    public void testCreateSuperclass() {
        RDFProperty subClassOfProperty = owlModel.getRDFProperty(RDFSNames.Slot.SUB_CLASS_OF);
        RDFSNamedClass superclass = owlModel.createRDFSNamedClass("Superclass");
        RDFSNamedClass subclass = owlModel.createRDFSNamedSubclass("Subclass", superclass);
        assertSize(1, subclass.getPropertyValues(subClassOfProperty));
        assertContains(superclass, subclass.getPropertyValues(subClassOfProperty));
    }
}
