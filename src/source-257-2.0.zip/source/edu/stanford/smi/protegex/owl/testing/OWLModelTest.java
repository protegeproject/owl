package edu.stanford.smi.protegex.owl.testing;

import edu.stanford.smi.protegex.owl.model.OWLModel;

import java.util.List;

/**
 * An interface for objects that can perform sanity checks on an ontology.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLModelTest extends OWLTest {

    /**
     * @param okb
     * @return a List of OWLTestResult objects
     */
    List test(OWLModel okb);
}
