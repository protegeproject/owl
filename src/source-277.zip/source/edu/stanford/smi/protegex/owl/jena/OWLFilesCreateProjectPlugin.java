package edu.stanford.smi.protegex.owl.jena;

import edu.stanford.smi.protege.model.KnowledgeBaseFactory;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.model.WidgetDescriptor;
import edu.stanford.smi.protege.plugin.AbstractCreateProjectPlugin;
import edu.stanford.smi.protege.plugin.CreateProjectWizard;
import edu.stanford.smi.protege.util.FileUtilities;
import edu.stanford.smi.protege.util.PropertyList;
import edu.stanford.smi.protege.util.WizardPage;
import edu.stanford.smi.protegex.owl.jena.parser.ProtegeOWLParser;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.OWLOntology;
import edu.stanford.smi.protegex.owl.swrl.model.SWRLNames;
import edu.stanford.smi.protegex.owl.swrl.ui.SWRLProjectPlugin;
import edu.stanford.smi.protegex.owl.swrl.ui.tab.SWRLTab;
import edu.stanford.smi.protegex.owl.ui.cls.SwitchClassDefinitionResourceDisplayPlugin;
import edu.stanford.smi.protegex.owl.ui.jena.OWLFilesWizardPage;
import edu.stanford.smi.protegex.owl.ui.jena.OWLImportsWizardPage;
import edu.stanford.smi.protegex.owl.ui.menu.OWLMenuProjectPlugin;
import edu.stanford.smi.protegex.owl.ui.profiles.ProfilesManager;
import edu.stanford.smi.protegex.owl.ui.widget.OWLUI;

import java.net.URI;
import java.net.URL;
import java.util.*;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class OWLFilesCreateProjectPlugin
        extends AbstractCreateProjectPlugin
        implements OWLFilesPlugin {

    private String defaultNamespace;

    private Collection imports = new ArrayList();

    private Map importPrefixes = new HashMap();

    private String fileURI;

    private String lang;

    private String profileURI;

    private boolean propertiesView;


    public OWLFilesCreateProjectPlugin() {
        super("OWL Files");
    }


    public void addImport(String uri, String prefix) {
        imports.add(uri);
        importPrefixes.put(uri, prefix);
    }


    private void addImports(Project project) {
        JenaOWLModel owlModel = (JenaOWLModel) project.getKnowledgeBase();

        OWLOntology ontology = owlModel.getDefaultOWLOntology();
        if (imports.contains(SWRLNames.SWRL_IMPORT)) {
            Collection tabWidgetDescriptors = project.getTabWidgetDescriptors();
            WidgetDescriptor w = project.getTabWidgetDescriptor(SWRLTab.class.getName());
            w.setVisible(true);
            project.setTabWidgetDescriptorOrder(tabWidgetDescriptors);
            owlModel.getNamespaceManager().setPrefix(SWRLNames.SWRL_NAMESPACE, SWRLNames.SWRL_PREFIX);
            owlModel.getNamespaceManager().setPrefix(SWRLNames.SWRLB_NAMESPACE, SWRLNames.SWRLB_PREFIX);
        }

        for (Iterator it = imports.iterator(); it.hasNext();) {
            String uri = (String) it.next();
            String prefix = (String) importPrefixes.get(uri);
            String namespace = uri;
            if (!namespace.endsWith("#") && !namespace.endsWith("/")) {
                namespace += "#";
            }
            try {
                owlModel.getNamespaceManager().setPrefix(namespace, prefix);
                ontology.addImports(uri);
                final URI u = new URI(uri);
                URL url = owlModel.getURIResolver().getPhysicalURL(u);
                System.out.println("Adding import " + uri + " (from " + url + ")");
                ProtegeOWLParser.addImport(owlModel, u);
            }
            catch (Exception ex) {
                ex.printStackTrace();
                OWLUI.showErrorMessageDialog("Could not load import " + uri + ":\n" + ex);
            }
        }
        if (!imports.isEmpty()) {
            owlModel.getTripleStoreModel().updateEditableResourceState();
        }
    }


    private void addViewSettings(PropertyList sources) {
        SwitchClassDefinitionResourceDisplayPlugin.setPropertiesView(sources, propertiesView);
        if (profileURI != null) {
            ProfilesManager.setProfile(sources, profileURI);
        }
    }


    protected Project buildNewProject(KnowledgeBaseFactory factory) {
        ProtegeOWLParser.inUI = true;
        Project project = super.buildNewProject(factory);
        if (project != null) {
            OWLModel owlModel = (OWLModel) project.getKnowledgeBase();
            OWLMenuProjectPlugin.makeHiddenClsesWithSubclassesVisible(owlModel);
            if (SWRLProjectPlugin.isSWRLImported(owlModel)) {
                SWRLProjectPlugin.adjustWidgets(project);
            }
        }
        ProtegeOWLParser.inUI = true;
        return project;
    }


    public boolean canCreateProject(KnowledgeBaseFactory factory, boolean useExistingSources) {
        return factory.getClass() == JenaKnowledgeBaseFactory.class;
    }


    public WizardPage createCreateProjectWizardPage(CreateProjectWizard wizard, boolean useExistingSources) {
        if (useExistingSources) {
            return new OWLFilesWizardPage(wizard, this);
        }
        else {
            return new OWLImportsWizardPage(wizard, this);
        }
    }


    protected Project createNewProject(KnowledgeBaseFactory factory) {
        Project project = super.createNewProject(factory);
        OWLModel owlModel = (OWLModel) project.getKnowledgeBase();
        if (defaultNamespace != null) {
            owlModel.getNamespaceManager().setDefaultNamespace(defaultNamespace);
        }
        addViewSettings(project.getSources());
        addImports(project);
        OWLMenuProjectPlugin.makeHiddenClsesWithSubclassesVisible(owlModel);
        return project;
    }


    protected URI getBuildProjectURI() {
        if (fileURI != null) {
            if (fileURI.startsWith("file:")) {
                int index = fileURI.lastIndexOf('.');
                if (index > 0) {
                    String uri = FileUtilities.replaceExtension(fileURI, ".pprj");
                    try {
                        return new URI(uri);
                    }
                    catch (Exception ex) {
                    }
                }
            }
        }
        return super.getBuildProjectURI();
    }


    protected void initializeSources(PropertyList sources) {
        JenaKnowledgeBaseFactory.setOWLFileName(sources, fileURI);
        JenaKnowledgeBaseFactory.setOWLFileLanguage(sources, lang);
        addViewSettings(sources);
    }


    public void setFile(String fileURI) {
        this.fileURI = fileURI;
    }


    public void setLanguage(String lang) {
        this.lang = lang;
    }


    public void setDefaultNamespace(String namespace) {
        this.defaultNamespace = namespace;
    }


    public void setPropertiesView(boolean value) {
        this.propertiesView = value;
    }


    public void setProfile(String profileURI) {
        this.profileURI = profileURI;
    }
}
