package edu.stanford.smi.protegex.owl.jena;

import com.hp.hpl.jena.ontology.OntModel;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.plugin.ProjectPlugin;

/**
 * A ProjectPlugin with additional functions in Jena-based projects.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface JenaProjectPlugin extends ProjectPlugin {

    /**
     * Called after a Jena OntModel was loaded but before the conversion
     * into Protege objects is done using the JenaLoader.  This is the
     * hook that is used by the SWRL plugin to install another FrameFactory
     * before all the objects are created.
     *
     * @param project  the current Project
     * @param ontModel the OntModel
     */
    void afterJenaLoad(Project project, OntModel ontModel);
}
