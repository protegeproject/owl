package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.util.Collection;
import java.util.List;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadDatatypeEnumerationTestCase extends AbstractJenaTestCase {

    public void testLoadFloatRestriction() throws Exception {
        loadRemoteOntologyWithJenaLoader("datatypeEnumerationFloat.owl");
        OWLNamedClass cls = owlModel.getOWLNamedClass("Cls");
        OWLAllValuesFrom restriction = (OWLAllValuesFrom) cls.getRestrictions(false).iterator().next();
        RDFResource filler = restriction.getFiller();
        assertTrue(filler instanceof OWLDataRange);
        final Collection values = ((OWLDataRange) filler).getOneOf().getValues();
        assertSize(2, values);
        assertContains(new Float(1.1), values);
        assertContains(new Float(2.2), values);
        assertSize(0, owlModel.getOWLThingClass().getInstances(false));
    }


    public void testLoadIntRestriction() throws Exception {
        loadRemoteOntologyWithJenaLoader("datatypeEnumerationInt.owl");
        OWLNamedClass cls = owlModel.getOWLNamedClass("Cls");
        OWLAllValuesFrom restriction = (OWLAllValuesFrom) cls.getRestrictions(false).iterator().next();
        RDFResource filler = restriction.getFiller();
        assertTrue(filler instanceof OWLDataRange);
        Collection values = ((OWLDataRange) filler).getOneOf().getValues();
        assertSize(2, values);
        assertContains(new Integer(1), values);
        assertContains(new Integer(2), values);
    }


    public void testLoadStringRestriction() throws Exception {
        loadRemoteOntologyWithJenaLoader("datatypeEnumerationString.owl");
        OWLNamedClass cls = owlModel.getOWLNamedClass("Cls");
        OWLAllValuesFrom restriction = (OWLAllValuesFrom) cls.getRestrictions(false).iterator().next();
        RDFResource filler = restriction.getFiller();
        assertTrue(filler instanceof OWLDataRange);
        Collection values = ((OWLDataRange) filler).getOneOf().getValues();
        assertSize(2, values);
        assertContains("A", values);
        assertContains("B", values);
    }


    public void testLoadDataRange() throws Exception {
        RDFSLiteral[] values = {
            owlModel.createRDFSLiteral("A"),
            owlModel.createRDFSLiteral("B")
        };
        OWLDataRange dataRange = owlModel.createOWLDataRange(values);
        OWLDatatypeProperty property = owlModel.createOWLDatatypeProperty("property");
        property.setRange(dataRange);

        JenaOWLModel newModel = reloadWithJenaLoader(owlModel);
        OWLDatatypeProperty newProperty = newModel.getOWLDatatypeProperty(property.getName());
        OWLDataRange newDR = (OWLDataRange) newProperty.getRange();
        List newValues = newDR.getOneOfValueLiterals();
        assertSize(2, newValues);

        //Jena.dumpRDF(newModel.getOntModel());
        assertSize(0, newModel.getOWLThingClass().getInstances(false));
    }
}
