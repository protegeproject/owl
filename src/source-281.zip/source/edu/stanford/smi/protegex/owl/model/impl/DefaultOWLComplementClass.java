package edu.stanford.smi.protegex.owl.model.impl;

import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protegex.owl.model.OWLComplementClass;
import edu.stanford.smi.protegex.owl.model.OWLNames;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFSClass;
import edu.stanford.smi.protegex.owl.model.visitor.OWLModelVisitor;

import java.util.Collection;
import java.util.Collections;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultOWLComplementClass extends AbstractOWLLogicalClass
        implements OWLComplementClass {

    /**
     * The unicode operator symbol for this kind of class
     */
    public final static char OPERATOR = '\u00AC';


    public DefaultOWLComplementClass(KnowledgeBase kb, FrameID id) {
        super(kb, id);
    }


    public DefaultOWLComplementClass() {
    }


    public String getBrowserText() {
        RDFSClass complementClass = getComplement();
        return "" + OPERATOR + (complementClass == null ? "?" : complementClass.getNestedBrowserText());
    }


    public RDFSClass getComplement() {
        return (RDFSClass) getPropertyValue(getOperandsProperty());
    }


    public Collection getOperands() {
        RDFSClass complement = getComplement();
        if (complement == null) {
            return Collections.EMPTY_LIST;
        }
        else {
            return Collections.singleton(complement);
        }
    }


    public RDFProperty getOperandsProperty() {
        return getOWLModel().getRDFProperty(OWLNames.Slot.COMPLEMENT_OF);
    }


    public String getNestedBrowserText() {
        return getBrowserText();
    }


    public void setComplement(RDFSClass complement) {
        setOwnSlotValue(getOperandsProperty(), complement);
    }


    /**
     * Overloaded to throw an IllegalArgumentException if the number of operands is greater
     * than 1 (there can be only one complement).
     *
     * @param clses the complement class
     */
    public void setOperands(Collection clses) {
        if (clses != null && clses.size() > 1) {
            throw new IllegalArgumentException("Only one complement class allowed.");
        }
        setPropertyValues(getOperandsProperty(), clses);
    }


    public void accept(OWLModelVisitor visitor) {
        visitor.visitOWLComplementClass(this);
    }
}
