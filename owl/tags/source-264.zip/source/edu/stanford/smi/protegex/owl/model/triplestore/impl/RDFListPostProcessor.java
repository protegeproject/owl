package edu.stanford.smi.protegex.owl.model.triplestore.impl;

import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.RDFSNamedClass;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;

import java.util.Iterator;
import java.util.List;

/**
 * Makes sure that all frames that have a value for rdf:first also have at least one type.
 * This is needed to add the type rdf:List to those list instances which don't have an explicit
 * type triple.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class RDFListPostProcessor {

    public RDFListPostProcessor(OWLModel owlModel) {

        List tripleStores = owlModel.getTripleStoreModel().getTripleStores();
        for (Iterator it = tripleStores.iterator(); it.hasNext();) {
            TripleStore tripleStore = (TripleStore) it.next();
            process(owlModel, tripleStore);
        }
    }


    private void process(OWLModel owlModel, TripleStore tripleStore) {
        owlModel.getTripleStoreModel().setActiveTripleStore(tripleStore);
        RDFSNamedClass rdfListClass = owlModel.getRDFListClass();
        RDFProperty rdfFirstProperty = owlModel.getRDFFirstProperty();
        Iterator subjects = tripleStore.listSubjects(rdfFirstProperty);
        while (subjects.hasNext()) {
            RDFResource subject = (RDFResource) subjects.next();
            if (subject.getProtegeType() == null) {
                subject.addProtegeType(rdfListClass);
            }
        }
    }
}
