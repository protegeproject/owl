package edu.stanford.smi.protegex.owl.model;

/**
 * The common base interface for OWLNamedClass and OWLAnonymousClass.
 * This can be used in method declarations if only OWL classes are valid.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface OWLClass extends RDFSClass{
}
