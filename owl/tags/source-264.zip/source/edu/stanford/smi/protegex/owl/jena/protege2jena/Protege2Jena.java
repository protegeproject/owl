package edu.stanford.smi.protegex.owl.jena.protege2jena;

import com.hp.hpl.jena.datatypes.RDFDatatype;
import com.hp.hpl.jena.datatypes.xsd.impl.XMLLiteralType;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.rdf.model.RDFList;
import com.hp.hpl.jena.util.FileUtils;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;
import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protegex.owl.jena.Jena;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.impl.XMLSchemaDatatypes;
import edu.stanford.smi.protegex.owl.model.triplestore.Triple;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreModel;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URI;
import java.net.URL;
import java.util.*;

/**
 * An object that can convert an OWLModel into an OntModel.
 * This implementation uses the OWLModel's TripleStore and
 * creates corresponding Jena triples for each.
 * <p/>
 * When completed, this will replace the JenaCreator class.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class Protege2Jena {

    /**
     * A temporary Model which is used to create properties without having to define
     * them with the correct type each time
     */
    private Model dummyModel = ModelFactory.createDefaultModel();

    private Collection fillTripleStores;

    /**
     * The source OWLModel
     */
    private OWLModel owlModel;

    /**
     * The target OntModel
     */
    private OntModel ontModel;

    /**
     * A Map from TripleStores to Jena Models
     */
    private Map tripleStore2Model = new HashMap();

    private TripleStoreModel tripleStoreModel;


    private Protege2Jena(OWLModel owlModel, OntModel ontModel) {
        this(owlModel, ontModel, owlModel.getTripleStoreModel().getTripleStores());
    }


    private Protege2Jena(OWLModel owlModel, OntModel ontModel, Collection fillTripleStores) {

        this.fillTripleStores = fillTripleStores;
        this.owlModel = owlModel;
        this.ontModel = ontModel;
        this.tripleStoreModel = owlModel.getTripleStoreModel();

        // Create SubModels and put them into Map
        createSubModels();

        // Fill each SubModel
        fillModels();
    }


    private void copyTriples(TripleStore tripleStore, Model model) {
        Iterator it = tripleStore.listTriples();
        while (it.hasNext()) {
            Triple triple = (Triple) it.next();
            Statement stmt = createStatement(triple, model);
            model.add(stmt);
        }
    }


    public static OntModel createOntModel(OWLModel owlModel) {
        return createOntModel(owlModel, OntModelSpec.OWL_MEM, owlModel.getTripleStoreModel().getTripleStores());
    }


    public static OntModel createOntModel(OWLModel owlModel, Collection fillTripleStores) {
        return createOntModel(owlModel, OntModelSpec.OWL_MEM, fillTripleStores);
    }


    public static OntModel createOntModel(OWLModel owlModel, OntModelSpec spec, Collection fillTripleStores) {
        OntModel ontModel = (OntModel) ModelFactory.createOntologyModel(spec);
        new Protege2Jena(owlModel, ontModel, fillTripleStores);
        return ontModel;
    }


    private void createSubModels() {
        Iterator it = tripleStoreModel.listUserTripleStores();
        TripleStore baseTripleStore = (TripleStore) it.next();
        Model baseModel = ontModel.getBaseModel();
        tripleStore2Model.put(baseTripleStore, baseModel);
        while (it.hasNext()) {
            TripleStore tripleStore = (TripleStore) it.next();
            Model subModel = createSubModel(tripleStore);
            ontModel.addSubModel(subModel);
            tripleStore2Model.put(tripleStore, subModel);
        }
    }


    private Model createSubModel(TripleStore tripleStore) {
        return ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
    }


    private void createNamespacePrefixes(TripleStore tripleStore, Model model) {

        // Delete any existing namespace declarations
        for (Iterator it = model.getNsPrefixMap().keySet().iterator(); it.hasNext();) {
            String prefix = (String) it.next();
            model.removeNsPrefix(prefix);
        }

        // Copy prefixes from TripleStore into Model
        for (Iterator it = tripleStore.getPrefixes().iterator(); it.hasNext();) {
            String prefix = (String) it.next();
            String namespace = tripleStore.getNamespaceForPrefix(prefix);
            model.setNsPrefix(prefix, namespace);
        }
    }


    private Statement createStatement(Triple triple, Model model) {
        Resource subject = getResource(triple.getSubject(), model);
        Property predicate = getProperty(triple.getPredicate(), model);
        RDFNode object = getRDFNode(triple.getObject(), model);
        return model.createStatement(subject, predicate, object);
    }


    private void fillModels() {
        for (Iterator it = tripleStore2Model.keySet().iterator(); it.hasNext();) {
            TripleStore tripleStore = (TripleStore) it.next();
            if (fillTripleStores.contains(tripleStore)) {
                Model model = getModel(tripleStore);
                createNamespacePrefixes(tripleStore, model);
                copyTriples(tripleStore, model);
                removeRedundantRDFSDomains(model);
                removeRedundantRDFSSubClassOfOWLThings(model);
                removeRedundantRDFSSubClassOfEquivalentClasses(model);
                removeRedundantRDFLists(model);
            }
        }
    }


    private Model getModel(TripleStore tripleStore) {
        return (Model) tripleStore2Model.get(tripleStore);
    }


    protected Set getParseTypeCollectionProperties() {
        Set set = new HashSet();
        set.add(OWL.unionOf);
        set.add(OWL.intersectionOf);
        set.add(OWL.distinctMembers);
        set.add(OWL.oneOf);
        return set;
    }


    private Property getProperty(RDFProperty rdfProperty, Model model) {
        String uri = rdfProperty.getURI();
        Property property = dummyModel.getProperty(uri);
        if (property != null) {
            return property;
        }
        return dummyModel.createProperty(uri);
    }


    private RDFNode getRDFNode(Object object, Model model) {
        if (object instanceof RDFResource) {
            return getResource((RDFResource) object, model);
        }
        else if (object instanceof RDFSLiteral) {
            RDFSLiteral literal = (RDFSLiteral) object;
            String language = literal.getLanguage();
            if (language != null) {
                String value = literal.getString();
                return model.createLiteral(value, language);
            }
            else {
                RDFDatatype datatype = XMLSchemaDatatypes.getXSDDatatype(literal.getDatatype());
                if (datatype == null && owlModel.getRDFXMLLiteralType().equals(literal.getDatatype())) {
                    datatype = XMLLiteralType.theXMLLiteralType;
                }
                return model.createTypedLiteral(literal.getString(), datatype);
            }
        }
        else if (object instanceof RDFExternalResource) {
            String uri = ((RDFExternalResource) object).getResourceURI();
            return model.getResource(uri);
        }
        else {
            return model.createTypedLiteral(object);
        }
    }


    private Resource getResource(RDFResource rdfResource, Model model) {
        if (rdfResource.isAnonymous()) {
            AnonId anonId = new AnonId("_:" + rdfResource.getName());
            return model.createResource(anonId);
        }
        else {
            return model.getResource(rdfResource.getURI());
        }
    }


    /**
     * In several contexts, such as owl:unionOf operands, it is unusual to have
     * typed rdf:Lists.  Typeless rdf:Lists are written out as parseType="Collection".
     * This method detects these rdf:Lists and removes its rdf:type.
     *
     * @param model
     */
    private void removeRedundantRDFLists(Model model) {
        Set properties = getParseTypeCollectionProperties();
        for (Iterator it = properties.iterator(); it.hasNext();) {
            Property property = (Property) it.next();
            Iterator objects = model.listObjectsOfProperty(property);
            while (objects.hasNext()) {
                Object object = objects.next();
                if (object instanceof Resource && ((Resource) object).hasProperty(RDF.type, RDF.List)) {
                    removeRedundantRDFListsRecursively((Resource) object);
                }
            }
        }
    }


    private void removeRedundantRDFListsRecursively(Resource list) {
        if (!list.equals(RDF.nil)) {
            if (list.hasProperty(RDF.type, RDF.List)) {
                list.removeAll(RDF.type);
            }
            Statement statement = list.getProperty(RDF.rest);
            if (statement != null) {
                removeRedundantRDFListsRecursively((Resource) statement.getObject());
            }
        }
    }


    private void removeRedundantRDFSDomains(Model model) {
        Set subjects = Jena.set(model.listSubjectsWithProperty(RDFS.domain, OWL.Thing));
        for (Iterator it = subjects.iterator(); it.hasNext();) {
            Resource resource = (Resource) it.next();
            Iterator vit = resource.listProperties(RDFS.domain);
            vit.next();
            if (!vit.hasNext()) {  // owl:Thing is the only domain
                resource.removeAll(RDFS.domain);
            }
        }
    }


    private void removeRedundantRDFSSubClassOfOWLThings(Model model) {
        Set subjects = Jena.set(model.listSubjectsWithProperty(RDFS.subClassOf, OWL.Thing));
        for (Iterator it = subjects.iterator(); it.hasNext();) {
            Resource resource = (Resource) it.next();
            Iterator vit = resource.listProperties(RDFS.subClassOf);
            vit.next();
            if (!vit.hasNext()) {  // owl:Thing is the only superclass
                resource.removeAll(RDFS.subClassOf);
            }
        }
    }


    private void removeRedundantRDFSSubClassOfEquivalentClasses(Model model) {
        Iterator classes = model.listSubjectsWithProperty(OWL.equivalentClass);
        while (classes.hasNext()) {
            Resource ontClass = (Resource) classes.next();
            Iterator equis = Jena.cloneIt(ontClass.listProperties(OWL.equivalentClass));
            while (equis.hasNext()) {
                Resource equi = (Resource) ((Statement) equis.next()).getObject();
                if (model.contains(equi, OWL.intersectionOf)) {
                    RDFNode operandsListNode = model.listObjectsOfProperty(equi, OWL.intersectionOf).nextNode();
                    if (operandsListNode.canAs(RDFList.class)) {
                        RDFList operandsList = (RDFList) operandsListNode.as(RDFList.class);
                        Iterator operands = operandsList.iterator();
                        while (operands.hasNext()) {
                            Resource operand = (Resource) operands.next();
                            if (!operand.isAnon()) {
                                model.removeAll(ontClass, RDFS.subClassOf, operand);
                            }
                        }
                    }
                }
            }
        }
    }


    public static void saveAll(OWLModel owlModel, URI uri) throws Exception {
        final String language = FileUtils.langXMLAbbrev;
        saveAll(owlModel, uri, language);
    }


    public static void saveAll(OWLModel owlModel, URI uri, String language) throws Exception {
        List fillTripleStores = new ArrayList();
        Iterator ts = owlModel.getTripleStoreModel().listUserTripleStores();
        fillTripleStores.add(ts.next());
        while (ts.hasNext()) {
            TripleStore tripleStore = (TripleStore) ts.next();
            String name = tripleStore.getName();
            URI logicalURI = new URI(name);
            if (owlModel.getURIResolver().isEditableImport(logicalURI)) {
                URL physicalURL = owlModel.getURIResolver().getPhysicalURL(logicalURI);
                if (physicalURL.toString().startsWith("file:")) {
                    fillTripleStores.add(tripleStore);
                }
                else {
                    System.err.println("Warning: Cannot save import " + name + " because physical URL is not a file");
                    System.err.println("  (Physical URL is " + physicalURL + ")");
                }
            }
        }
        OntModel ontModel = createOntModel(owlModel, fillTripleStores);

        File file = new File(uri);
        String namespace = owlModel.getNamespaceManager().getDefaultNamespace();
        System.out.println("Saving " + file);
        JenaOWLModel.save(file, ontModel, language, namespace);
        Iterator tripleStores = owlModel.getTripleStoreModel().listUserTripleStores();
        tripleStores.next();
        Iterator graphs = ontModel.listImportedModels();
        while (tripleStores.hasNext()) {
            TripleStore tripleStore = (TripleStore) tripleStores.next();
            Model model = (Model) graphs.next();
            if (fillTripleStores.contains(tripleStore)) {
                String name = tripleStore.getName();
                URI logicalURI = new URI(name);
                URL physicalURL = owlModel.getURIResolver().getPhysicalURL(logicalURI);
                Instance ontology = TripleStoreUtil.getFirstOntology(owlModel, tripleStore);
                String defaultNamespace = getDefaultNamespace(ontology);
                System.out.println("Saving import " + name + " to " + physicalURL);
                final String fileString = physicalURL.getFile();
                file = new File(fileString);
                FileOutputStream fos = new FileOutputStream(file);
                JenaOWLModel.saveModel(fos, model, language, defaultNamespace);
            }
        }
        System.out.println("... saving successful.");
    }


    private static String getDefaultNamespace(Instance ontology) {
        Slot slot = ontology.getKnowledgeBase().getSlot(OWLNames.Slot.ONTOLOGY_PREFIXES);
        Collection values = ontology.getDirectOwnSlotValues(slot);
        for (Iterator it = values.iterator(); it.hasNext();) {
            String value = (String) it.next();
            if (value.startsWith(":")) {
                return value.substring(1);
            }
        }
        return "http://dummy.com/ontology#";
    }
}
