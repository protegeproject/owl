package edu.stanford.smi.protegex.owl.database.triplestore;

import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.model.framestore.MergingNarrowFrameStore;
import edu.stanford.smi.protege.model.framestore.NarrowFrameStore;
import edu.stanford.smi.protegex.owl.database.OWLDatabaseModel;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreModel;
import edu.stanford.smi.protegex.owl.model.triplestore.impl.TripleChangePostProcessor;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DatabaseTripleStoreModel implements TripleStoreModel {

    private OWLDatabaseModel owlModel;

    private DatabaseTripleStore ts;


    public DatabaseTripleStoreModel(OWLDatabaseModel owlModel) {
        this.owlModel = owlModel;
        MergingNarrowFrameStore mnfs = MergingNarrowFrameStore.get(owlModel);
        NarrowFrameStore frameStore = mnfs.getActiveFrameStore();
        ts = new DatabaseTripleStore(owlModel, this, frameStore);
    }


    public TripleStore createTripleStore(String name) {
        return ts;
    }


    public void deleteTripleStore(TripleStore tripleStore) {
    }


    public void endTripleStoreChanges() {
        owlModel.flushCache();
        owlModel.updateProtegeMetaOntologyImported();
        TripleChangePostProcessor.postProcess(owlModel);
    }


    public TripleStore getActiveTripleStore() {
        return ts;
    }


    public TripleStore getHomeTripleStore(RDFResource resource) {
        return ts;
    }


    public Collection getPropertyValues(RDFResource resource, RDFProperty property) {
        return ts.getSlotValues(resource, property);
    }


    public Collection getSlotValues(Instance instance, Slot slot) {
        return ts.getSlotValues(instance, slot);
    }


    public TripleStore getTripleStore(String name) {
        return ts;
    }


    public List getTripleStores() {
        return Collections.singletonList(ts);
    }


    public TripleStore getTopTripleStore() {
        return ts;
    }


    public boolean isActiveTriple(RDFResource subject, RDFProperty predicate, Object object) {
        return true;
    }


    public boolean isEditableTriple(RDFResource subject, RDFProperty predicate, Object object) {
        return true;
    }


    public boolean isEditableTripleStore(TripleStore ts) {
        return true;
    }


    public Iterator listUserTripleStores() {
        return Collections.singleton(ts).iterator();
    }


    public void replaceJavaObject(RDFResource subject) {
        // Not needed ?
    }


    public void setActiveTripleStore(TripleStore tripleStore) {
    }


    public void setHomeTripleStore(RDFResource resource, TripleStore tripleStore) {
    }


    public void updateEditableResourceState() {
    }
}
