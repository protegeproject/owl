package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.model.OWLProperty;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadFunctionalPropertyTestCase extends AbstractJenaTestCase {

    public void testLoadFunctionalAnnotationProperty() throws Exception {
        loadRemoteOntology("functional.owl");
        OWLProperty property = owlModel.getOWLProperty("functionalAnnotationProperty");
        assertTrue(property.isAnnotationProperty());
        assertTrue(property.isFunctional());
    }


    public void testLoadFunctionalDatatypeProperty() throws Exception {
        loadRemoteOntology("functional.owl");
        OWLProperty property = owlModel.getOWLProperty("functionalProperty");
        assertFalse(property.isAnnotationProperty());
        assertTrue(property.isFunctional());
    }
}
