package edu.stanford.smi.protegex.owl.inference.dig.reasoner;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * User: matthewhorridge<br>
 * The Univeristy Of Manchester<br>
 * Medical Informatics Group<br>
 * Date: Jun 3, 2004<br><br>
 * <p/>
 * matthew.horridge@cs.man.ac.uk<br>
 * www.cs.man.ac.uk/~horridgm<br><br>
 */
public class DefaultDIGReasonerConnection implements DIGReasonerConnection {

    private String reasonerURL = "http://localhost:8080";

    private URL url;

    private HttpURLConnection conn;


    /**
     * Specifies the location of the inference in
     * terms of the inference URL.
     *
     * @param reasonerURL The <code>URL</code>
     */
    public void setReasonerURL(String reasonerURL) {
        this.reasonerURL = reasonerURL;
    }


    /**
     * Gets the URL that points to the location
     * of the DIG Reasoner.
     */
    public String getReasonerURL() {
        return reasonerURL;
    }


    /**
     * Creates a HTTP Connection to the reasoner
     *
     * @throws IOException
     */
    protected void connectToReasoner() throws IOException {
        url = new URL(reasonerURL);

        conn = (HttpURLConnection) url.openConnection();

        conn.setRequestProperty("Content-Type", "text/xml");

        conn.setRequestMethod("POST");

        conn.setDoInput(true);

        conn.setDoOutput(true);
    }


    /**
     * Sends a request to the reasoner
     */
    public void send(StringWriter writer) throws IOException {
        connectToReasoner();

        StringBuffer request = writer.getBuffer();

        // Set the length of the request
        conn.setRequestProperty("Content-Length", "" + request.length());

        conn.setRequestMethod("POST");

        // Make the connection
        conn.connect();

        OutputStream os = conn.getOutputStream();

        OutputStreamWriter osw = new OutputStreamWriter(os);

        osw.write(request.toString());

        osw.flush();

        osw.close();

        // Close the connection
        conn.disconnect();
    }


    /**
     * Obtains an input stream which can be
     * used to get the reasoner response
     */
    public Reader receive() throws IOException {
        conn.connect();

        return new InputStreamReader(conn.getInputStream());
    }


    /**
     * May be used to close the reasoner connection
     * after a read has finished.
     *
     * @throws java.io.IOException
     */
    public void closeConnection() throws IOException {
        conn.disconnect();
    }
}


