package edu.stanford.smi.protegex.owl.model.impl;

import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.ValueType;
import edu.stanford.smi.protegex.owl.model.RDFSDatatype;
import edu.stanford.smi.protegex.owl.model.visitor.OWLModelVisitor;
import edu.stanford.smi.protegex.owl.ui.icons.OWLIcons;

import javax.swing.*;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultRDFSDatatype extends DefaultRDFIndividual implements RDFSDatatype {

    public DefaultRDFSDatatype(KnowledgeBase kb, FrameID id) {
        super(kb, id);
    }


    public DefaultRDFSDatatype() {
    }


    public Object getDefaultValue() {
        // TODO: Return RDFSLiteral if this is not a default type
        ValueType valueType = XMLSchemaDatatypes.getValueType(getURI());
        if (valueType == ValueType.BOOLEAN) {
            return Boolean.FALSE;
        }
        else if (valueType == ValueType.INTEGER) {
            return new Integer(0);
        }
        else if (valueType == ValueType.FLOAT) {
            return new Float(0);
        }
        else if (valueType == ValueType.STRING) {
            return "";
        }
        else {
            return null;
        }
    }


    public Icon getIcon() {
        return isEditable() ?
                OWLIcons.getImageIcon(OWLIcons.RDF_DATATYPE) :
                OWLIcons.getReadOnlyIndividualIcon(OWLIcons.getImageIcon(OWLIcons.RDF_DATATYPE));
    }


    public void accept(OWLModelVisitor visitor) {
        visitor.visitRDFDatatype(this);
    }
}
