package edu.stanford.smi.protegex.owl.jena.triplestore;

import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Model;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.model.framestore.InMemoryFrameDb;
import edu.stanford.smi.protege.model.framestore.MergingNarrowFrameStore;
import edu.stanford.smi.protege.model.framestore.NarrowFrameStore;
import edu.stanford.smi.protegex.owl.jena.JenaOWLModel;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.factory.OWLJavaFactoryUpdater;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreModel;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStoreUtil;
import edu.stanford.smi.protegex.owl.model.triplestore.impl.TripleChangePostProcessor;

import java.net.URI;
import java.util.*;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class JenaTripleStoreModel implements TripleStoreModel {

    private JenaOWLModel owlModel;

    private MergingNarrowFrameStore mnfs;

    private Slot nameSlot;

    private List ts = new ArrayList();


    public JenaTripleStoreModel(JenaOWLModel owlModel) {
        this.owlModel = owlModel;
        this.nameSlot = owlModel.getSlot(Model.Slot.NAME);
        mnfs = MergingNarrowFrameStore.get(owlModel);
        initTripleStores();
    }


    public TripleStore createTripleStore(String name) {
        NarrowFrameStore frameStore = new InMemoryFrameDb(name);
        String parentName = getActiveTripleStore().getName();
        mnfs.addActiveChildFrameStore(frameStore, parentName);
        TripleStore tripleStore = new JenaTripleStore(owlModel, frameStore, this);
        ts.add(tripleStore);
        updateRemoveFrameStores();
        return tripleStore;
    }


    public void deleteTripleStore(TripleStore tripleStore) {
        ts.remove(tripleStore);
        // TODO! mnfs.delete(tripleStore.getNarrowFrameStore());
    }


    public void endTripleStoreChanges() {
        owlModel.flushCache();
        final Collection resources = owlModel.getRDFResources();
        for (Iterator it = resources.iterator(); it.hasNext();) {
            RDFResource resource = (RDFResource) it.next();
            if (resource.isSystem()) {
                it.remove();
            }
        }
        OWLJavaFactoryUpdater.run(owlModel, resources);
        owlModel.updateProtegeMetaOntologyImported();
        TripleChangePostProcessor.postProcess(owlModel);
        owlModel.flushCache();
    }


    public static void ensureActiveTripleStore(RDFResource resource) {
        TripleStoreUtil.ensureActiveTripleStore(resource);
    }


    public TripleStore getActiveTripleStore() {
        NarrowFrameStore activeFrameStore = mnfs.getActiveFrameStore();
        String name = activeFrameStore.getName();
        return getTripleStore(name);
    }


    public TripleStore getHomeTripleStore(RDFResource resource) {
        Slot nameSlot = ((KnowledgeBase) owlModel).getSlot(Model.Slot.NAME);
        for (Iterator it = ts.iterator(); it.hasNext();) {
            JenaTripleStore tripleStore = (JenaTripleStore) it.next();
            if (tripleStore.getNarrowFrameStore().getValuesCount(resource, nameSlot, null, false) > 0) {
                return tripleStore;
            }
        }
        return null;
    }


    public Collection getPropertyValues(RDFResource resource, RDFProperty property) {
        Collection values = mnfs.getValues(resource, property, null, false);
        return owlModel.getOWLFrameStore().getConvertedValues(values);
    }


    public Collection getSlotValues(Instance instance, Slot slot) {
        return mnfs.getValues(instance, slot, null, false);
    }


    public TripleStore getTripleStore(String name) {
        for (Iterator it = ts.iterator(); it.hasNext();) {
            TripleStore tripleStore = (TripleStore) it.next();
            if (name.equals(tripleStore.getName())) {
                return tripleStore;
            }
        }
        return null;
    }


    public TripleStore getTripleStore(int index) {
        return (TripleStore) getTripleStores().get(index);
    }


    public List getTripleStores() {
        return new ArrayList(ts);
    }


    public TripleStore getTopTripleStore() {
        return (TripleStore) ts.get(1);
    }


    public boolean isActiveTriple(RDFResource subject, RDFProperty predicate, Object object) {
        return getActiveTripleStore().contains(subject, predicate, object);
    }


    public boolean isEditableTriple(RDFResource subject, RDFProperty predicate, Object object) {
        Iterator it = listUserTripleStores();
        while (it.hasNext()) {
            TripleStore ts = (TripleStore) it.next();
            if (ts.contains(subject, predicate, object)) {
                return isEditableTripleStore(ts);
            }
        }
        return false;
    }


    public boolean isEditableTripleStore(TripleStore tripleStore) {
        int index = ts.indexOf(tripleStore);
        if (index == 0) {
            return false;
        }
        if (index == 1) {
            return true;
        }
        try {
            URI uri = new URI(tripleStore.getName());
            return owlModel.getURIResolver().isEditableImport(uri);
        }
        catch (Exception ex) {
        }
        return false;
    }


    public Iterator listUserTripleStores() {
        Iterator it = getTripleStores().iterator();
        it.next();
        return it;
    }


    private void initTripleStores() {
        ts = new ArrayList();
        NarrowFrameStore[] ss = (NarrowFrameStore[]) mnfs.getAvailableFrameStores().toArray(new NarrowFrameStore[0]);
        for (int i = 0; i < ss.length; i++) {
            NarrowFrameStore s = ss[i];
            ts.add(new JenaTripleStore(owlModel, s, this));
        }
        updateRemoveFrameStores();
    }


    public void replaceJavaObject(RDFResource subject) {
        mnfs.replaceFrame(subject);
    }


    public void setActiveTripleStore(TripleStore tripleStore) {
        if (mnfs.getActiveFrameStore() != tripleStore.getNarrowFrameStore()) {
            mnfs.setActiveFrameStore(tripleStore.getNarrowFrameStore());
        }
    }


    public void setHomeTripleStore(RDFResource resource, TripleStore tripleStore) {
        JenaTripleStore home = (JenaTripleStore) getHomeTripleStore(resource);
        if (home != tripleStore) {
            List values = mnfs.getValues(resource, nameSlot, null, false);
            String name = (String) values.get(0);
            home.getNarrowFrameStore().removeValue(resource, nameSlot, null, false, name);
            tripleStore.getNarrowFrameStore().addValues(resource, nameSlot, null, false, Collections.singleton(name));
        }
    }


    public void updateEditableResourceState() {
        Slot nameSlot = owlModel.getSlot(Model.Slot.NAME);
        TripleStoreUtil.updateFrameInclusion(mnfs, nameSlot);
    }


    private void updateRemoveFrameStores() {
        Collection allFrameStores = mnfs.getAvailableFrameStores();
        mnfs.setRemoveFrameStores(allFrameStores);
    }
}
