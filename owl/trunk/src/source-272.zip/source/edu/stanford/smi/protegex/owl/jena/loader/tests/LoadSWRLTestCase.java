package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protege.model.Instance;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.OWLNames;
import edu.stanford.smi.protegex.owl.model.OWLObjectProperty;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.net.URI;
import java.util.List;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadSWRLTestCase extends AbstractJenaTestCase {

    public void testLoadSWRL() throws Exception {
        loadTestOntologyWithJenaLoader(new URI("http://www.daml.org/2004/04/swrl/swrl.owl"));
        RDFProperty argument2Property = (RDFProperty) owlModel.getSlot("swrl:argument2");
        assertNotNull(argument2Property);
        assertNull(argument2Property.getRange());
        OWLNamedClass datavaluedPropertyAtomCls = (OWLNamedClass) owlModel.getCls("swrl:DatavaluedPropertyAtom");
        assertNotNull(datavaluedPropertyAtomCls);
        //assertEquals(ValueType.ANY, datavaluedPropertyAtomCls.getTemplateSlotValueType(argument2Property));

        OWLNamedClass dataRangeAtomCls = (OWLNamedClass) owlModel.getCls("swrl:DataRangeAtom");
        assertNotNull(dataRangeAtomCls);

        OWLObjectProperty dataRangeSlot = owlModel.getOWLObjectProperty("swrl:dataRange");
        assertNotNull(dataRangeSlot);

        //Collection clses = dataRangeAtomCls.getTemplateSlotAllowedClses(dataRangeSlot);
        //assertSize(1, clses);
        //assertContains(okb.getCls(OWLNames.Cls.DATA_RANGE), clses);
    }


    public void testLoadSWRLDataRangeAtom() throws Exception {

        loadRemoteOntologyWithJenaLoader("SWRLDataRange.owl");

        Instance dataRange = owlModel.getInstance("MyDataRange");
        Slot oneOfSlot = owlModel.getSlot(OWLNames.Slot.ONE_OF);
        final List values = dataRange.getDirectOwnSlotValues(oneOfSlot);
        assertSize(2, values);
        assertContains("10", values);
        assertContains("15", values);
    }
}
