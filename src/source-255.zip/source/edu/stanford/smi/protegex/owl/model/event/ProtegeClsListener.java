package edu.stanford.smi.protegex.owl.model.event;

import edu.stanford.smi.protege.event.ClsListener;
import edu.stanford.smi.protege.event.ClsEvent;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface ProtegeClsListener extends ClsListener {

    /**
     * @deprecated
     * @see ClassListener#instanceAdded
     */
    void directInstanceAdded(ClsEvent event);

    /**
     * @deprecated
     * @see ClassListener#instanceRemoved
     */
    void directInstanceRemoved(ClsEvent event);


    /**
     * @deprecated
     * @see ClassListener#subclassAdded
     */
    void directSubclassAdded(ClsEvent event);

    /**
     * @deprecated not supported by OWL
     */
    void directSubclassMoved(ClsEvent event);

    /**
     * @deprecated
     * @see ClassListener#subclassRemoved
     */
    void directSubclassRemoved(ClsEvent event);

    /**
     * @deprecated
     * @see ClassListener#superclassAdded
     */
    void directSuperclassAdded(ClsEvent event);

    /**
     * @deprecated
     * @see ClassListener#subclassRemoved
     */
    void directSuperclassRemoved(ClsEvent event);

    /**
     * @deprecated no OWL equivalent
     */
    void templateFacetAdded(ClsEvent event);

    /**
     * @deprecated no OWL equivalent
     */
    void templateFacetRemoved(ClsEvent event);

    /**
     * @deprecated no OWL equivalent
     */
    void templateFacetValueChanged(ClsEvent event);

    /**
     * @deprecated
     * @see ClassListener#addedToUnionDomainOf
     */
    void templateSlotAdded(ClsEvent event);

    /**
     * @deprecated
     * @see ClassListener#removedFromUnionDomainOf
     */
    void templateSlotRemoved(ClsEvent event);

    /**
     * @deprecated no OWL equivalent
     */
    void templateSlotValueChanged(ClsEvent event);
}
