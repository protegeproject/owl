package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Model;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

import java.util.Collection;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadDomainTestCase extends AbstractJenaTestCase {

    public void testLoadUnionDomain() throws Exception {
        loadRemoteOntology("union-domain.owl");
        Cls personCls = owlModel.getCls("Person");
        Cls corporationCls = owlModel.getCls("Corporation");
        Slot slot = owlModel.getSlot("hasBankAccount");
        Collection domain = slot.getDirectDomain();
        assertEquals(2, domain.size());
        assertTrue(domain.contains(personCls));
        assertTrue(domain.contains(corporationCls));
    }


    public void testLoadInheritedDomain() throws Exception {
        loadRemoteOntology("inheritedDomain.owl");
        Slot subProperty = owlModel.getOWLProperty("subSlot");
        assertNull(subProperty.getDirectOwnSlotValue(owlModel.getSlot(Model.Slot.DIRECT_DOMAIN)));
    }
}
