package edu.stanford.smi.protegex.owl.model.impl;

import edu.stanford.smi.protegex.owl.model.NamespaceManager;
import edu.stanford.smi.protegex.owl.model.NamespaceManagerListener;
import edu.stanford.smi.protegex.owl.model.OWLModel;

import java.util.ArrayList;
import java.util.Collection;

/**
 * An abstract implementation of basic services for NamespaceManagers.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public abstract class AbstractNamespaceManager implements NamespaceManager {

    private Collection listeners = new ArrayList();

    protected OWLModel owlModel;


    public void addNamespaceManagerListener(NamespaceManagerListener listener) {
        listeners.add(listener);
    }


    public void init(OWLModel okb) {
        this.owlModel = okb;
    }


    protected Collection getListeners() {
        return new ArrayList(listeners);
    }


    public void removeNamespaceManagerListener(NamespaceManagerListener listener) {
        listeners.remove(listener);
    }
}
