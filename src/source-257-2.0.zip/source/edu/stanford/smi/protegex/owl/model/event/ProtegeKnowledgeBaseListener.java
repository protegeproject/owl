package edu.stanford.smi.protegex.owl.model.event;

import edu.stanford.smi.protege.event.KnowledgeBaseListener;
import edu.stanford.smi.protege.event.KnowledgeBaseEvent;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface ProtegeKnowledgeBaseListener extends KnowledgeBaseListener {

    /**
     * @deprecated
     * @see ModelListener#classCreated
     */
    void clsCreated(KnowledgeBaseEvent event);

    /**
     * @deprecated
     * @see ModelListener#classDeleted
     */
    void clsDeleted(KnowledgeBaseEvent event);

    /**
     * @deprecated not needed
     */
    void defaultClsMetaClsChanged(KnowledgeBaseEvent event);

    /**
     * @deprecated not needed
     */
    void defaultFacetMetaClsChanged(KnowledgeBaseEvent event);

    /**
     * @deprecated not needed
     */
    void defaultSlotMetaClsChanged(KnowledgeBaseEvent event);

    /**
     * @deprecated not needed
     */
    void facetCreated(KnowledgeBaseEvent event);

    /**
     * @deprecated not needed
     */
    void facetDeleted(KnowledgeBaseEvent event);

    /**
     * @deprecated
     * @see ModelListener#resourceNameChanged
     */
    void frameNameChanged(KnowledgeBaseEvent event);

    /**
     * @deprecated
     * @see ModelListener#individualCreated
     */
    void instanceCreated(KnowledgeBaseEvent event);


    /**
     * @deprecated
     * @see ModelListener#individualDeleted
     */
    void instanceDeleted(KnowledgeBaseEvent event);

    /**
     * @deprecated
     * @see ModelListener#propertyCreated
     */
    void slotCreated(KnowledgeBaseEvent event);


    /**
     * @deprecated
     * @see ModelListener#propertyDeleted
     */
    void slotDeleted(KnowledgeBaseEvent event);
}
