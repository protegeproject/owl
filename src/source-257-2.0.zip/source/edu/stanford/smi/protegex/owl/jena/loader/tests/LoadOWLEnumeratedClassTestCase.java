package edu.stanford.smi.protegex.owl.jena.loader.tests;

import edu.stanford.smi.protegex.owl.model.OWLEnumeratedClass;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.OWLObjectProperty;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadOWLEnumeratedClassTestCase extends AbstractJenaTestCase {

    public void testLoadEnumerationWithClass() throws Exception {
        loadRemoteOntology("enum-with-class.owl");
        OWLNamedClass cls = owlModel.getOWLNamedClass("Cls");
        OWLNamedClass enumCls = owlModel.getOWLNamedClass("Enum");
        OWLObjectProperty property = owlModel.getOWLObjectProperty("slot");
        assertNotNull(cls);
        assertNotNull(enumCls);
        assertNotNull(property);
        OWLEnumeratedClass e = (OWLEnumeratedClass) enumCls.getDefinition();
        assertSize(2, e.getOneOf());
        assertContains(cls, e.getOneOf());
        assertContains(property, e.getOneOf());
    }
}
