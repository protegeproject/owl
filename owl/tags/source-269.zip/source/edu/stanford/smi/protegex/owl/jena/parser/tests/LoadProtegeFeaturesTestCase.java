package edu.stanford.smi.protegex.owl.jena.parser.tests;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Model;
import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.OWLOntology;
import edu.stanford.smi.protegex.owl.model.RDFProperty;
import edu.stanford.smi.protegex.owl.model.RDFResource;
import edu.stanford.smi.protegex.owl.model.triplestore.TripleStore;

import java.util.Collection;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class LoadProtegeFeaturesTestCase extends AbstractProtegeOWLParserTestCase {

    public void testLoadAbstractFlag() throws Exception {
        loadRemoteOntology("abstractClass.owl");
        RDFProperty abstractProperty = owlModel.getRDFProperty("protege:abstract");
        assertNotNull(abstractProperty);
        TripleStore homeTripleStore = owlModel.getTripleStoreModel().getHomeTripleStore(abstractProperty);
        Object protegeTripleStore = owlModel.getTripleStoreModel().getTripleStores().get(2);
        assertEquals(protegeTripleStore, homeTripleStore);
        OWLNamedClass cls = owlModel.getOWLNamedClass("Cls");
        Object propertyValue = cls.getPropertyValue(abstractProperty);
        assertEquals(Boolean.TRUE, propertyValue);
        assertTrue(((Cls) cls).isAbstract());
        OWLOntology ontology = owlModel.getDefaultOWLOntology();
        Collection imps = ontology.getImports();
        assertSize(1, imps);
        Collection irs = ontology.getImportResources();
        assertSize(1, irs);
    }


    public void testLoadFromTo() throws Exception {
        loadRemoteOntology("ProtegeFromTo.owl");
        RDFProperty fromProperty = owlModel.getRDFProperty(Model.Slot.FROM);
        assertNotNull(fromProperty);
        RDFProperty toProperty = owlModel.getRDFProperty(Model.Slot.TO);
        assertNotNull(toProperty);
        RDFResource relation = owlModel.getRDFResource("relation");
        assertNotNull(relation);
        assertSize(1, relation.getPropertyValues(fromProperty));
        assertSize(1, relation.getPropertyValues(toProperty));
    }
}
