package edu.stanford.smi.protegex.owl.compactparser.tests;

import edu.stanford.smi.protegex.owl.compactparser.OWLCompactParser;
import edu.stanford.smi.protegex.owl.compactparser.ParseException;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.tests.AbstractJenaTestCase;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class ParseQuantifierRestrictionsTestCase extends AbstractJenaTestCase {

    public void testParseOWLAllValuesFromWithOWLDatatypeProperty() throws Exception {
        RDFProperty property = owlModel.createOWLDatatypeProperty("property");
        RDFSClass result = OWLCompactParser.parseCls(owlModel, "* property xsd:double");
        assertTrue(result instanceof OWLAllValuesFrom);
        OWLAllValuesFrom allValuesFrom = (OWLAllValuesFrom) result;
        assertEquals(property, allValuesFrom.getOnProperty());
        assertEquals(owlModel.getXSDdouble(), allValuesFrom.getAllValuesFrom());
        try {
            OWLCompactParser.parseCls(owlModel, "* property xsd:dou");
            assertTrue(false);
        }
        catch (ParseException ex) {
        }
    }


    public void testFailParseRestrictionsWithDatatypeSlot() {
        owlModel.createOWLDatatypeProperty("children", owlModel.getXSDstring());
        owlModel.createOWLNamedClass("RichPerson");
        try {
            OWLCompactParser.parseCls(owlModel, "* children RichPerson");
            assertTrue("Expected parser to fail", false);
        }
        catch (Exception ex) {
            // Ok. Expected
        }
        try {
            OWLCompactParser.parseCls(owlModel, "? children RichPerson");
            assertTrue("Expected parser to fail", false);
        }
        catch (Exception ex) {
            // Ok. Expected
        }
    }


    public void testFailParseRestrictionsWithObjectSlot() {
        owlModel.createOWLObjectProperty("slot");
        try {
            OWLCompactParser.parseCls(owlModel, "* slot xsd:int");
            assertTrue("Expected parser to fail", false);
        }
        catch (Exception ex) {
            // Ok. Expected
        }
        try {
            OWLCompactParser.parseCls(owlModel, "? slot xsd:int");
            assertTrue("Expected parser to fail", false);
        }
        catch (Exception ex) {
            // Ok. Expected
        }
    }


    public void testParseAllRestriction() throws Exception {
        owlModel.createOWLObjectProperty("children");
        owlModel.createOWLNamedClass("RichPerson");
        String expression = "* children RichPerson";
        RDFSClass aClass = OWLCompactParser.parseCls(owlModel, expression);
        assertTrue(aClass instanceof OWLAllValuesFrom);
        OWLAllValuesFrom restriction = (OWLAllValuesFrom) aClass;
        assertTrue(restriction.isDefined());
        assertTrue(restriction.getOnProperty().getName().equals("children"));
        assertTrue(restriction.getFiller().getName().equals("RichPerson"));
    }


    public void testParseAllRestrictionDataType() throws Exception {
        owlModel.createOWLDatatypeProperty("property", owlModel.getXSDstring());
        String expression = "* property xsd:int";
        RDFSClass aClass = OWLCompactParser.parseCls(owlModel, expression);
        assertTrue(aClass instanceof OWLAllValuesFrom);
        OWLAllValuesFrom restriction = (OWLAllValuesFrom) aClass;
        assertTrue(restriction.isDefined());
        assertTrue(restriction.getOnProperty().getName().equals("property"));
        assertEquals(restriction.getFiller(), owlModel.getXSDint());
    }


    public void testParseSomeValuesFromWithNamedClass() throws Exception {
        owlModel.createOWLNamedClass("RichPerson");
        owlModel.createOWLObjectProperty("children");
        String expression = "? children RichPerson";
        RDFSClass aClass = OWLCompactParser.parseCls(owlModel, expression);
        assertTrue(aClass instanceof OWLSomeValuesFrom);
        OWLSomeValuesFrom restriction = (OWLSomeValuesFrom) aClass;
        assertTrue(restriction.isDefined());
        assertTrue(restriction.getOnProperty().getName().equals("children"));
        assertTrue(restriction.getFiller().getName().equals("RichPerson"));
    }


    public void testParseSomeValuesFromWithAnonymousClass() throws Exception {
        owlModel.createOWLNamedClass("RichPerson");
        owlModel.createOWLObjectProperty("children");
        String expression = "? children !RichPerson";
        OWLCompactParser.checkClass(owlModel, expression);
        RDFSClass aClass = OWLCompactParser.parseCls(owlModel, expression);
        assertTrue(aClass instanceof OWLSomeValuesFrom);
        OWLSomeValuesFrom restriction = (OWLSomeValuesFrom) aClass;
        assertTrue(restriction.isDefined());
        assertTrue(restriction.getOnProperty().getName().equals("children"));
        assertTrue(restriction.getFiller() instanceof OWLComplementClass);
    }
}
