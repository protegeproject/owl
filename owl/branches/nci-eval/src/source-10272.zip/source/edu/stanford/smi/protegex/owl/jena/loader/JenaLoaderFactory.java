package edu.stanford.smi.protegex.owl.jena.loader;

import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.ontology.OntModelSpec;
import edu.stanford.smi.protege.model.Project;

/**
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface JenaLoaderFactory {

    OntModel createOntModel(OntModelSpec spec);


    OntModelSpec getOntModelSpec(Project project);
}
