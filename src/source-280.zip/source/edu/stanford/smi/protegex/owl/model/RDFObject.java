package edu.stanford.smi.protegex.owl.model;

/**
 * The common type of RDFSLiteral and RDFResource.
 * This can be used to ensure type safety for variables and method parameters.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface RDFObject {

    String getBrowserText();
}
