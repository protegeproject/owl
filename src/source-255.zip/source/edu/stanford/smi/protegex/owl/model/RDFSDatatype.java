package edu.stanford.smi.protegex.owl.model;

/**
 * An RDF resource representing an XML Schema datatype.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public interface RDFSDatatype extends RDFResource {

    /**
     * Creates a default value for this datatype (e.g. Integer(0) for xsd:int).
     *
     * @return a default value
     */
    Object getDefaultValue();
}
