package edu.stanford.smi.protegex.owl.model.impl;

import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.model.FrameID;
import edu.stanford.smi.protege.model.KnowledgeBase;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protegex.owl.compactparser.OWLCompactParser;
import edu.stanford.smi.protegex.owl.compactparser.ParseException;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.model.visitor.OWLModelVisitor;

import java.util.Set;

/**
 * A Cls representing a hasValue restriction.
 *
 * @author Holger Knublauch  <holger@smi.stanford.edu>
 */
public class DefaultOWLHasValue extends AbstractOWLRestriction
        implements OWLHasValue {

    /**
     * The unicode operator symbol for this kind of restriction
     */
    public final static char OPERATOR = '\u220B';


    public DefaultOWLHasValue(KnowledgeBase kb, FrameID id) {
        super(kb, id);
    }


    public DefaultOWLHasValue() {
    }


    public void checkFillerText(String text) throws Exception {
        checkFillerText(text, getOnProperty());
    }


    public static void checkFillerText(String text, Slot slot) throws ParseException {
        if (slot != null) {
            OWLModel kb = (OWLModel) slot.getKnowledgeBase();
            OWLCompactParser.parseHasRestrictionValue(kb, text);
        }
    }


    public String getBrowserText() {
        return getBrowserTextPropertyName() + " " + OPERATOR + " " + getBrowserTextFiller();
    }


    public RDFProperty getFillerProperty() {
        return getOWLModel().getRDFProperty(OWLNames.Slot.HAS_VALUE);
    }


    public String getFillerText() {
        Object value = getHasValue();
        if (value == null) {
            return "";
        }
        else {
            if (value instanceof Frame) {
                return ((Frame) value).getBrowserText();
            }
            else {
                if (value instanceof String) {
                    return "\"" + value + "\"";
                }
                else {
                    return value.toString();
                }
            }
        }
    }


    public Object getHasValue() {
        return getDirectOwnSlotValue(getFillerProperty());
    }


    public void getNestedNamedClasses(Set set) {
        if (getHasValue() instanceof RDFSClass) {
            ((RDFSClass) getHasValue()).getNestedNamedClasses(set);
        }
    }


    public char getOperator() {
        return OPERATOR;
    }


    public void setFillerText(String text) throws Exception {
        OWLModel kb = getOWLModel();
        Object value = OWLCompactParser.parseHasRestrictionValue(kb, text);
        setHasValue(value);
    }


    public void setHasValue(Object value) {
        if (value instanceof Double) {
            value = new Float(((Double) value).doubleValue());
        }
        if (value instanceof Long) {
            value = new Integer(((Long) value).intValue());
        }
        setDirectOwnSlotValue(getFillerProperty(), value);
    }


    public void accept(OWLModelVisitor visitor) {
        visitor.visitOWLHasValue(this);
    }
}
